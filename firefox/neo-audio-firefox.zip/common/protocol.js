// Neo Audio — 引擎宿主 ⇄ UI 的消息协议（阶段 3.1）。
//
// 宿主（EngineHost）持有 AudioContext 与 NeoAudio；UI（EngineClient）只讲这套消息。
// 同一页面里两端用 createLocalChannel()（直接传对象，零拷贝）；跨 runtime.Port 时用 wrapJsonPort()
// （Chrome 的 Port 只能传 JSON：FRAME 里的 Float32Array 要转成普通数组，见 encodeForJson / decodeFromJson）。
//
// UI → 宿主：
//   {type:'hello'}                                    → 宿主回 ready（已启动）或 state（未启动）
//   {type:'set', module, index, field, value}
//   {type:'get', id, module, index, field}            → 回 {type:'got', id, value, error}
//   {type:'enable', module, on}
//   {type:'getEnabled', id, module}                   → 回 {type:'got', id, value(0/1), error}
//   {type:'layout', module, freqs:number[]}
//   {type:'fft', fftSize, curvePoints}                → 宿主重建分析器
//   {type:'display', on, intervalMs?}                 → 显示帧开关（关 = worklet 停发）
//   {type:'apply', ops:[{t:'enable',m,on}|{t:'set',m,i,f,v}]}  整份设置一次下发
//   {type:'clearClip'}
//   {type:'volume', value}                             总音量 0…1（宿主里引擎之后的增益；标签页被捕获后由插件播放）
//   {type:'hq', op:'status'|'download'|'cancel'|'delete'|'restart'}   虚拟舞台的分离模型（阶段 4.5）：查状态 / 下载 / 取消 /
//                                                    删除缓存 / 按新设置重起分离 Worker；宿主回 hq 状态
// 宿主 → UI：
//   {type:'ready', sampleRate, latency, fftSize, curvePoints, source}
//   {type:'state', started, idle, source, warnings:string[]}
//   {type:'frame', d}                                 一帧显示数据（NeoAudio.onDisplay 的对象）
//   {type:'idle', on}
//   {type:'hq', model:{state:'none'|'downloading'|'ready'|'error', loaded, total, error},
//               engine:{state:'off'|'starting'|'on'|'failed'|'nomodel', ep, threads, rtf, infMs, windows, depth, error}}
//                                                    模型下载状态变化、分离 Worker 状态 / 每段统计都会推一条
//   {type:'got', id, value, error} / {type:'error', message}

export const PROTOCOL_VERSION = 1;

export const MSG = Object.freeze({
  HELLO: "hello",
  READY: "ready",
  STATE: "state",
  SET: "set",
  GET: "get",
  GOT: "got",
  ENABLE: "enable",
  GET_ENABLED: "getEnabled",
  LAYOUT: "layout",
  FFT: "fft",
  DISPLAY: "display",
  FRAME: "frame",
  IDLE: "idle",
  APPLY: "apply",
  CLEAR_CLIP: "clearClip",
  VOLUME: "volume",
  HQ: "hq",
  ERROR: "error",
});

/** 通道端点：post(msg) 发给对端；onMessage(fn) 收；close()。 */
class LocalEndpoint {
  constructor() {
    this.peer = null;
    this.handler = null;
    this.closed = false;
    this._queue = [];
  }
  post(msg) {
    if (this.closed || !this.peer) return;
    const peer = this.peer;
    // 微任务投递：保持发送顺序，也避免在调用方的调用栈里直接重入对端
    queueMicrotask(() => {
      if (peer.closed) return;
      if (peer.handler) peer.handler(msg);
      else peer._queue.push(msg);
    });
  }
  onMessage(fn) {
    this.handler = fn;
    if (fn && this._queue.length) {
      const q = this._queue.splice(0);
      for (const m of q) fn(m);
    }
  }
  close() {
    this.closed = true;
    this.handler = null;
    this.peer = null;
  }
}

/** 同一页面里的一对端点（宿主一端、UI 一端）。 */
export function createLocalChannel() {
  const a = new LocalEndpoint();
  const b = new LocalEndpoint();
  a.peer = b;
  b.peer = a;
  return { host: a, ui: b };
}

/** 把 MessagePort / Worker 一类支持结构化克隆的端口包成端点。 */
export function wrapMessagePort(port) {
  const ep = {
    post: (msg) => port.postMessage(msg),
    onMessage: (fn) => {
      port.onmessage = fn ? (e) => fn(e.data) : null;
    },
    close: () => {
      port.onmessage = null;
      if (port.close) port.close();
    },
  };
  if (port.start) port.start();
  return ep;
}

/** 把只能传 JSON 的 runtime.Port 包成端点（FRAME 自动编解码）。 */
export function wrapJsonPort(port) {
  let handler = null;
  const listener = (m) => {
    if (handler) handler(decodeFromJson(m));
  };
  port.onMessage.addListener(listener);
  return {
    post: (msg) => port.postMessage(encodeForJson(msg)),
    onMessage: (fn) => {
      handler = fn;
    },
    close: () => {
      handler = null;
      try {
        port.onMessage.removeListener(listener);
        port.disconnect();
      } catch (_) {
        /* 已断开 */
      }
    },
  };
}

const FRAME_ARRAYS = ["meters", "curveDb", "curveFreq", "barsDb", "barFreq", "barActive", "waveL", "waveR", "scopeL", "scopeR"];

/** FRAME 的 Float32Array → 普通数组（JSON 可传）；其它消息原样。 */
export function encodeForJson(msg) {
  if (!msg || msg.type !== MSG.FRAME || !msg.d) return msg;
  const d = {};
  for (const [k, v] of Object.entries(msg.d)) d[k] = ArrayBuffer.isView(v) ? Array.from(v) : v;
  return { type: MSG.FRAME, d };
}

/** encodeForJson 的逆：把 FRAME 的数组恢复成 Float32Array。 */
export function decodeFromJson(msg) {
  if (!msg || msg.type !== MSG.FRAME || !msg.d) return msg;
  const d = Object.assign({}, msg.d);
  for (const k of FRAME_ARRAYS) if (Array.isArray(d[k])) d[k] = Float32Array.from(d[k]);
  return { type: MSG.FRAME, d };
}
