// Neo Audio — 扩展后台脚本（阶段 3.2 / 3.4）：Chrome 当 service worker 跑，Firefox 当事件页跑，同一份代码。
// 标签页捕获（tabCapture + offscreen）只有 Chrome 有；Firefox 只走页内媒体宿主（content script 里）。
//
// 职责：按标签页记住"开 / 关"（storage.session，SW 被回收后也在）；点工具栏图标 → 让该标签页的 content script
// 启动（它按首选音源决定：页内媒体宿主就在页面里；标签页捕获则回来请 SW 做 tabCapture 并起 offscreen 宿主）；
// 徽章 ON。再点 / 关标签页 / 面板电源键 → 关：content script 卸掉 UI 与页内宿主，offscreen 的宿主销毁，没活动捕获时关 offscreen 文档。
//
// 消息：
//   content → SW：{type:"neo-query"} → {active}；{type:"neo-stop"}；{type:"neo-capture", on} → {ok, error, sampleRate}
//   SW → content：{type:"neo-activate"} / {type:"neo-deactivate"}；{type:"neo-status"} / {type:"neo-probe", …}（自动化）
//   SW → offscreen：{to:"offscreen", type:"ping"|"start"|"stop"|"status"|"probe", …}

import { ModelStore } from "./model-store.js";
import { HQ_MODEL } from "./hq-model.js";
import { createHqServer } from "./hq-session.js";

const ACTIVE_KEY = "neo.activeTabs";
const CAPTURE_KEY = "neo.captureTabs";
const CAN_CAPTURE = !!(chrome.tabCapture && chrome.offscreen); // Firefox 没有这两个 API
const CONTENT_SCRIPT = "common/content-boot.js";

async function getSet(key) {
  const r = await chrome.storage.session.get(key);
  return new Set(r[key] || []);
}
async function putSet(key, set) {
  await chrome.storage.session.set({ [key]: [...set] });
}
const getActive = () => getSet(ACTIVE_KEY);

// ---- offscreen 文档（只在标签页捕获模式下需要）

async function pingOffscreen(timeoutMs) {
  const t0 = Date.now();
  for (;;) {
    try {
      const r = await chrome.runtime.sendMessage({ to: "offscreen", type: "ping" });
      if (r && r.ok) return true;
    } catch (_) {
      /* 还没就绪 */
    }
    if (Date.now() - t0 > timeoutMs) return false;
    await new Promise((r) => setTimeout(r, 50));
  }
}

// offscreen 文档的建 / 关串行化：标签页重载时"旧捕获释放 → 关文档"与"新页面激活 → 建文档"会撞车（并发 createDocument 直接抛）
let offscreenLock = Promise.resolve();
function withOffscreenLock(fn) {
  const p = offscreenLock.then(fn, fn);
  offscreenLock = p.catch(() => {});
  return p;
}

function ensureOffscreen() {
  return withOffscreenLock(ensureOffscreenNow);
}

async function ensureOffscreenNow() {
  // createDocument 返回时文档的模块脚本可能还没注册监听：ping 到应答为止；已有文档却不应答（旧版代码留下的）→ 关掉重建
  if (await chrome.offscreen.hasDocument()) {
    if (await pingOffscreen(1500)) return;
    console.warn("[Neo Audio] 已有的 offscreen 文档不应答，重建");
    try {
      await chrome.offscreen.closeDocument();
    } catch (_) {
      /* 已关闭 */
    }
  }
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA", "AUDIO_PLAYBACK"],
    justification: "在后台文档里用 AudioWorklet 处理被捕获标签页的音频并播放处理后的声音",
  });
  if (!(await pingOffscreen(5000))) throw new Error("offscreen 文档 5 s 内没有就绪（看 chrome://extensions → 检查视图 offscreen.html 的控制台）");
}

// ---- 系统占用（面板底部读数，BO 2026-10-16）：CPU% 按两次采样的 idle / total 差算，系统内存按 capacity − available。
// 浏览器没有 GPU 利用率 / 显存的接口（WebGPU 也不暴露），所以只有这两项；Firefox 没有 chrome.system.* → null
let cpuLast = null;
async function sysInfo() {
  const out = { cpu: null, mem: null };
  if (!(chrome.system && chrome.system.cpu)) return out;
  try {
    const info = await chrome.system.cpu.getInfo();
    let idle = 0;
    let total = 0;
    for (const p of info.processors) {
      idle += p.usage.idle;
      total += p.usage.total;
    }
    if (cpuLast && total > cpuLast.total) out.cpu = Math.max(0, Math.min(100, 100 * (1 - (idle - cpuLast.idle) / (total - cpuLast.total))));
    cpuLast = { idle, total };
  } catch (_) {
    /* 没权限 */
  }
  try {
    if (chrome.system.memory) {
      const mi = await chrome.system.memory.getInfo();
      out.mem = { used: mi.capacity - mi.availableCapacity, total: mi.capacity };
    }
  } catch (_) {
    /* 没权限 */
  }
  return out;
}

// ---- 分离模型（阶段 4.5）：缓存在插件源的 IndexedDB。状态 / 删除 SW 自己读写；下载交给 offscreen 文档（SW 随时会被回收，
// 168 MB 的流式下载在那里不安全），下载期间 offscreen 不关；进度由 offscreen 发 neo-model-state 过来，再广播给开着的标签页
const swStore = new ModelStore(HQ_MODEL);
let modelDownloading = false;
// 分离服务（方案 B）：Chrome 在 offscreen 文档里（这里只数有几条 neo-hq 端口，用于"空闲就关"），Firefox 没有 offscreen → 后台页自己带
// Firefox：Worker 模式 + 看门狗（WebGPU 首次推理随机不返回：Worker 里、内联主线程里都见过；主线程卡住救不回，Worker 能杀掉重起）
const hqServer = CAN_CAPTURE ? null : createHqServer({ modelStore: swStore, workerUrl: chrome.runtime.getURL("shared/neo-hq-worker.js"), coreUrl: chrome.runtime.getURL("shared/neo-hq-core.js"), watchdogMs: 45000, log: (t) => console.debug("[Neo Audio]", t) });
let hqPorts = 0;
if (!CAN_CAPTURE) swStore.onState = (st) => broadcastModelState(Object.assign({}, st)); // Firefox：下载在后台页自己做，进度广播给标签页

async function modelOp(op, m) {
  if (op === "seturl" && m && typeof m.url === "string") {
    // 开发 / 自动化：模型地址换成本地服务器（Chrome 的 offscreen 经 start / model 消息拿到同一个覆盖值）
    swStore.url = m.url;
    await chrome.storage.local.set({ "neo.devModelUrl": m.url }).catch(() => {});
    return swStore.status();
  }
  if (op === "status") return swStore.status();
  if (op === "delete") {
    modelDownloading = false;
    return swStore.delete();
  }
  if (!CAN_CAPTURE) {
    // Firefox：后台页自己下（下载中 content script 每秒问一次状态，事件页不会因 30 s 没消息被挂起；光连着端口救不了它）
    if (op === "download") swStore.download();
    else if (op === "cancel") swStore.cancel();
    return swStore.status();
  }
  await ensureOffscreen();
  const dev = await chrome.storage.local.get("neo.devModelUrl").catch(() => ({}));
  const r = await chrome.runtime.sendMessage({ to: "offscreen", type: "model", op, devModelUrl: dev["neo.devModelUrl"] || undefined });
  if (op === "download" && r && r.state && r.state.state === "downloading") modelDownloading = true;
  return r && r.state ? r.state : swStore.state;
}

async function broadcastModelState(state) {
  const was = modelDownloading;
  modelDownloading = state.state === "downloading"; // 以 offscreen 报的状态为准（它的第一条"下载中"可能比 modelOp 的回复先到）
  for (const tabId of await getActive()) tellTab(tabId, { type: "neo-model-state", state });
  // 只在"下载结束"时考虑关文档：宿主启动时刷新模型状态也会发一条（曾把正在起宿主的 offscreen 关掉，start 永远没回音）
  if (was && !modelDownloading) await closeOffscreenIfIdle();
}

function closeOffscreenIfIdle() {
  return withOffscreenLock(closeOffscreenIfIdleNow);
}

let capturePending = 0; // 正在起捕获（拿到 streamId 到宿主回应之间）：这段时间不许关 offscreen

async function closeOffscreenIfIdleNow() {
  if (!CAN_CAPTURE) return;
  if (modelDownloading || capturePending > 0 || hqPorts > 0) return;
  const caps = await getSet(CAPTURE_KEY);
  if (caps.size) return;
  try {
    if (!(await chrome.offscreen.hasDocument())) return;
    // SW 随时可能被回收、内存里的计数会丢：关之前问一下文档本身（下载中 / 还有分离通道就不关）
    const st = await chrome.runtime.sendMessage({ to: "offscreen", type: "status" }).catch(() => null);
    if (st && (st.downloading || st.hq > 0)) return;
    await chrome.offscreen.closeDocument();
  } catch (_) {
    /* 已关闭 */
  }
}

/** 标签页捕获开 / 关（content script 请求）。开需要该标签页已被"调用"过（点过图标，activeTab）。 */
async function capture(tabId, on) {
  if (!CAN_CAPTURE) {
    if (on) throw new Error("此浏览器不支持标签页捕获");
    return { ok: true };
  }
  let caps = await getSet(CAPTURE_KEY);
  if (on) {
    // 该标签页还挂着旧的捕获（页面重载 / 导航后没释放）：先停掉，否则 getMediaStreamId 报 "Cannot capture a tab with an active stream"
    if (caps.has(tabId)) {
      await capture(tabId, false);
      caps = await getSet(CAPTURE_KEY);
    }
    capturePending++;
    try {
      await ensureOffscreen();
      const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
      // 开发 / 自动化：neo.devModelUrl 把分离模型的下载地址换成本地（offscreen 文档自己读不到 chrome.storage）
      const dev = await chrome.storage.local.get("neo.devModelUrl").catch(() => ({}));
      const r = await chrome.runtime.sendMessage({ to: "offscreen", type: "start", tabId, streamId, devModelUrl: dev["neo.devModelUrl"] || undefined });
      if (!r || !r.ok) throw new Error((r && r.error) || "offscreen 未响应");
      caps.add(tabId);
      await putSet(CAPTURE_KEY, caps);
      return r;
    } finally {
      capturePending--;
    }
  }
  if (caps.has(tabId)) {
    caps.delete(tabId);
    await putSet(CAPTURE_KEY, caps);
    try {
      await chrome.runtime.sendMessage({ to: "offscreen", type: "stop", tabId });
    } catch (_) {
      /* offscreen 可能已关闭 */
    }
  }
  await closeOffscreenIfIdle();
  return { ok: true };
}

// ---- 标签页开关

async function badge(tabId, on) {
  try {
    await chrome.action.setBadgeText({ tabId, text: on ? "ON" : "" });
    if (on) await chrome.action.setBadgeBackgroundColor({ tabId, color: "#c99a58" });
  } catch (_) {
    /* 标签页可能已关闭 */
  }
}

async function tellTab(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch (_) {
    return null; // 该页面没有 content script（chrome:// 等，或安装插件前就已打开的页面）
  }
}

/**
 * 让该标签页启动。安装 / 更新插件之前就已打开的页面没有 content script（Chrome 不会补注入），
 * 消息没人接时用 scripting 注入一次再发（点过图标的标签页有 activeTab 授权）。
 */
async function showUi(tabId) {
  const r = await tellTab(tabId, { type: "neo-activate" });
  if (r) return r;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: [CONTENT_SCRIPT] });
  } catch (e) {
    console.warn("[Neo Audio] 无法注入 content script（chrome:// / 商店页面等）:", e.message);
    return null;
  }
  return tellTab(tabId, { type: "neo-activate" });
}

async function activate(tabId) {
  const set = await getActive();
  set.add(tabId);
  await putSet(ACTIVE_KEY, set);
  await badge(tabId, true);
  const r = await showUi(tabId);
  if (!r) throw new Error("页面无法注入 UI");
  if (!r.ok) throw new Error(r.error || "启动失败");
  return r;
}

async function deactivate(tabId) {
  const set = await getActive();
  if (!set.has(tabId)) return;
  set.delete(tabId);
  await putSet(ACTIVE_KEY, set);
  await badge(tabId, false);
  await tellTab(tabId, { type: "neo-deactivate" });
  await capture(tabId, false);
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id === undefined) return;
  const set = await getActive();
  try {
    if (set.has(tab.id)) await deactivate(tab.id);
    else await activate(tab.id);
  } catch (e) {
    console.error("[Neo Audio]", e);
    await deactivate(tab.id).catch(() => {});
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  deactivate(tabId).catch(() => {});
});

// content script 的"活着吗"长连接（neo-alive）：这边不用做事，只要接住端口；扩展重载时端口自然断开，页内脚本据此退出
// content script 的"活着吗"长连接还兼作"文档没了"的信号：端口断开 = 页面重载 / 导航到新文档（或 content script 退出）。
// 被捕获的标签页此时要立刻释放旧的捕获流与 offscreen 宿主——不释放的话标签页一直被旧流静音，新页面再捕获会报
// "Cannot capture a tab with an active stream"、退回页内媒体后页面自己的声音又被捕获吃掉，结果就是没声（BO 2026-10-15）。
// 不能用 tabs.onUpdated(status = loading)：YouTube 换影片是 SPA 导航，文档没换它也会报 loading，一放就把正在用的捕获停了，
// 面板停在"等待引擎…"（BO 2026-10-16）
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "neo-hq") {
    // 分离通道：Firefox 由后台页接；Chrome 由 offscreen 文档接（它也收到同一个 onConnect），这里只计数
    if (hqServer) {
      hqServer.attach(port);
      return;
    }
    hqPorts++;
    port.onDisconnect.addListener(() => {
      hqPorts = Math.max(0, hqPorts - 1);
      // 换设备重起分离时通道断了马上又连：缓 3 s 再看要不要关，别把 offscreen 文档拆了再建（起得慢、模型要重读）
      setTimeout(closeOffscreenIfIdle, 3000);
    });
    return;
  }
  if (port.name !== "neo-alive") return;
  port.onMessage.addListener(() => {});
  const tabId = port.sender && port.sender.tab ? port.sender.tab.id : undefined;
  port.onDisconnect.addListener(() => {
    if (tabId !== undefined) capture(tabId, false).catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || !m.type || m.to === "offscreen") return false;
  const tabId = sender.tab ? sender.tab.id : undefined;
  if (m.type === "neo-query") {
    // cpuSeparation：分离的 CPU 模式要多线程 wasm（SharedArrayBuffer）；Chrome 的 offscreen 有，Firefox 的后台页没有 → 面板灰掉 CPU
    // sysInfo：有没有 chrome.system.cpu（Firefox 没有 → 面板不显示"整机 CPU / 内存"，以前是一直显示"—"）
    getActive().then((set) => reply({ active: tabId !== undefined && set.has(tabId), canCapture: CAN_CAPTURE, cpuSeparation: CAN_CAPTURE || typeof SharedArrayBuffer !== "undefined", sysInfo: !!(chrome.system && chrome.system.cpu) }));
    return true;
  }
  if (m.type === "neo-stop" && tabId !== undefined) {
    deactivate(tabId).then(() => reply({ ok: true }));
    return true;
  }
  if (m.type === "neo-hq-prepare") {
    // 页面要起分离：Chrome 先把 offscreen 文档拉起来（content script 随后 connect("neo-hq")）；Firefox 后台页本身就是服务端
    if (!CAN_CAPTURE) {
      reply({ ok: true });
      return false;
    }
    ensureOffscreen().then(
      () => reply({ ok: true }),
      (e) => reply({ ok: false, error: e.message })
    );
    return true;
  }
  if (m.type === "neo-gpuprobe") {
    // 诊断：后台页主线程 / 后台页里的 Worker 各自有没有 WebGPU（Firefox 4.5b 定方案用）
    (async () => {
      const out = { main: { gpu: !!(typeof navigator !== "undefined" && navigator.gpu), adapter: null, sab: typeof SharedArrayBuffer !== "undefined" }, worker: null, ua: navigator.userAgent };
      try {
        const ad = navigator.gpu ? await navigator.gpu.requestAdapter({ powerPreference: "high-performance" }) : null;
        if (ad) {
          const info = ad.info || {};
          out.main.adapter = `${info.vendor || "?"} ${info.architecture || ""} ${info.description || ""}`.trim();
        }
      } catch (e) {
        out.main.error = e.message;
      }
      try {
        out.worker = await new Promise((resolve, reject) => {
          const w = new Worker(chrome.runtime.getURL("shared/gpu-probe-worker.js"));
          const t = setTimeout(() => reject(new Error("timeout")), 8000);
          w.onmessage = (e) => { clearTimeout(t); resolve(e.data); w.terminate(); };
          w.onerror = (e) => { clearTimeout(t); reject(new Error(e.message || "worker error")); };
        });
      } catch (e) {
        out.worker = { error: e.message };
      }
      reply(out);
    })();
    return true;
  }
  if (m.type === "neo-sys") {
    sysInfo().then(reply, () => reply(null));
    return true;
  }
  if (m.type === "neo-model" && tabId !== undefined) {
    modelOp(m.op, m).then(
      (state) => reply({ state }),
      (e) => reply({ state: { state: "error", loaded: 0, total: HQ_MODEL.size, error: e.message } })
    );
    return true;
  }
  if (m.type === "neo-model-state" && tabId === undefined) {
    broadcastModelState(m.state || {}).catch(() => {});
    return false;
  }
  if (m.type === "neo-capture" && tabId !== undefined) {
    capture(tabId, !!m.on).then(
      (r) => reply(Object.assign({ ok: true }, r)),
      (e) => reply({ ok: false, error: e.message })
    );
    return true;
  }
  return false;
});

// 启动自检：shared/、common/、dsp_wasm.wasm 是 tools/pack.py 拷进来的；直接加载没打包的源码目录时它们不存在，
// offscreen / 面板的模块一导入就失败，现象是"徽章 ON 但什么都不出现"。缺了就把原因写进控制台。
(async () => {
  const missing = [];
  for (const f of ["shared/wasm-abi.js", "common/host.js", "common/media-host.js", "common/ui/panel.js", "common/content-boot.js", "dsp_wasm.wasm"]) {
    try {
      const r = await fetch(chrome.runtime.getURL(f), { method: "HEAD" });
      if (!r.ok) missing.push(f);
    } catch (_) {
      missing.push(f);
    }
  }
  if (missing.length) console.error(`[Neo Audio] 扩展目录缺少文件：${missing.join(", ")}。请先运行 python tools/pack.py（Firefox 加 --browser firefox），再重新加载扩展目录。`);
})();

// 自动化（Playwright 拿到 SW 后直接调）：不经过工具栏点击
self.__neo = { activate, deactivate, getActive, capture, ensureOffscreen, closeOffscreenIfIdle, modelOp, status: (tabId) => tellTab(tabId, { type: "neo-status" }), probe: (tabId, m) => tellTab(tabId, Object.assign({ type: "neo-probe", tabId }, m)) }; // tabId 带着：标签页捕获模式下 content script 把探针转给 offscreen，它按 tabId 找宿主
