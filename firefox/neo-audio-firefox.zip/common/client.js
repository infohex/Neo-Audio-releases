// Neo Audio — UI 侧的引擎客户端（阶段 3.1）。
//
// 对页面 / 面板呈现与 NeoAudio 相同的控制面（setParam / getParam / getModuleEnabled / setModuleEnabled /
// setFftSize / clearClip / onDisplay / onIdle / feedLamp / lamp / ui），但引擎在宿主那边，这里只讲协议。
// UI 侧自己持有一个 wasm 实例（lampAbi：na_init 过、不处理音频）：保管模块 11 显示设置、跑灯板，
// 并建一个与宿主同点数的分析器只为拿频点表（空屏版面）。

import { MODULE, ERR, NeoLamp } from "../shared/neo-audio-node.js";
import { MSG } from "./protocol.js";

export class EngineClient {
  /**
   * @param {{post:Function,onMessage:Function,close:Function}} ep 通道端点
   * @param {{lampAbi:object, sampleRate?:number, fftSize?:number, curvePoints?:number}} o
   */
  constructor(ep, o) {
    this.ep = ep;
    this.ui = o.lampAbi; // 与 NeoAudio.ui 同名：模块 11 读写、moduleCount、analyzerFftSize 都从这里来
    this.opts = { fftSize: o.fftSize || 4096, curvePoints: o.curvePoints || 256 };
    this.sampleRate = o.sampleRate || 48000;
    this.latency = 0;
    this.idle = false;
    this.started = false;
    this.source = "none";
    this.warnings = [];
    this.displayOn = false;
    this.volume = 1;
    this.frameCount = 0; // 收到的显示帧数（自动化核对显示屏开关用）
    this.onDisplay = null;
    this.onIdle = null;
    this.onError = null;
    this.onState = null;
    this.onReady = null;
    this.onHq = null; // (m) => void：分离模型 / Worker 状态（协议里的 hq 消息）
    this.hq = null;
    this._pending = new Map();
    this._nextId = 1;
    this._cache = new Map();
    this._lampObj = new NeoLamp(this.ui);
    this.lamp = this._lampObj.lamp;
    this._ready = new Promise((resolve) => {
      this._resolveReady = resolve;
    });
    ep.onMessage((m) => this._onMessage(m));
    ep.post({ type: MSG.HELLO });
  }

  /** 宿主启动完成（收到 ready）。 */
  get ready() {
    return this._ready;
  }

  _onMessage(m) {
    if (!m) return;
    switch (m.type) {
      case MSG.READY:
        this.started = true;
        this.sampleRate = m.sampleRate;
        this.latency = m.latency;
        this.source = m.source;
        if (m.fftSize) this.opts.fftSize = m.fftSize;
        if (m.curvePoints) this.opts.curvePoints = m.curvePoints;
        if (typeof m.volume === "number") this.volume = m.volume;
        this._syncLocalAnalyzer();
        if (this.displayOn) this.ep.post({ type: MSG.DISPLAY, on: true });
        if (this.onReady) this.onReady(m);
        this._resolveReady(m);
        break;
      case MSG.STATE:
        this.started = !!m.started;
        this.idle = !!m.idle;
        this.source = m.source;
        this.warnings = m.warnings || [];
        if (this.onState) this.onState(m);
        break;
      case MSG.FRAME:
        if (this.displayOn && this.onDisplay) {
          this.frameCount++;
          this.onDisplay(m.d);
        }
        break;
      case MSG.IDLE:
        this.idle = !!m.on;
        if (this.onIdle) this.onIdle(this.idle);
        break;
      case MSG.GOT: {
        const p = this._pending.get(m.id);
        if (p) {
          this._pending.delete(m.id);
          if (m.error === ERR.OK) p.resolve(m.value);
          else p.reject(new Error(`na_get_param 错误 ${m.error}`));
        }
        break;
      }
      case MSG.HQ:
        this.hq = m;
        if (this.onHq) this.onHq(m);
        break;
      case MSG.ERROR:
        if (this.onError) this.onError(new Error(m.message));
        break;
      default:
        break;
    }
  }

  /** 虚拟舞台的分离模型 / Worker：op = status | download | cancel | delete | restart（结果经 onHq 推回）。 */
  hqOp(op) {
    this.ep.post({ type: MSG.HQ, op });
  }

  _syncLocalAnalyzer() {
    // 本地分析器只为频点表：与宿主同点数，这样 curveFreq / barFreq 一致
    const r = this.ui.analyzerInit(this.sampleRate, this.opts.fftSize, this.opts.curvePoints);
    if (r !== ERR.OK && this.onError) this.onError(new Error(`本地分析器重建失败: ${r}`));
  }

  // ---- 与 NeoAudio 相同的控制面 ----

  paramInfo(module, field) {
    return this.ui.paramInfo(module, field);
  }

  setParam(module, index, field, value) {
    this._cache.set(`${module}/${index}/${field}`, value);
    if (module === MODULE.DISPLAY) return this.ui.setParam(module, index, field, value);
    this.ep.post({ type: MSG.SET, module, index, field, value });
    return ERR.OK;
  }

  getParam(module, index, field) {
    if (module === MODULE.DISPLAY) {
      const v = this.ui.getParam(module, index, field);
      return Number.isNaN(v) ? Promise.reject(new Error(`na_get_param 错误 ${this.ui.lastError()}`)) : Promise.resolve(v);
    }
    return new Promise((resolve, reject) => {
      const id = this._nextId++;
      this._pending.set(id, { resolve, reject });
      this.ep.post({ type: MSG.GET, id, module, index, field });
    });
  }

  cachedParam(module, index, field) {
    return this._cache.get(`${module}/${index}/${field}`);
  }

  getModuleEnabled(module) {
    return new Promise((resolve, reject) => {
      const id = this._nextId++;
      this._pending.set(id, { resolve: (v) => resolve(v > 0.5), reject });
      this.ep.post({ type: MSG.GET_ENABLED, id, module });
    });
  }

  setModuleEnabled(module, on) {
    this.ep.post({ type: MSG.ENABLE, module, on: !!on });
  }

  setLayout(module, freqs) {
    this.ep.post({ type: MSG.LAYOUT, module, freqs: Array.from(freqs) });
  }

  clearClip() {
    this.ep.post({ type: MSG.CLEAR_CLIP });
  }

  /** 总音量 0…1（宿主里引擎之后的增益）。 */
  setVolume(v) {
    this.volume = Math.max(0, Math.min(1, Number(v) || 0));
    this.ep.post({ type: MSG.VOLUME, value: this.volume });
  }

  /** 改 FFT 点数：宿主重建分析器，本地分析器跟着重建（频点表一致）。 */
  setFftSize(fftSize, curvePoints = this.opts.curvePoints) {
    this.opts.fftSize = fftSize;
    this.opts.curvePoints = curvePoints;
    this._syncLocalAnalyzer();
    this.ep.post({ type: MSG.FFT, fftSize, curvePoints });
    return ERR.OK;
  }

  /** 显示屏开关：关 = 宿主不再发帧（没有别的 UI 要时 worklet 停发），灯板清零。 */
  setDisplay(on) {
    on = !!on;
    if (on === this.displayOn) return;
    this.displayOn = on;
    this.ep.post({ type: MSG.DISPLAY, on });
    if (!on) this._lampObj.reset();
  }

  /** 整份设置一次下发（见 protocol.js apply）。 */
  apply(ops) {
    for (const op of ops) {
      if (op.t === "set") this._cache.set(`${op.m}/${op.i || 0}/${op.f}`, op.v);
      if (op.t === "set" && op.m === MODULE.DISPLAY) this.ui.setParam(op.m, op.i || 0, op.f, op.v);
    }
    this.ep.post({ type: MSG.APPLY, ops });
  }

  feedLamp(d) {
    return this._lampObj.feedLamp(d);
  }

  destroy() {
    this.setDisplay(false);
    this.ep.close();
    this._pending.clear();
  }
}
