// Neo Audio — 界面文字表（阶段 3.2，BO 2026-10-08：多语言）。
//
// 每个键给出各语言的文字；需要缩写的（推子标签）用 [长名, 短名]：推子上显示短名，完整名放在悬停提示。
// 短名的硬规则：中文 ≤ 4 字，英文 ≤ 9 个字符；超出的由 CSS 折成两行兜底（不再出现 "…"）。
// 显示屏画布上的 PEAK / L+R / 频率刻度是仪表习惯，不翻译。
//   t(key)  长名      ts(key) 短名（没有短名时 = 长名）      setLang(id) / lang() / detectLang()
// 默认语言 en（BO 2026-10-08）；测试页固定中文（setLang("zh-CN")）；面板按保存的设置，没存过就英文。

export const LANGS = [
  { id: "zh-CN", name: "简体中文" },
  { id: "en", name: "English" },
];
const DEFAULT = "en";
let current = DEFAULT;

const T = {
  // ---- 面板头部 / 右上角
  "collapse": { "zh-CN": "收起", en: "Collapse" },
  "power": { "zh-CN": "停止处理并关闭", en: "Stop processing and close" },
  "source.element": { "zh-CN": "页内媒体", en: "Page media" },
  "source.tab": { "zh-CN": "标签页", en: "Tab" },
  "source.none": { "zh-CN": "无音源", en: "No source" },
  "source.switching": { "zh-CN": "切换音源…", en: "Switching source…" },
  "source.tabFailed": { "zh-CN": "标签页捕获失败", en: "Tab capture failed" },
  "source.elementFailed": { "zh-CN": "本页不能运行页内引擎（多半是页面的 CSP 禁止 WebAssembly），已改用标签页捕获", en: "The in-page engine can't run on this page (its CSP probably blocks WebAssembly); using tab capture instead" },
  "volume": { "zh-CN": "音量", en: "Volume" },
  "volume.tip": { "zh-CN": "音量（标签页被捕获后由插件播放）", en: "Volume (the extension plays the captured tab)" },
  "bypass": { "zh-CN": "旁路", en: "Bypass" },
  "bypass.tip": { "zh-CN": "全部旁路（对比）", en: "Bypass everything (A/B)" },
  "status.ready": { "zh-CN": "就绪", en: "Ready" },
  "status.idle": { "zh-CN": "空闲", en: "Idle" },
  "status.waiting": { "zh-CN": "等待引擎…", en: "Waiting for engine…" },
  "status.disconnected": { "zh-CN": "已断开", en: "Disconnected" },
  // ---- 配置栏
  "profiles.tip": { "zh-CN": "设置自动保存；命名配置可快速切换，可导出 / 导入 .json 文件", en: "Settings auto-save; named profiles switch quickly and can be exported / imported as .json" },
  "profile": { "zh-CN": "配置", en: "Profile" },
  "profile.unnamed": { "zh-CN": "（未命名）", en: "(unnamed)" },
  "profile.save": { "zh-CN": "保存", en: "Save" },
  "profile.save.tip": { "zh-CN": "保存到当前配置", en: "Save to the current profile" },
  "profile.saveas": { "zh-CN": "另存为…", en: "Save as…" },
  "profile.saveas.tip": { "zh-CN": "把当前设置存成一个新配置", en: "Store the current settings as a new profile" },
  "profile.namePh": { "zh-CN": "配置名，Enter 保存", en: "Name, Enter to save" },
  "profile.delete": { "zh-CN": "删除", en: "Delete" },
  "profile.export": { "zh-CN": "导出", en: "Export" },
  "profile.export.tip": { "zh-CN": "导出为 .json 文件", en: "Export as a .json file" },
  "profile.import": { "zh-CN": "导入", en: "Import" },
  "profile.import.tip": { "zh-CN": "从 .json 文件导入", en: "Import from a .json file" },
  "theme": { "zh-CN": "界面", en: "Theme" },
  "theme.tip": { "zh-CN": "界面配色", en: "UI colour preset" },
  "theme.A": { "zh-CN": "海岸青", en: "Coast" },
  "theme.B": { "zh-CN": "橙青", en: "Orange" },
  "theme.C": { "zh-CN": "奶油", en: "Cream" },
  "theme.D": { "zh-CN": "深蓝灰", en: "Slate" },
  "lang": { "zh-CN": "语言", en: "Language" },
  "lang.tip": { "zh-CN": "界面语言", en: "UI language" },
  "zoom": { "zh-CN": "缩放", en: "Zoom" },
  "hbar.tip": { "zh-CN": "点击：展开 / 折叠；按住拖动：调整高度", en: "Click: expand / fold; drag: set the height" },
  "zoom.tip": { "zh-CN": "整个面板和圆钮的缩放（小屏幕上缩小、大屏幕上放大）", en: "Scale of the whole panel and button (shrink on small screens, enlarge on large ones)" },
  // ---- 显示屏
  "display.hint": { "zh-CN": "单击：切换 波形 / 频程 / 曲线；双击：弹出 / 收回显示屏；右键：弹出态的缩放与透明度", en: "Click: wave / bands / curve; double-click: pop the display out / back; right-click: popup zoom and opacity" },
  "pop.zoom": { "zh-CN": "弹出显示屏缩放", en: "Popup zoom" },
  "pop.alpha": { "zh-CN": "弹出显示屏透明度", en: "Popup opacity" },
  "display.tip": { "zh-CN": "显示屏开 / 关（关 = 不取显示数据，省 CPU）", en: "Display on / off (off = no display data, saves CPU)" },
  "view.scope": { "zh-CN": "波形", en: "Wave" },
  "view.bars": { "zh-CN": "频程", en: "Bands" },
  "view.curve": { "zh-CN": "曲线", en: "Curve" },
  "scale": { "zh-CN": "刻度", en: "Scale" },
  "scale.linear": { "zh-CN": "线性", en: "Linear" },
  "scale.nonlinear": { "zh-CN": "非线性", en: "Curved" },
  "vfdStyle": { "zh-CN": "风格", en: "Style" },
  "vfd.kenwood": { "zh-CN": "Kenwood 青白", en: "Kenwood cyan" },
  "vfd.green": { "zh-CN": "经典 VFD 绿", en: "Classic VFD green" },
  "vfd.purple": { "zh-CN": "紫色荧光", en: "Purple" },
  "vfd.neon": { "zh-CN": "氖红霓虹", en: "Neon red" },
  "vfd.xenon": { "zh-CN": "氙气白", en: "Xenon white" },
  "vfd.amber": { "zh-CN": "琥珀", en: "Amber" },
  "glow": { "zh-CN": "辉光", en: "Glow" },
  "afterglow": { "zh-CN": "余晖", en: "Persist" },
  "spill": { "zh-CN": "溢光", en: "Spill" },
  "bezel": { "zh-CN": "边框", en: "Bezel" },
  // ---- 页签 / 模块
  "tab.eq": { "zh-CN": "EQ", en: "EQ" },
  "tab.tone": { "zh-CN": "高低音", en: "Tone" },
  "tab.width": { "zh-CN": "3D", en: "3D" },
  "tab.reverb": { "zh-CN": "混响", en: "Reverb" },
  "tab.surround": { "zh-CN": "环绕", en: "Surround" },
  "tab.stage": { "zh-CN": "舞台", en: "Stage" },
  "tab.output": { "zh-CN": "输出级", en: "Output" },
  "module.tip": { "zh-CN": "模块开 / 关", en: "Module on / off" },
  "mod.eq": { "zh-CN": "EQ", en: "EQ" },
  "mod.tone": { "zh-CN": "高低音提升", en: "Tone (TrueBass + TrueTreble)" },
  "mod.width": { "zh-CN": "3D 立体声宽度", en: "3D stereo width" },
  "mod.width.tip": { "zh-CN": "中 / 侧宽度：0 单声道、1 原样、往上展宽；展宽集中在高频起点以上，中频按参与度，低频分频点以下不展宽", en: "Mid/side width: 0 mono, 1 unchanged, above widens; widening is focused above the HF start, mids by the mid amount, bass below the crossover is never widened" },
  "mod.reverb": { "zh-CN": "混响", en: "Reverb" },
  "mod.surround": { "zh-CN": "虚拟环绕", en: "Virtual surround" },
  "mod.stage": { "zh-CN": "虚拟舞台", en: "Virtual stage" },
  "mod.stage.tip": { "zh-CN": "神经网络把混音拆成鼓 / 贝斯 / 人声 / 其它，每个元素可在舞台上任意摆放（含身后），按方位与距离重新合成；与虚拟环绕二选一", en: "A neural net splits the mix into drums / bass / vocals / other; place each element anywhere on the stage (behind you too) and it is re-rendered by direction and distance; exclusive with Virtual surround" },
  "mod.output": { "zh-CN": "输出级", en: "Output stage" },
  "eq.comp": { "zh-CN": "互扰补偿", en: "Interaction comp." },
  "tone.bass": { "zh-CN": "低频", en: "Bass" },
  "tone.treble": { "zh-CN": "高频", en: "Treble" },
  "preset": { "zh-CN": "预设", en: "Preset" },
  "preset.custom": { "zh-CN": "自定义", en: "Custom" },
  "render": { "zh-CN": "渲染", en: "Render" },
  "render.headphones": { "zh-CN": "耳机", en: "Phones" },
  "render.speakers": { "zh-CN": "音箱", en: "Speakers" },
  "timbre": { "zh-CN": "音色修正", en: "Timbre fix" },
  // ---- 推子标签 [长, 短]
  "out.manual": { "zh-CN": ["手动增益", "手动增益"], en: ["Manual gain", "Gain"] },
  "out.auto": { "zh-CN": ["自动增益", "自动增益"], en: ["Auto gain", "Auto"] },
  "out.autoAmount": { "zh-CN": ["自动增益强度", "自动强度"], en: ["Auto gain amount", "Amount"] },
  "out.autoLimit": { "zh-CN": ["自动增益上限", "自动上限"], en: ["Auto gain limit", "Limit"] },
  "out.balance": { "zh-CN": "耳机平衡", en: "Headphone balance" },
  "out.balance.tip": { "zh-CN": "补偿两耳听力差异与耳机左右单元误差。", en: "Compensates hearing asymmetry and driver mismatch." },
  "out.trimL": { "zh-CN": ["左耳音量", "左耳音量"], en: ["Left level", "L level"] },
  "out.trimR": { "zh-CN": ["右耳音量", "右耳音量"], en: ["Right level", "R level"] },
  "out.hfL": { "zh-CN": ["左耳高频", "左耳高频"], en: ["Left treble", "L treble"] },
  "out.hfR": { "zh-CN": ["右耳高频", "右耳高频"], en: ["Right treble", "R treble"] },
  "tone.freq": { "zh-CN": ["提升频点", "提升频点"], en: ["Boost frequency", "Freq"] },
  "tone.gain": { "zh-CN": ["提升量", "提升量"], en: ["Boost amount", "Boost"] },
  "w.width": { "zh-CN": ["立体声宽度", "宽度"], en: ["Stereo width", "Width"] },
  "w.hint": { "zh-CN": "宽度大于 2 建议打开输出级的限幅，否则容易过载", en: "Above 2, enable the output-stage limiter to avoid clipping" },
  "w.xover": { "zh-CN": ["低频分频点", "低频分频"], en: ["Bass crossover", "Bass xover"] },
  "w.hf": { "zh-CN": ["高频起点", "高频起点"], en: ["HF start", "HF start"] },
  "w.mid": { "zh-CN": ["中频参与度", "中频参与"], en: ["Mid amount", "Mid amt"] },
  "st.drums": { "zh-CN": ["鼓", "鼓"], en: ["Drums", "Drums"] },
  "st.bass": { "zh-CN": ["贝斯", "贝斯"], en: ["Bass", "Bass"] },
  "st.vocals": { "zh-CN": ["人声", "人声"], en: ["Vocals", "Vocals"] },
  "st.other": { "zh-CN": ["其它", "其它"], en: ["Other", "Other"] },
  "st.room": { "zh-CN": ["房间感", "房间感"], en: ["Room ambience", "Room"] },
  "st.distAtten": { "zh-CN": ["距离衰减", "距离衰减"], en: ["Distance attenuation", "Dist. att."] },
  "st.rear": { "zh-CN": ["后方强调", "后方强调"], en: ["Rear emphasis", "Rear"] },
  "st.layoutReset": { "zh-CN": "复位摆位", en: "Reset layout" },
  "st.demo": { "zh-CN": "演示", en: "Demo" },
  "st.demo.tip": { "zh-CN": "人声按当前半径绕听者顺时针转圈（演示环绕）；拖动人声会从新位置、新半径继续；再点一次停止", en: "Vocals circle the listener clockwise at their current radius (surround demo); dragging the vocals continues from the new spot and radius; click again to stop" },
  "st.front": { "zh-CN": "前", en: "Front" },
  "st.hint.fallback": { "zh-CN": "分离未就绪，原声直通（模型要先下载；启动要几秒；CPU 跟不上时也会回到这里）", en: "Separation not ready, dry passthrough (the model must be downloaded first; start-up takes a few seconds; it also lands here when the CPU cannot keep up)" },
  "st.hint.video": { "zh-CN": "高音质分离按段处理，声音比画面晚 1–6 s；适合听音乐", en: "High-quality separation works in segments: audio runs 1–6 s behind video; meant for music" },
  "ro.stLatency": { "zh-CN": "延时", en: "Latency" },
  "ro.stLate": { "zh-CN": "声部迟到", en: "Late stems" },
  "ro.stRtf": { "zh-CN": "实时率", en: "Real-time ratio" },
  "st.device": { "zh-CN": "计算", en: "Compute" },
  "st.device.gpu": { "zh-CN": "GPU", en: "GPU" },
  "st.device.cpu": { "zh-CN": "CPU", en: "CPU" },
  "st.device.cpuNA": { "zh-CN": "这个浏览器里 CPU 分离跑不了多线程，跟不上实时；只能用 GPU", en: "CPU separation cannot use multiple threads in this browser and cannot keep up; GPU only" },
  "st.segment": { "zh-CN": ["音质与延时", "音质"], en: ["Quality vs. latency", "Quality"] },
  "st.segment.tip": { "zh-CN": "音质与延时：分离一次处理的音频长度（秒）。越长分得越干净、但声音越晚出来；0.5 s 延时最小，1.5 s 音质最好", en: "Quality vs. latency: audio processed per separation pass (seconds). Longer = cleaner separation but later audio; 0.5 s for least delay, 1.5 s for best quality" },
  "ro.cpu": { "zh-CN": "整机 CPU", en: "System CPU" },
  "ro.mem": { "zh-CN": "整机内存", en: "System memory" },
  "ro.sys.na": { "zh-CN": "不支持", en: "N/A" },
  "ro.sys.naTip": { "zh-CN": "Firefox 没有读取整机 CPU / 内存的接口（chrome.system.*），这两项只有 Chrome 能显示", en: "Firefox has no API for whole-machine CPU / memory (chrome.system.*); only Chrome can show these" },
  "ro.sys.tip": { "zh-CN": "整台电脑的占用（所有程序），不是 Neo Audio 或舞台模块单独的用量——浏览器没有按插件统计的接口", en: "Whole-machine usage (all programs), not Neo Audio's or the stage module's own share — the browser offers no per-extension counters" },
  "st.model": { "zh-CN": "模型", en: "Model" },
  "st.setup.none": { "zh-CN": "首次使用：虚拟舞台要先下载分离模型（168 MB，只下一次，之后存在浏览器里）", en: "First use: Virtual stage needs the separation model first (168 MB, downloaded once and kept in the browser)" },
  "st.setup.downloading": { "zh-CN": "正在下载分离模型，下完自动开始分离", en: "Downloading the separation model; separation starts automatically when done" },
  "st.setup.error": { "zh-CN": "模型下载失败，请重试", en: "Model download failed, please retry" },
  "st.model.none": { "zh-CN": "未下载", en: "Not downloaded" },
  "st.model.downloading": { "zh-CN": "下载中", en: "Downloading" },
  "st.model.ready": { "zh-CN": "已就绪", en: "Ready" },
  "st.model.error": { "zh-CN": "出错", en: "Error" },
  "st.model.download": { "zh-CN": "下载", en: "Download" },
  "st.model.redownload": { "zh-CN": "重新下载", en: "Re-download" },
  "st.model.cancel": { "zh-CN": "取消", en: "Cancel" },
  "st.model.delete": { "zh-CN": "删除", en: "Delete" },
  "st.engine.off": { "zh-CN": "分离：关", en: "Separation: off" },
  "st.engine.starting": { "zh-CN": "分离：启动中…", en: "Separation: starting…" },
  "st.engine.on": { "zh-CN": "分离：运行中", en: "Separation: running" },
  "st.engine.failed": { "zh-CN": "分离：失败", en: "Separation: failed" },
  "st.engine.nomodel": { "zh-CN": "分离：等模型", en: "Separation: waiting for model" },
  "st.hint.drag": { "zh-CN": "拖动圆点摆放元素：方位 + 距离；弧线是元素的宽度", en: "Drag the dots to place elements: direction + distance; the arc is the element width" },
  "rb.room": { "zh-CN": ["混响电平", "混响电平"], en: ["Reverb level", "Level"] },
  "rb.roomHf": { "zh-CN": ["高频衰减", "高频衰减"], en: ["HF damping", "HF damp"] },
  "rb.decay": { "zh-CN": ["混响时间", "混响时间"], en: ["Decay time", "Decay"] },
  "rb.decayHf": { "zh-CN": ["高频衰减比", "高频比"], en: ["HF decay ratio", "HF ratio"] },
  "rb.er": { "zh-CN": ["早反射电平", "早反射"], en: ["Early reflections", "Early"] },
  "rb.erDelay": { "zh-CN": ["早反射延迟", "反射延迟"], en: ["Early reflections delay", "ER delay"] },
  "rb.late": { "zh-CN": ["后期混响电平", "后期电平"], en: ["Late reverb level", "Late"] },
  "rb.lateDelay": { "zh-CN": ["后期混响延迟", "后期延迟"], en: ["Late reverb delay", "Late dly"] },
  "rb.diffusion": { "zh-CN": ["扩散", "扩散"], en: ["Diffusion", "Diffusion"] },
  "rb.density": { "zh-CN": ["密度", "密度"], en: ["Density", "Density"] },
  "rb.hfRef": { "zh-CN": ["高频参考频率", "高频参考"], en: ["HF reference", "HF ref"] },
  "sr.fl": { "zh-CN": ["前左", "前左"], en: ["Front left", "Front L"] },
  "sr.fr": { "zh-CN": ["前右", "前右"], en: ["Front right", "Front R"] },
  "sr.c": { "zh-CN": ["中置", "中置"], en: ["Center", "Center"] },
  "sr.lfe": { "zh-CN": ["LFE", "LFE"], en: ["LFE", "LFE"] },
  "sr.ls": { "zh-CN": ["左环绕", "左环绕"], en: ["Surround left", "Surr L"] },
  "sr.rs": { "zh-CN": ["右环绕", "右环绕"], en: ["Surround right", "Surr R"] },
  "sr.steer": { "zh-CN": ["导向强度", "导向强度"], en: ["Steering", "Steering"] },
  "sr.frontKeep": { "zh-CN": ["前方保留", "前方保留"], en: ["Front keep", "Front"] },
  "sr.centerHpf": { "zh-CN": ["中置下限", "中置下限"], en: ["Center high-pass", "C HPF"] },
  "sr.wrap": { "zh-CN": ["环绕包裹", "环绕包裹"], en: ["Surround wrap", "Wrap"] },
  "sr.delay": { "zh-CN": ["环绕延时", "环绕延时"], en: ["Surround delay", "Delay"] },
  "sr.lpf": { "zh-CN": ["环绕低通", "环绕低通"], en: ["Surround low-pass", "LPF"] },
  "sr.angle": { "zh-CN": ["环绕角度", "环绕角度"], en: ["Surround angle", "Angle"] },
  "sr.room": { "zh-CN": ["房间感", "房间感"], en: ["Room", "Room"] },
  // ---- 读数
  "ro.bass": { "zh-CN": "低频", en: "Bass" },
  "ro.treble": { "zh-CN": "高频", en: "Treble" },
  "ro.lr": { "zh-CN": "左右", en: "L / R" },
  "ro.cs": { "zh-CN": "中置 / 环绕", en: "C / S" },
  "ro.delay": { "zh-CN": "延时", en: "Delay" },
  "ro.off": { "zh-CN": "关", en: "Off" },
  "ro.outOfRange": { "zh-CN": "超出范围", en: "Out of range" },
  "ro.active": { "zh-CN": "生效", en: "Active" },
  "ro.passthrough": { "zh-CN": "0 dB（直通）", en: "0 dB (bypass)" },
  "ro.center": { "zh-CN": "居中", en: "Center" },
  "ro.left": { "zh-CN": "左", en: "L" },
  "ro.right": { "zh-CN": "右", en: "R" },
  "ro.surround": { "zh-CN": "环绕", en: "Surr" },
  "ro.centerCh": { "zh-CN": "中置", en: "Center" },
  // ---- 单位 / 通用
  "unit.samples": { "zh-CN": "样本", en: "samples" },
  "on": { "zh-CN": "开", en: "On" },
  "off": { "zh-CN": "关", en: "Off" },
  "mute.tip": { "zh-CN": "Off = 静音", en: "Off = mute" },
  // ---- 页内媒体宿主的提示
  "media.none": { "zh-CN": "页面上还没有媒体元素；开始播放时会自动接入", en: "No media element on this page yet; it will be hooked when playback starts" },
  "media.cantAttach": { "zh-CN": "媒体元素无法接入（{name}：页面可能已把它接进自己的 WebAudio）", en: "Media element cannot be hooked ({name}: the page may already route it through its own WebAudio)" },
  "media.silent": { "zh-CN": "页内媒体无声：该媒体可能是跨域（无 CORS 头）或受保护的内容，请切到「标签页」捕获", en: "Page media is silent: it may be cross-origin (no CORS headers) or protected; switch the source to Tab" },
};

export function lang() {
  return current;
}

export function setLang(id) {
  current = LANGS.some((l) => l.id === id) ? id : DEFAULT;
  return current;
}

/** 浏览器语言 → 支持的语言（中文系 → zh-CN，其余 → en）。 */
export function detectLang(navLang = typeof navigator !== "undefined" ? navigator.language : "") {
  return /^zh/i.test(navLang || "") ? "zh-CN" : "en";
}

function pick(key) {
  const e = T[key];
  if (!e) return key;
  return e[current] !== undefined ? e[current] : e[DEFAULT];
}

/** 长名；{name} 形式的占位符用 vars 填。 */
export function t(key, vars) {
  let v = pick(key);
  if (Array.isArray(v)) v = v[0];
  if (vars) for (const [k, x] of Object.entries(vars)) v = v.replace(`{${k}}`, x);
  return v;
}

/** 短名（推子标签）；没有短名时就是长名。 */
export function ts(key) {
  const v = pick(key);
  return Array.isArray(v) ? v[1] || v[0] : v;
}
