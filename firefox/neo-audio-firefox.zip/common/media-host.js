// Neo Audio — 页内媒体宿主（阶段 3.2 修订；BO 2026-10-07：标签页捕获会让视频全屏只占浏览器窗口，改为默认直接接页面里的媒体元素）。
//
// 在页面（content script）里建 AudioContext + EngineHost，把 <video>/<audio> 用 createMediaElementSource 接进引擎，
// 处理后的声音从同一个上下文播出。页面自己的音量、全屏、画中画都不受影响。Firefox 走的也是这条路。
//
// 规则：
// - 选哪个元素：正在播放的优先；否则有声音数据（readyState > 0）的里面面积最大的视频；否则第一个。
//   之后任何媒体元素开始播放（document 捕获阶段的 play 事件）就切到它；新插入的媒体元素由 MutationObserver 发现。
// - 同一元素只能接一次（WebAudio 规则）：已接过的记在 WeakMap；页面自己已经把它接进 WebAudio 的会抛 InvalidStateError → 记警告、跳过。
// - 跨域且没有 CORS 头的媒体接进来是静音（浏览器规则）：元素在播、时间在走，而引擎 3 s 空闲 → 警告"页内媒体无声"，提示切到标签页捕获。
// - 释放（切到标签页捕获 / 关插件）：元素一旦接进 WebAudio 就回不去了，所以不关上下文，而是把源直通到 destination，引擎卸掉。

import { EngineHost } from "./host.js";
import { t } from "./i18n.js";

const MEDIA_SEL = "video, audio";
// 同一页面内只建一个 AudioContext，每个元素只建一个 MediaElementAudioSourceNode（WebAudio 规则：元素接进某个上下文后
// 不能再接别的上下文）。关插件 / 切到标签页捕获时节点直通到 destination，再开时从这里取回接进新引擎。
const shared = { ctx: null, nodes: new WeakMap(), failed: new WeakSet() };

export class PageMediaHost {
  /**
   * @param {{module?:WebAssembly.Module, wasmUrl:string, workletUrl:string, neoOpts?:object, log?:Function, onState?:Function}} o
   */
  constructor(o) {
    this.o = o;
    this.log = o.log || (() => {});
    this.host = new EngineHost({ module: o.module, wasmUrl: o.wasmUrl, workletUrl: o.workletUrl, neoOpts: o.neoOpts, modelStore: o.modelStore, log: this.log, makeContext: () => shared.ctx || (shared.ctx = new AudioContext()) });
    this.host.onState = (s) => this._onHostState(s);
    this.current = null; // 当前接进引擎的媒体元素
    this.nodes = shared.nodes; // 元素 → MediaElementAudioSourceNode（只能建一次，页面级共享）
    this.failed = shared.failed; // 接不进去的元素
    this.released = false;
    this.warnings = []; // [{key, vars}]：文字按当前语言现算（allWarnings）
    this._observer = null;
    this._onPlay = (e) => {
      const el = e.target;
      if (el && el.matches && el.matches(MEDIA_SEL) && !this.released) {
        this._resume();
        if (el !== this.current) this.attach(el);
      }
    };
    this._silenceTimer = 0;
  }

  get ctx() {
    return this.host.ctx;
  }

  async start() {
    await this.host.start();
    document.addEventListener("play", this._onPlay, true);
    document.addEventListener("playing", this._onPlay, true);
    // 自动播放策略：没有用户手势时上下文是 suspended（Firefox 还单独拦 WebAudio）。媒体已经在播时不会再有 play 事件，
    // 所以页面里任何一次点击 / 按键（包括点我们的圆钮）都试着恢复，直到 running 为止
    this._onGesture = () => this._resume();
    for (const ev of ["pointerdown", "keydown", "touchstart"]) document.addEventListener(ev, this._onGesture, true);
    this._observer = new MutationObserver((muts) => {
      if (this.current && !this.current.paused) return;
      for (const m of muts) {
        for (const n of m.addedNodes) {
          if (!(n instanceof Element)) continue;
          const el = n.matches && n.matches(MEDIA_SEL) ? n : n.querySelector && n.querySelector(MEDIA_SEL);
          if (el) {
            this.attach(el);
            return;
          }
        }
      }
    });
    this._observer.observe(document.documentElement, { childList: true, subtree: true });
    const el = this.pick();
    if (el) this.attach(el);
    else this._warn("media.none");
    this._resume();
    return this;
  }

  /** 候选元素：正在播放 > 有数据且面积最大的视频 > 第一个。 */
  pick() {
    const all = [...document.querySelectorAll(MEDIA_SEL)].filter((el) => !this.failed.has(el));
    if (!all.length) return null;
    const playing = all.find((el) => !el.paused && !el.ended);
    if (playing) return playing;
    const area = (el) => (el.tagName === "VIDEO" ? Math.max(1, el.clientWidth * el.clientHeight) : 1);
    const ready = all.filter((el) => el.readyState > 0 || el.currentSrc);
    const pool = ready.length ? ready : all;
    return pool.sort((a, b) => area(b) - area(a))[0];
  }

  attach(el) {
    if (this.released || !el || this.failed.has(el)) return false;
    let node = this.nodes.get(el);
    if (!node) {
      try {
        node = this.ctx.createMediaElementSource(el);
      } catch (e) {
        this.failed.add(el);
        this._warn("media.cantAttach", { name: e.name });
        return false;
      }
      this.nodes.set(el, node);
    }
    // 之前直通到 destination 的（上次关插件时留下的）先断开，再接进引擎
    try {
      node.disconnect();
    } catch (_) {
      /* 未连接 */
    }
    this.current = el;
    this.host.connectNode(node, "element");
    this._clearWarn(["media.silent", "media.cantAttach", "media.none"]);
    this.log(`已接入 <${el.tagName.toLowerCase()}>${el.currentSrc ? " " + el.currentSrc.slice(0, 80) : ""}`);
    this._resume();
    return true;
  }

  _resume() {
    const ctx = this.ctx;
    if (!ctx || ctx.state === "running") return;
    ctx.resume().then(
      () => {
        this.log(`AudioContext 已恢复（${ctx.state}）`);
        this.host._emitState();
      },
      () => {}
    );
  }

  _onHostState(s) {
    // 引擎空闲（输入连续 3 s 全 0）而元素在播、时间在走 → 页内媒体无声（跨域 / 受保护）
    clearTimeout(this._silenceTimer);
    if (s.idle && this.current && !this.current.paused && !this.current.muted && this.current.volume > 0) {
      const t = this.current.currentTime;
      this._silenceTimer = setTimeout(() => {
        if (this.current && !this.current.paused && this.current.currentTime > t + 0.5 && this.host.idle) {
          this._warn("media.silent");
        }
      }, 1200);
    } else if (!s.idle) {
      this._clearWarn(["media.silent"]);
    }
    if (this.o.onState) this.o.onState(Object.assign({}, s, { warnings: this.allWarnings() }));
  }

  allWarnings() {
    return [...this.warnings.map((w) => t(w.key, w.vars)), ...this.host.warnings];
  }
  _warn(key, vars) {
    if (this.warnings.some((w) => w.key === key)) return;
    this.warnings.push({ key, vars });
    this.log(t(key, vars));
    this.host._emitState();
  }
  _clearWarn(keys) {
    const n = this.warnings.length;
    this.warnings = this.warnings.filter((w) => !keys.includes(w.key));
    if (this.warnings.length !== n) this.host._emitState();
  }

  /** 接入一个 UI 端点（协议）。 */
  attachUi(ep) {
    const detach = this.host.attach(ep);
    // 宿主的 state 消息不含本类的警告：补发一次
    ep.post({ type: "state", started: this.host.started, idle: this.host.idle, source: this.host.sourceKind, volume: this.host.volume, warnings: this.allWarnings() });
    return detach;
  }

  /**
   * 释放：元素接进 WebAudio 后回不去，所以不关上下文——把源直通到 destination，卸掉引擎（之后标签页捕获拿到的就是原声）。
   */
  async release() {
    if (this.released) return;
    this.released = true;
    document.removeEventListener("play", this._onPlay, true);
    document.removeEventListener("playing", this._onPlay, true);
    for (const ev of ["pointerdown", "keydown", "touchstart"]) document.removeEventListener(ev, this._onGesture, true);
    if (this._observer) this._observer.disconnect();
    clearTimeout(this._silenceTimer);
    const ctx = this.ctx;
    const node = this.current ? this.nodes.get(this.current) : null;
    this.host.disconnectSource();
    // 所有接过的元素（不只当前这个）都直通，别让切换过的元素哑掉
    for (const el of document.querySelectorAll(MEDIA_SEL)) {
      const n = this.nodes.get(el);
      if (n && n !== node) {
        try {
          n.disconnect();
          n.connect(ctx.destination);
        } catch (_) {
          /* 忽略 */
        }
      }
    }
    if (this.host.neo) {
      try {
        this.host.neo.destroy();
      } catch (_) {
        /* 已销毁 */
      }
      this.host.neo = null;
    }
    if (node && ctx) {
      try {
        node.connect(ctx.destination);
      } catch (_) {
        /* 已断开 */
      }
    }
    this.host.started = false;
    this.host._emitState();
    this.log("页内媒体宿主已释放（媒体直通）");
  }
}
