// Neo Audio — 虚拟舞台"高音质模式"的分离模型（阶段 4.5）：htdemucs（Demucs v4，MIT）导出的动态段长 ONNX，
// 由 tools/nn/export_htdemucs.py --dynamic 生成（STFT / iSTFT 在模型外）。不随插件包，第一次启用时从这里下载进 IndexedDB。
//
// 发布新模型：传到公开仓库 infohex/Neo-Audio-models 的 Releases（代码仓库是私有的，私有仓库的 Release 资源对插件的 fetch 是 404），
// 改这里的 url / size 与 key（key 变了旧缓存就不认，会重新下载）。
export const HQ_MODEL = Object.freeze({
  key: "htdemucs-dyn-fp32-v1",
  url: "https://github.com/infohex/Neo-Audio-models/releases/download/models-v1/htdemucs-dyn-fp32.onnx",
  size: 168_418_866,
  license: "MIT (Demucs v4, Meta Research)",
});
