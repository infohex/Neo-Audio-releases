// Neo Audio — 分离服务端（阶段 4.5，方案 B）：住在插件源的文档里（Chrome：offscreen 文档；Firefox：后台页），
// 替页面里的引擎跑分离 Worker。页面的 content script 用 runtime.connect({name: "neo-hq"}) 连进来，引擎本身留在页面里
// （页内媒体），不需要标签页捕获，开关舞台不刷新页面，全屏 / 画中画不受影响。
//
// Port 上的消息（content script ⇄ 这里，JSON）：
//   → {type:'init', device:'gpu'|'cpu', segmentMs, threads}   起 Worker（模型从本源的 IndexedDB 读）
//   ← {type:'ready', ep, threads, fallback, segment}            / {type:'error', code?:'nomodel', message}
//   → {type:'hops', index, hops, b64}                           连续 hops 跳的输入（hq-codec 编码）；{type:'hops', reset:true} = 队列重置，序号从 0 起
//   ← {type:'stems', index, hops, b64}                          定稿的声部块
//   ← {type:'stat', …}                                          每段一条（neo-hq-worker.js 的 stat）
//   → {type:'segment', segmentMs}                              在线换段长（不重起）；← {type:'segment', segment, warmMs}
//   → {type:'keepalive'}                                       每 10 s 一个，让 Firefox 事件页别被挂起（不处理）
//   → {type:'stop'}
// 断开 Port = 停 Worker。

import { encodeF32, decodeF32 } from "./hq-codec.js";

/**
 * @param {{modelStore:{bytes:()=>Promise<ArrayBuffer|null>}, workerUrl:string, coreUrl?:string, inline?:boolean, watchdogMs?:number, log?:(s:string)=>void}} o
 *   inline：不起 Worker，把分离核心（coreUrl，neo-hq-core.js）内联在当前文档的主线程跑；watchdogMs：Worker 模式下没 ready 就重起
 * 返回 { attach(port), count }。
 */
const MAX_ATTEMPTS = 3;

export function createHqServer(o) {
  const log = o.log || (() => {});
  const sessions = new Set();

  function stop(s) {
    s.gen++;
    if (s.worker) {
      try {
        s.worker.terminate();
      } catch (_) {
        /* 已停 */
      }
      s.worker = null;
    }
    if (s.ch) {
      s.ch.port1.onmessage = null;
      s.ch = null;
    }
  }

  function send(s, m) {
    try {
      s.port.postMessage(m);
    } catch (_) {
      /* 对端已断 */
    }
  }

  async function start(s, cfg, attempt = 1) {
    stop(s);
    const gen = s.gen;
    let model = null;
    try {
      model = await o.modelStore.bytes();
    } catch (e) {
      send(s, { type: "error", message: `读模型失败：${e.message}` });
      return;
    }
    if (gen !== s.gen) return;
    if (!model) {
      send(s, { type: "error", code: "nomodel", message: "分离模型还没下载" });
      return;
    }
    let worker;
    // 看门狗（Firefox，4.5b）：WebGPU 首次推理有时永远不回来（Worker 里、主线程里都见过，而且是随机的，重起一次就好）。
    // 没有 ready 就超时 → 杀掉 Worker 重起，最多 MAX_ATTEMPTS 次；主线程不会被卡住，所以只在 Worker 模式下用
    let watchdog = 0;
    const onOut = (m) => {
      if (!m) return;
      if (m.type === "ready" || m.type === "error") clearTimeout(watchdog);
      if (m.type === "ready" || m.type === "error" || m.type === "stat" || m.type === "note" || m.type === "segment") send(s, m);
      if (m.type === "error") log(`分离 Worker：${m.message}`);
    };
    try {
      if (o.inline) {
        // 内联：同一个文档里跑核心，用一个"假 Worker"对象保持下面的代码不变
        const { createSeparator } = await import(o.coreUrl);
        if (gen !== s.gen) return;
        const sep = createSeparator({ post: onOut });
        worker = { postMessage: (m) => sep.handle(m), terminate: () => sep.dispose() };
      } else {
        worker = new Worker(o.workerUrl, { type: "module" });
        worker.onmessage = (e) => onOut(e.data);
        worker.onerror = (e) => send(s, { type: "error", message: e && e.message ? e.message : "分离 Worker 脚本加载失败" });
      }
    } catch (e) {
      send(s, { type: "error", message: `起不了分离 Worker：${e.message}` });
      return;
    }
    const ch = new MessageChannel();
    ch.port1.onmessage = (e) => {
      const d = e.data;
      if (!d || typeof d.index !== "number" || !d.buf) return;
      send(s, { type: "stems", index: d.index, hops: d.hops, b64: encodeF32(d.buf) });
    };
    worker.postMessage({ type: "init", model, device: cfg.device || "gpu", segmentMs: cfg.segmentMs || 500, threads: cfg.threads || 1 }, [model]);
    worker.postMessage({ type: "port", port: ch.port2 }, [ch.port2]);
    s.worker = worker;
    s.ch = ch;
    if (!o.inline && o.watchdogMs) {
      watchdog = setTimeout(() => {
        if (gen !== s.gen) return;
        if (attempt < MAX_ATTEMPTS) {
          log(`分离 Worker ${o.watchdogMs / 1000} s 没就绪，重起（${attempt + 1}/${MAX_ATTEMPTS}）`);
          send(s, { type: "note", text: `分离 ${o.watchdogMs / 1000} s 没就绪，重起（${attempt + 1}/${MAX_ATTEMPTS}）…` });
          start(s, cfg, attempt + 1).catch((e) => send(s, { type: "error", message: e.message }));
        } else {
          stop(s);
          send(s, { type: "error", message: `分离 ${MAX_ATTEMPTS} 次都没就绪（WebGPU 首次推理不返回），请关掉再开舞台` });
        }
      }, o.watchdogMs);
    }
  }

  function attach(port) {
    const s = { port, worker: null, ch: null, gen: 0 };
    sessions.add(s);
    port.onMessage.addListener((m) => {
      if (!m || !m.type) return;
      if (m.type === "init") start(s, m).catch((e) => send(s, { type: "error", message: e.message }));
      else if (m.type === "hops") {
        if (!s.ch) return;
        if (m.reset) s.ch.port1.postMessage({ reset: true });
        else if (typeof m.b64 === "string") s.ch.port1.postMessage({ index: m.index, hops: m.hops, buf: decodeF32(m.b64) });
      } else if (m.type === "segment") {
        if (s.worker) s.worker.postMessage({ type: "segment", segmentMs: m.segmentMs });
      } else if (m.type === "stop") stop(s);
      // keepalive：content script 每 10 s 发一个，只为让 Firefox 的事件页别因 30 s 没消息被挂起（端口会全断），不用处理
    });
    port.onDisconnect.addListener(() => {
      stop(s);
      sessions.delete(s);
    });
    log(`分离通道连入（共 ${sessions.size} 条）`);
  }

  return {
    attach,
    get count() {
      return sessions.size;
    },
  };
}
