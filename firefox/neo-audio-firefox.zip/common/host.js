// Neo Audio — 引擎宿主（阶段 3.1）。
//
// 持有 AudioContext 与一个 NeoAudio（wasm 实例 ①：worklet 引擎；其主线程实例只做分析器，灯板在 UI 侧），
// 对外只讲 protocol.js 的消息。谁来连都行：同一页面的 UI（测试页）、content script 的面板、独立窗口。
// 显示帧只发给打开了显示屏的端点；没人要时让 worklet 停发（省 CPU）。
//
// 用法（页内）：
//   const host = new EngineHost({ module, wasmUrl, workletUrl, makeContext: () => new AudioContext() });
//   await host.start({ fftSize: 4096 });
//   host.attach(channel.host);
//   host.connectElement(audioEl);

import { NeoAudio, MODULE, ERR } from "../shared/neo-audio-node.js";
import { MSG } from "./protocol.js";
import { HQ_MODEL } from "./hq-model.js";

const DISPLAY_OFF_INTERVAL_MS = 1e9; // 等于"不发"：worklet 按块数计数，1e9 ms 永远到不了

export class EngineHost {
  /**
   * @param {{module?:WebAssembly.Module, wasmUrl?:string, workletUrl:string, makeContext?:()=>AudioContext, neoOpts?:object, modelStore?:object, log?:(s:string)=>void}} o
   *   modelStore：虚拟舞台分离模型的缓存（common/model-store.js 的 ModelStore）；没有就只能 nomodel
   */
  constructor(o) {
    this.module = o.module || null;
    this.wasmUrl = o.wasmUrl || null;
    this.workletUrl = o.workletUrl;
    this.makeContext = o.makeContext || (() => new AudioContext());
    this.neoOpts = Object.assign({ fftSize: 4096, curvePoints: 256, displayIntervalMs: 33 }, o.neoOpts || {});
    this.modelStore = o.modelStore || null;
    if (this.modelStore) {
      this.neoOpts.hqModel = () => this.modelStore.bytes();
      const prev = this.modelStore.onState; // 同一个 store 可能被几个宿主 / 文档共用：串起来，别覆盖
      this.modelStore.onState = (st) => {
        if (prev) prev(st);
        this._broadcast(this._hqMsg());
        // 模型刚就绪而模块正开着在等它（页内媒体下下载经 SW 异步回来，不走 _hqOp 的回调）→ 直接起分离
        if (st.state === "ready" && this.neo && (this.neo.hqInfo.state === "nomodel" || this.neo.hqInfo.state === "failed")) this.neo.restartHq();
      };
      this.modelStore.status().catch(() => {});
    }
    this.log = o.log || (() => {});
    this.ctx = null;
    this.neo = null;
    this.gain = null; // 引擎之后的总音量（标签页被捕获后页面自己的音量控制失效，由这里补上）
    this.volume = 1;
    this.source = null; // 当前接进引擎的源节点
    this.sourceKind = "none"; // none | element | node | tab
    this.started = false;
    this.idle = false;
    this.warnings = [];
    this._eps = new Set(); // 已连接的端点：{ep, display:boolean, detach}
    this._lastFrame = null;
    this.frameCount = 0; // 发出的显示帧数（自动化核对显示屏开关用）
    this.onState = null; // (state) => void：宿主自己的观察者（测试页状态栏）
  }

  /** 建 AudioContext 与 worklet 引擎。fftSize 等覆盖构造时的 neoOpts。 */
  async start(opts = {}) {
    if (this.started) return this.neo;
    Object.assign(this.neoOpts, opts);
    if (!this.module) this.module = await NeoAudio.loadModule(this.wasmUrl);
    this.ctx = this.makeContext();
    const neo = await NeoAudio.create(this.ctx, Object.assign({ module: this.module, wasmUrl: this.wasmUrl, workletUrl: this.workletUrl }, this.neoOpts));
    this.neo = neo;
    this.started = true;
    this.gain = this.ctx.createGain();
    this.gain.gain.value = this.volume;
    this.gain.connect(this.ctx.destination);
    this._idleIntervalMs = neo.opts.idleIntervalMs; // 显示屏关时改成"不发"，开回来要还原
    neo.onError = (e) => {
      this.log(`worklet 错误: ${e.message}`);
      this._broadcast({ type: MSG.ERROR, message: e.message });
    };
    neo.onIdle = (on) => {
      this.idle = on;
      this._broadcast({ type: MSG.IDLE, on });
      this._emitState();
    };
    neo.onDisplay = (d) => {
      this._lastFrame = d;
      this.frameCount++;
      for (const e of this._eps) if (e.display) e.ep.post({ type: MSG.FRAME, d });
    };
    neo.onHq = (info) => {
      if (info.error && info.error !== this._lastHqError) {
        this._lastHqError = info.error;
        this.log(`虚拟舞台分离：${info.error}`);
      }
      this._broadcast(this._hqMsg());
    };
    this._applyDisplayInterval();
    for (const e of this._eps) e.ep.post(this._readyMsg());
    this._emitState();
    return neo;
  }

  /** 关掉引擎与上下文（重建采样率 / 关闭插件时）。端点保留，重新 start 后会再收到 ready。 */
  async destroy() {
    this.disconnectSource();
    if (this.neo) {
      try {
        this.neo.destroy();
      } catch (_) {
        /* 已销毁 */
      }
    }
    this.neo = null;
    this.gain = null;
    if (this.ctx) {
      try {
        await this.ctx.close();
      } catch (_) {
        /* 已关闭 */
      }
    }
    this.ctx = null;
    this.started = false;
    this.idle = false;
    this._lastFrame = null;
    this._emitState();
  }

  get sampleRate() {
    return this.ctx ? this.ctx.sampleRate : 0;
  }
  get latency() {
    return this.neo ? this.neo.latency : 0;
  }

  // ---- 源 ----

  /** 把页面里的 <audio>/<video> 接进引擎（同一元素只能接一次，这是 WebAudio 的规则）。 */
  connectElement(el) {
    if (!this.started) throw new Error("宿主未启动");
    this.disconnectSource();
    try {
      this.source = this.ctx.createMediaElementSource(el);
    } catch (e) {
      this._warn(`媒体元素无法接入：${e.message}`);
      throw e;
    }
    this.sourceKind = "element";
    this.source.connect(this.neo.node);
    this.neo.node.connect(this.gain);
    this._emitState();
    return this.source;
  }

  /** 接一个现成的源节点（MediaStreamSource 等；tabCapture 走这里）。 */
  connectNode(node, kind = "node") {
    if (!this.started) throw new Error("宿主未启动");
    this.disconnectSource();
    this.source = node;
    this.sourceKind = kind;
    node.connect(this.neo.node);
    this.neo.node.connect(this.gain);
    this._emitState();
    return node;
  }

  disconnectSource() {
    if (this.source) {
      try {
        this.source.disconnect();
      } catch (_) {
        /* 已断开 */
      }
    }
    this.source = null;
    this.sourceKind = "none";
  }

  // ---- 端点 ----

  /** 接入一个 UI 端点；返回断开函数。 */
  attach(ep) {
    const e = { ep, display: false };
    this._eps.add(e);
    ep.onMessage((m) => this._handle(e, m));
    const detach = () => {
      this._eps.delete(e);
      ep.onMessage(null);
      this._applyDisplayInterval();
    };
    e.detach = detach;
    return detach;
  }

  /** 是否有端点在要显示帧。 */
  get displayWanted() {
    for (const e of this._eps) if (e.display) return true;
    return false;
  }

  _handle(e, m) {
    if (!m || !m.type) return;
    const neo = this.neo;
    switch (m.type) {
      case MSG.HELLO:
        e.ep.post(this.started ? this._readyMsg() : this._stateMsg());
        e.ep.post(this._hqMsg());
        break;
      case MSG.DISPLAY:
        e.display = !!m.on;
        this._applyDisplayInterval(m.intervalMs);
        break;
      case MSG.SET:
        if (neo) neo.setParam(m.module, m.index, m.field, m.value);
        break;
      case MSG.GET:
        if (!neo) {
          e.ep.post({ type: MSG.GOT, id: m.id, value: NaN, error: ERR.NOT_INITIALIZED });
          break;
        }
        neo
          .getParam(m.module, m.index, m.field)
          .then((value) => e.ep.post({ type: MSG.GOT, id: m.id, value, error: ERR.OK }))
          .catch((err) => e.ep.post({ type: MSG.GOT, id: m.id, value: NaN, error: parseErr(err) }));
        break;
      case MSG.ENABLE:
        if (neo) neo.setModuleEnabled(m.module, m.on);
        break;
      case MSG.GET_ENABLED:
        if (!neo) {
          e.ep.post({ type: MSG.GOT, id: m.id, value: NaN, error: ERR.NOT_INITIALIZED });
          break;
        }
        neo
          .getModuleEnabled(m.module)
          .then((on) => e.ep.post({ type: MSG.GOT, id: m.id, value: on ? 1 : 0, error: ERR.OK }))
          .catch((err) => e.ep.post({ type: MSG.GOT, id: m.id, value: NaN, error: parseErr(err) }));
        break;
      case MSG.LAYOUT:
        if (neo) neo.setLayout(m.module, m.freqs);
        break;
      case MSG.FFT:
        if (neo) {
          const r = neo.setFftSize(m.fftSize, m.curvePoints || this.neoOpts.curvePoints);
          if (r !== ERR.OK) this.log(`FFT 点数设置失败: ${r}`);
          else {
            this.neoOpts.fftSize = m.fftSize;
            this._applyDisplayInterval();
          }
        }
        break;
      case MSG.APPLY:
        this.applyOps(m.ops || []);
        break;
      case MSG.CLEAR_CLIP:
        if (neo) neo.clearClip();
        break;
      case MSG.VOLUME:
        this.setVolume(m.value);
        break;
      case MSG.HQ:
        this._hqOp(m.op, e);
        break;
      default:
        break;
    }
  }

  /** 虚拟舞台的分离模型 / Worker 操作（阶段 4.5）。 */
  _hqOp(op, e) {
    const store = this.modelStore;
    const neo = this.neo;
    const reply = () => e.ep.post(this._hqMsg());
    switch (op) {
      case "status":
        if (store) store.status().then(reply, reply);
        else reply();
        break;
      case "download":
        if (!store) {
          reply();
          break;
        }
        store.download().then((s) => {
          // 下载好了而模块正开着（在等模型）→ 直接起 Worker
          if (s.state === "ready" && neo && (neo.hqInfo.state === "nomodel" || neo.hqInfo.state === "failed")) neo.restartHq();
        });
        break;
      case "cancel":
        if (store) store.cancel();
        break;
      case "delete":
        if (neo) neo.stopHq();
        if (store) store.delete().then(reply, reply);
        else reply();
        break;
      case "restart":
        if (neo) neo.restartHq();
        break;
      default:
        break;
    }
  }

  _hqMsg() {
    const store = this.modelStore;
    return {
      type: MSG.HQ,
      // 没有模型缓存的宿主（Chrome 的页内媒体宿主、Firefox）：报"未下载"，下载由面板先切到标签页捕获再发给 offscreen 宿主
      model: store ? Object.assign({}, store.state) : { state: "none", loaded: 0, total: HQ_MODEL.size, error: null, noStore: true },
      engine: this.neo ? Object.assign({}, this.neo.hqInfo) : { state: "off" },
    };
  }

  /** 总音量 0…1（20 ms 平滑）。 */
  setVolume(v) {
    v = Math.max(0, Math.min(1, Number(v)));
    if (!Number.isFinite(v)) return;
    this.volume = v;
    if (this.gain) this.gain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02);
  }

  /** 整份设置一次下发：先开关再参数（模块 11 不在音频链上，UI 侧自己管，这里忽略）。 */
  applyOps(ops) {
    const neo = this.neo;
    if (!neo) return;
    for (const op of ops) if (op.t === "enable") neo.setModuleEnabled(op.m, !!op.on);
    for (const op of ops) if (op.t === "set" && op.m !== MODULE.DISPLAY) neo.setParam(op.m, op.i || 0, op.f, op.v);
  }

  _applyDisplayInterval(intervalMs) {
    if (!this.neo) return;
    const on = this.displayWanted;
    const ms = on ? intervalMs || this.neoOpts.displayIntervalMs : DISPLAY_OFF_INTERVAL_MS;
    this.neo.setDisplayInterval(ms, on ? this._idleIntervalMs : DISPLAY_OFF_INTERVAL_MS);
  }

  _readyMsg() {
    return {
      type: MSG.READY,
      sampleRate: this.sampleRate,
      latency: this.latency,
      fftSize: this.neoOpts.fftSize,
      curvePoints: this.neoOpts.curvePoints,
      source: this.sourceKind,
      volume: this.volume,
    };
  }
  _stateMsg() {
    return { type: MSG.STATE, started: this.started, idle: this.idle, source: this.sourceKind, volume: this.volume, ctxState: this.ctx ? this.ctx.state : "closed", warnings: this.warnings.slice() };
  }
  _emitState() {
    const s = this._stateMsg();
    this._broadcast(s);
    if (this.onState) this.onState(s);
  }
  _broadcast(msg) {
    for (const e of this._eps) e.ep.post(msg);
  }
  _warn(text) {
    this.warnings.push(text);
    if (this.warnings.length > 8) this.warnings.shift();
    this.log(text);
    this._emitState();
  }
}

function parseErr(err) {
  const m = /(-?\d+)/.exec(err && err.message ? err.message : "");
  return m ? parseInt(m[1], 10) : ERR.BAD_VALUE;
}
