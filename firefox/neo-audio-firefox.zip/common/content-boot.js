// Neo Audio — content script 引导（阶段 3.2 / 3.4）：Chrome 与 Firefox 同一份（manifest 指到 common/content-boot.js）。
//
// 每个 http(s) 页面都注入这一小段，但什么都不做，直到 service worker 说"这个标签页开了"（neo-activate，
// 或页面刚加载时查询 neo-query 得到 active）。那时按首选音源启动：
//   element：页内媒体宿主（common/media-host.js）就在本页，把 <video>/<audio> 接进引擎；页面全屏 / 音量 / 画中画不受影响（默认）
//   tab：    请 service worker 做 tabCapture，引擎在 offscreen 文档里（被捕获的标签页全屏只占浏览器窗口，Chrome 的规则）
// 然后动态 import 面板模块（common/ui/panel.js）挂出页底圆钮；面板头上可切换音源。只在顶层 frame 运行。

(function neoBoot() {
  if (window.__neoAudio) return;
  // 预渲染中的文档（YouTube 用 Speculation Rules 预渲染下一条视频页）：等它真的显示出来再启动，
  // 预渲染状态下加载扩展资源会被浏览器拒绝
  if (document.prerendering) {
    document.addEventListener("prerenderingchange", () => neoBoot(), { once: true });
    return;
  }
  const api = { mod: null, mediaMod: null, panel: null, pageHost: null, mode: null, activating: null, canCapture: false, log: (t) => console.debug("[Neo Audio]", t) };
  window.__neoAudio = api;
  const url = (p) => chrome.runtime.getURL(p);
  // 虚拟舞台的分离（方案 B，BO 2026-10-16）：引擎留在页面里，分离 Worker 在插件源的文档（Chrome：offscreen；Firefox：后台页），
  // 音频跳经 runtime.Port 来回（hq-codec 编码）——不需要标签页捕获，开关舞台不刷新页面
  const NEO_OPTS = { fftSize: 4096, curvePoints: 256, waveColumns: 16, scopeFrames: 2048, displayIntervalMs: 33, hqTransport: remoteHqTransport }; // 4096：低频分辨率 11.7 Hz，60 Hz 一带的柱才分得开（BO）

  // 音源不再有用户偏好（面板上的选项去掉了，方案 B，BO 2026-10-16；以前设置里存过的 extras.source 一律忽略）：
  // 页面上有 <video>/<audio> 就页内媒体；没有媒体元素的页面（纯 WebAudio 站点）才用标签页捕获；引擎被 CSP 挡住时也自动退到捕获。
  // file:// 页面（Chrome 直接打开本地 MP3 / 视频）：file 源是不透明的，媒体元素一接进 WebAudio 就只输出零（"页内媒体无声"），
  // 而且接过就不能再切捕获（docs/phase4-06），所以一开始就走标签页捕获（BO 2026-10-17）；舞台在捕获宿主里照常跑
  async function preferredSource() {
    if (location.protocol === "file:" && api.canCapture) return "tab";
    return document.querySelector("video, audio") || !api.canCapture ? "element" : "tab";
  }

  /** 远程分离通道（接口见 neo-audio-node.js 的 localHqTransport）：先让 SW 把 offscreen 起来，再 connect("neo-hq")。 */
  async function remoteHqTransport() {
    const codec = await import(url("common/hq-codec.js"));
    const prep = await chrome.runtime.sendMessage({ type: "neo-hq-prepare" });
    if (!prep || !prep.ok) throw new Error((prep && prep.error) || "分离服务起不来");
    const rp = chrome.runtime.connect({ name: "neo-hq" });
    const ch = new MessageChannel();
    let pending = null;
    // Firefox 的后台是事件页：30 s 没收到消息就被挂起，端口随之全断（预热那十几秒没跳可发、CPU 跟不上时跳被跳过不发，都会静默
    // 超过 30 s → "分离通道断开"）。端口只是连着救不了它，得有消息进去：每 10 s 发一个 keepalive（服务端不理）。Chrome 无害
    const keepalive = setInterval(() => {
      try {
        rp.postMessage({ type: "keepalive" });
      } catch (_) {
        clearInterval(keepalive);
      }
    }, 10000);
    const tr = {
      port: ch.port1,
      onMessage: null,
      init(cfg) {
        return new Promise((resolve, reject) => {
          pending = { resolve, reject, timer: setTimeout(() => { pending = null; reject(new Error("分离服务加载模型超时")); }, 600000) };
          rp.postMessage(Object.assign({ type: "init" }, cfg));
        });
      },
      terminate() {
        clearInterval(keepalive);
        try {
          rp.disconnect();
        } catch (_) {
          /* 已断 */
        }
        ch.port2.close();
      },
      send(m) {
        try {
          rp.postMessage(m);
        } catch (_) {
          /* 已断 */
        }
      },
    };
    rp.onMessage.addListener((m) => {
      if (!m || !m.type) return;
      if (m.type === "stems") {
        if (typeof m.b64 === "string") ch.port2.postMessage({ index: m.index, hops: m.hops, buf: codec.decodeF32(m.b64) });
        return;
      }
      if (pending && m.type !== "ready" && m.type !== "error") {
        if (tr.onMessage) tr.onMessage(m); // 启动中的 note
        return;
      }
      if (pending && (m.type === "ready" || m.type === "error")) {
        const pd = pending;
        pending = null;
        clearTimeout(pd.timer);
        if (m.type === "ready") pd.resolve(m);
        else {
          const e = new Error(m.message || "分离服务出错");
          e.code = m.code;
          pd.reject(e);
        }
        return;
      }
      if (tr.onMessage) tr.onMessage(m);
    });
    rp.onDisconnect.addListener(() => {
      clearInterval(keepalive);
      if (pending) {
        const pd = pending;
        pending = null;
        clearTimeout(pd.timer);
        pd.reject(new Error("分离通道断开"));
      } else if (tr.onMessage) tr.onMessage({ type: "error", message: "分离通道断开（插件重载？）" });
    });
    ch.port2.onmessage = (e) => {
      const d = e.data;
      if (!d) return;
      if (d.reset) rp.postMessage({ type: "hops", reset: true }); // 队列重置标记：与跳同一条路，顺序不乱
      else if (d.buf && typeof d.index === "number") rp.postMessage({ type: "hops", index: d.index, hops: d.hops, b64: codec.encodeF32(d.buf) });
    };
    return tr;
  }

  // 页内媒体下的分离模型缓存代理：真正的下载 / 缓存在插件源的文档（Chrome：offscreen，经 SW 转发；Firefox：后台页自己）；
  // 进度由 SW 用 neo-model-state 推回。页内宿主起不了分离 Worker，所以不提供字节（bytes 永远 null → 面板显示"等模型 / 需要标签页捕获"）
  const remoteStore = {
    state: { state: "none", loaded: 0, total: 0, error: null },
    onState: null,
    _poll: 0,
    _set(st) {
      Object.assign(remoteStore.state, st);
      if (remoteStore.onState) remoteStore.onState(remoteStore.state);
      // 下载中每秒问一次状态：进度推送（neo-model-state）靠 SW 的"已激活标签页"名单，自检页 / 没经 SW 激活的页面收不到
      if (remoteStore.state.state === "downloading" && !remoteStore._poll) remoteStore._poll = setInterval(() => remoteStore._op("status"), 1000);
      if (remoteStore.state.state !== "downloading" && remoteStore._poll) {
        clearInterval(remoteStore._poll);
        remoteStore._poll = 0;
      }
    },
    _op(op) {
      return chrome.runtime.sendMessage({ type: "neo-model", op }).then(
        (r) => {
          if (r && r.state) remoteStore._set(r.state);
          return remoteStore.state;
        },
        () => remoteStore.state
      );
    },
    status: () => remoteStore._op("status"),
    download: () => remoteStore._op("download"),
    cancel: () => remoteStore._op("cancel"),
    delete: () => remoteStore._op("delete"),
    bytes: () => Promise.resolve(null),
  };

  // ---- 音源
  async function startSource(mode) {
    if (mode === "element") {
      if (!api.mediaMod) api.mediaMod = await import(url("common/media-host.js"));
      const host = new api.mediaMod.PageMediaHost({ wasmUrl: url("dsp_wasm.wasm"), workletUrl: url("shared/neo-audio-processor.js"), neoOpts: NEO_OPTS, log: api.log, modelStore: remoteStore }); // 模型缓存代理：Chrome 经 SW → offscreen，Firefox 后台页自己管
      await host.start();
      api.pageHost = host;
      api.mode = "element";
      return { ok: true };
    }
    const r = await chrome.runtime.sendMessage({ type: "neo-capture", on: true });
    if (!r || !r.ok) throw new Error((r && r.error) || "标签页捕获失败");
    api.mode = "tab";
    return r;
  }
  async function stopSource() {
    if (api.mode === "element" && api.pageHost) {
      await api.pageHost.release();
      api.pageHost = null;
    } else if (api.mode === "tab") {
      await chrome.runtime.sendMessage({ type: "neo-capture", on: false }).catch(() => {});
    }
    api.mode = null;
  }
  /** 切换音源：先停旧的再起新的；标签页捕获失败（无用户手势 / 受限页面）退回页内媒体并告诉面板。 */
  async function setSource(mode) {
    if (mode === api.mode) return { ok: true, mode };
    if (mode === "tab" && !api.canCapture) return { ok: false, mode: api.mode, error: "unsupported" };
    await stopSource();
    try {
      await startSource(mode);
      return { ok: true, mode: api.mode };
    } catch (e) {
      api.log(`音源切换到 ${mode} 失败：${e.message}`);
      if (mode !== "element") await startSource("element");
      api.lastSourceError = { key: "source.tabFailed", detail: e.message };
      return { ok: false, mode: api.mode, error: e.message };
    }
  }

  function env() {
    return {
      assetUrl: url,
      wasmUrl: url("dsp_wasm.wasm"),
      // 面板 → 宿主：页内模式是同页通道；标签页模式是到 offscreen 的 runtime.Port（面板用 wrapJsonPort 包）
      connect: (onDisconnect) => {
        if (api.mode === "element" && api.pageHost) {
          const host = api.pageHost;
          return { kind: "local", attach: (ep) => host.attachUi(ep) }; // 面板自己建同页通道
        }
        const port = chrome.runtime.connect({ name: "neo-ui" });
        port.onDisconnect.addListener(() => onDisconnect && onDisconnect());
        return port;
      },
      getSource: () => api.mode,
      hqCpu: () => api.cpuSeparation !== false, // 分离的 CPU 模式可用吗（Firefox 后台页没有多线程 wasm → 不可用）
      // 系统占用（CPU% / 内存）：SW 用 chrome.system.* 取。最多等 1.5 s：SW 没回话不能把面板的只读轮询吊死
      sysInfo: () => Promise.race([chrome.runtime.sendMessage({ type: "neo-sys" }), new Promise((r) => setTimeout(() => r(null), 1500))]).catch(() => null),
      // Firefox 没有 chrome.system.*（neo-query 回 sysInfo:false）：两格留着、写"不支持"并说明原因（BO 2026-10-16：格子不能没了）
      sysAvail: () => api.sysInfo !== false,
      getSourceError: () => {
        const e = api.lastSourceError;
        api.lastSourceError = null;
        return e;
      },
      setSource: api.canCapture ? setSource : undefined, // Firefox 没有标签页捕获：面板不显示音源开关
      onStop: () => chrome.runtime.sendMessage({ type: "neo-stop" }).catch(() => {}),
      // 换语言：文字烤在 DOM 里，整个面板重建（引擎不动）
      remount: async () => {
        const wasOpen = !!(api.panel && api.panel.state.open);
        if (api.panel) api.panel.unmount();
        api.panel = await api.mod.mountPanel(env());
        if (wasOpen) api.panel.open();
      },
      log: api.log,
    };
  }

  async function activate() {
    if (api.panel) return api.panel;
    if (!api.activating) {
      api.activating = (async () => {
        try {
          const q = await chrome.runtime.sendMessage({ type: "neo-query" });
          api.canCapture = !!(q && q.canCapture);
          api.cpuSeparation = !q || q.cpuSeparation !== false;
          api.sysInfo = !!(q && q.sysInfo);
        } catch (_) {
          api.canCapture = false;
        }
        const mode = await preferredSource();
        try {
          await startSource(mode);
        } catch (e) {
          api.log(`音源 ${mode} 启动失败：${e.message}`);
          if (mode !== "element") {
            await startSource("element");
            api.lastSourceError = { key: "source.tabFailed", detail: e.message };
          } else if (api.canCapture) {
            // 页内引擎起不来（典型：页面 CSP 的 script-src 没有 'wasm-unsafe-eval'，WebAssembly.compile 被挡）
            // → 退回标签页捕获：引擎在扩展自己的 offscreen 文档里，不受页面 CSP 约束（BO 2026-10-14：确保其它网站可激活）
            try {
              await startSource("tab");
              api.lastSourceError = { key: "source.elementFailed", detail: e.message };
            } catch (e2) {
              throw new Error(`页内引擎与标签页捕获都失败：${e.message}；${e2.message}`);
            }
          } else {
            throw e;
          }
        }
        try {
          if (!api.mod) api.mod = await import(url("common/ui/panel.js"));
        } catch (e) {
          // 诊断（BO 2026-10-14：YouTube 上偶发 "Unsafe attempt to load URL chrome-extension://…"）：把当时的页面状态记下来
          const nav = performance.getEntriesByType("navigation")[0];
          console.warn("[Neo Audio] 面板模块加载失败", e.message, {
            href: location.href.slice(0, 120),
            runtimeId: alive() ? chrome.runtime.id : "(失效)",
            prerendering: !!document.prerendering,
            visibility: document.visibilityState,
            readyState: document.readyState,
            activationStart: nav ? nav.activationStart : null,
            navType: nav ? nav.type : null,
            frames: window.length,
            top: window === window.top,
            origin: location.origin,
            domain: document.domain,
            hasFocus: document.hasFocus(),
            sinceLoad: Math.round(performance.now()),
          });
          throw e;
        }
        api.panel = await api.mod.mountPanel(env());
        return api.panel;
      })().finally(() => {
        api.activating = null;
      });
    }
    return api.activating;
  }

  async function deactivate() {
    if (api.panel) {
      api.panel.unmount();
      api.panel = null;
    }
    await stopSource();
  }

  // 扩展重载 / 更新后，旧的 content script 还留在页面里（Chrome 不会替它收尸）：它的 chrome.runtime.id 变成 undefined，
  // 再去 import 扩展资源会在页面控制台报 "Unsafe attempt to load URL chrome-extension://…"。这里一律先验身份：
  // 失效就把自己收干净（卸面板、把音频交还给页面）并不再响应任何消息。
  const alive = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  };
  let orphaned = false;
  function orphan() {
    if (orphaned) return;
    orphaned = true;
    try {
      if (api.panel) api.panel.unmount();
    } catch (_) {
      /* 已经没了 */
    }
    api.panel = null;
    stopSource().catch(() => {});
    try {
      delete window.__neoAudio;
    } catch (_) {
      /* 忽略 */
    }
    console.debug("[Neo Audio] 扩展已重载，这份旧的页内脚本已退出；重新点工具栏图标即可");
  }
  // 长连接当探针：扩展重载时端口断开；SW 空闲被杀也会断开，所以断开后再看 runtime.id 才下结论
  function watchRuntime() {
    try {
      const port = chrome.runtime.connect({ name: "neo-alive" });
      port.onDisconnect.addListener(() => {
        if (!alive()) orphan();
        else setTimeout(watchRuntime, 1000);
      });
    } catch (_) {
      if (!alive()) orphan();
    }
  }
  watchRuntime();

  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (!m || !m.type) return false;
    if (orphaned || !alive()) {
      orphan();
      return false;
    }
    switch (m.type) {
      case "neo-activate":
        activate().then(() => reply({ ok: true }), (e) => reply({ ok: false, error: e.message }));
        return true;
      case "neo-deactivate":
        deactivate().then(() => reply({ ok: true }));
        return true;
      case "neo-model-state":
        remoteStore._set(m.state || {});
        return false;
      // 自动化探针：当前模式与引擎状态；读回参数（页内模式直接读本页宿主，标签页模式转 offscreen）
      case "neo-status": {
        const h = api.pageHost ? api.pageHost.host : null;
        if (api.mode === "element" && h) {
          reply({ mode: api.mode, started: h.started, source: h.sourceKind, displayWanted: h.displayWanted, volume: h.volume, sampleRate: h.sampleRate, frames: h.frameCount, media: api.pageHost.current ? api.pageHost.current.tagName.toLowerCase() : null, warnings: api.pageHost.allWarnings(), panel: !!api.panel });
          return false;
        }
        chrome.runtime.sendMessage({ to: "offscreen", type: "status" }).then((r) => reply(Object.assign({ mode: api.mode, panel: !!api.panel }, r)), () => reply({ mode: api.mode, panel: !!api.panel }));
        return true;
      }
      case "neo-probe": {
        if (m.op === "display") {
          reply(displayProbe());
          return false;
        }
        const h = api.pageHost ? api.pageHost.host : null;
        if (api.mode === "element" && h && h.neo) {
          if (m.op === "set") {
            reply({ value: h.neo.setParam(m.module, m.index || 0, m.field, m.value) });
            return false;
          }
          if (m.op === "hq") {
            reply({ value: Object.assign({}, h.neo.hqInfo) });
            return false;
          }
          const p = m.op === "enabled" ? h.neo.getModuleEnabled(m.module) : h.neo.getParam(m.module, m.index || 0, m.field);
          p.then((value) => reply({ value }), (err) => reply({ error: err.message }));
          return true;
        }
        chrome.runtime.sendMessage(Object.assign({ to: "offscreen", type: "probe" }, m, { type: "probe" })).then(reply, (e) => reply({ error: e.message }));
        return true;
      }
      default:
        return false;
    }
  });

  /**
   * 显示链路探针：渲染后端、GL 状态、画布尺寸与可见性、显示屏参数、重画一次后画布里的亮像素数、帧数、报错。
   * 本机自检页经 neoDev:"probe" 用；任何站点可从插件后台控制台调：__neo.probe(tabId, { op: "display" })
   * （Firefox：about:debugging → 此插件 → 检查）。onParam(v)：主线程 → worklet 的参数读回（异步，1.5 s 超时）。
   */
  function displayProbe(onParam) {
    const r = {};
    if (!api.panel) {
      r.error = "面板未挂载";
      return r;
    }
    try {
      const p = api.panel;
      const cv = p.$("display");
      r.renderer = p.vfd.rendererName();
      const glr = p.vfd.glRenderer();
      if (glr && glr.gl) {
        const gl = glr.gl;
        const at = gl.getContextAttributes ? gl.getContextAttributes() : null;
        r.gl = { version: gl.getParameter(gl.VERSION), lost: gl.isContextLost(), error: gl.getError(), buffer: [gl.drawingBufferWidth, gl.drawingBufferHeight], attrs: at ? { alpha: at.alpha, premultipliedAlpha: at.premultipliedAlpha, preserveDrawingBuffer: at.preserveDrawingBuffer, antialias: at.antialias } : null, pageCtx: !!(cv.wrappedJSObject && gl.wrappedJSObject === undefined) };
      }
      r.open = p.state.open;
      r.displayOn = p.state.neo ? p.state.neo.displayOn : null;
      r.frames = p.state.neo ? p.state.neo.frameCount : -1;
      r.hostFrames = api.pageHost ? api.pageHost.host.frameCount : -1;
      r.ctxState = api.pageHost && api.pageHost.ctx ? api.pageHost.ctx.state : null;
      if (p.state.neo && onParam) {
        Promise.race([p.state.neo.getParam(2, 3, 0), new Promise((res) => setTimeout(() => res("timeout"), 1500))]).then(onParam);
      }
      r.lastDisplay = !!p.state.lastDisplay;
      if (p.state.lastDisplay) r.peak = Math.round(Math.max(...Array.from(p.state.lastDisplay.barsDb)));
      // 显示屏参数（BO 本机的保存值可能与自检默认值不同）
      r.params = { theme: p.state.theme, glow: p.state.glowAmount, afterglowMs: p.state.afterglowMs, spill: p.state.spillAmount, bezel: p.state.bezelPx, view: p.state.viewMode, scale: p.state.barScale, uiTheme: p.state.uiTheme, panelW: p.state.panelW };
      // 画布在页面里的尺寸与可见性
      const rc = cv.getBoundingClientRect();
      const cs = getComputedStyle(cv);
      r.canvas = { backing: [cv.width, cv.height], css: [Math.round(rc.width), Math.round(rc.height)], at: [Math.round(rc.left), Math.round(rc.top)], dpr: window.devicePixelRatio, opacity: cs.opacity, visibility: cs.visibility, display: cs.display, zoom: Math.round((window.outerWidth / window.innerWidth) * 100) / 100 };
      p.redraw();
      r.w = cv.width;
      r.h = cv.height;
      const px = p.vfd.readPixels(0, 0, cv.width, cv.height);
      let lit = 0;
      for (let i = 0; i < px.length; i += 4) if (px[i] + px[i + 1] + px[i + 2] > 60) lit++;
      r.lit = lit;
      if (glr && glr.gl) r.glErrorAfterDraw = glr.gl.getError();
    } catch (err) {
      r.error = `${err.message} @ ${(err.stack || "").split(String.fromCharCode(10)).slice(0, 3).join(" | ")}`;
    }
    return r;
  }

  // 自动化（仅本机测试页 127.0.0.1 / localhost）：Firefox 下自动化点不了工具栏图标，页面可用
  // window.postMessage({ neoDev: "activate" | "deactivate" }, "*") 触发；其它站点不认。
  // NEO_DEV_ANY：pack.py --dev-any 的测试构建（不进 zip）把它改成 true，任何站点都接受来自 opener 窗口的触发口，
  // 结果回给 opener——自检页用 window.open 打开真实站点（如 YouTube）复现实机环境。
  const NEO_DEV_ANY = false;
  const NEO_AUTO = NEO_DEV_ANY ? location.hash.match(/#neoauto(?:=(\w+))?/) : null;
  if (NEO_DEV_ANY || NEO_AUTO || /^(127\.0\.0\.1|localhost)$/.test(location.hostname)) {
    const devLogs = [];
    let devSource = null; // 测试构建：驱动本页的自检页窗口（按消息来源 origin 认，跨界包装下比对象身份可靠）
    const targets = () => (devSource && devSource !== window ? [window, devSource] : [window]);
    const tell = (msg) => {
      for (const w of targets()) {
        try {
          w.postMessage(msg, "*");
        } catch (_) {
          /* 忽略 */
        }
      }
    };
    // 日志也镜像给页面（自动化收集）
    const baseLog = api.log;
    api.log = (t) => {
      baseLog(t);
      devLogs.push(String(t));
      tell({ neoDevLog: String(t), neoDevFrom: location.hostname });
    };
    if (NEO_AUTO) {
      // 自驱动（ff-test.mjs --file）：复现"Firefox 直接打开本地 MP3"这类页面；结果 POST 到自检服务器（它开了 CORS）
      const gl = NEO_AUTO[1] || "webgl";
      try {
        localStorage.setItem("neo.gl", gl);
      } catch (_) {
        /* file:// 可能没有存储 */
      }
      const post = (body) => fetch("http://127.0.0.1:8770/__site", { method: "POST", headers: { "content-type": "text/plain" }, body: JSON.stringify(body) }).catch(() => {});
      post({ stage: "start", href: location.href.slice(0, 80), readyState: document.readyState });
      setTimeout(async () => {
        try {
          const media = document.querySelector("video, audio");
          post({ stage: "activating", media: media ? media.tagName : null, dom: document.documentElement.outerHTML.slice(0, 400), body: document.body ? document.body.childNodes.length : -1 });
          if (media) {
            try {
              await media.play();
            } catch (e) {
              api.log(`自驱动 play 失败：${e.message}`);
            }
          }
          await activate();
          if (api.panel && !api.panel.state.open) api.panel.toggle();
          setTimeout(() => {
            const r = displayProbe();
            r.screen = [window.mozInnerScreenX, window.mozInnerScreenY, window.devicePixelRatio];
            r.href = location.href.slice(0, 80);
            r.media = media ? { tag: media.tagName.toLowerCase(), paused: media.paused, t: media.currentTime } : null;
            post({ probe: r, log: devLogs });
          }, 7000);
        } catch (e) {
          post({ error: e.message, log: devLogs });
        }
      }, 2500);
    }
    window.addEventListener("message", (e) => {
      if (!e.data || typeof e.data.neoDev !== "string") return;
      if (NEO_DEV_ANY) {
        try {
          document.title = `neo:${e.data.neoDev} origin=${e.origin} src=${e.source ? (e.source === window ? "self" : "other") : "n"} opener=${window.opener ? "y" : "n"}`; // 测试构建：窗口截图里能看到握手到了没
        } catch (_) {
          /* 忽略 */
        }
      }
      if (e.source !== window) {
        if (!(NEO_DEV_ANY && /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(e.origin))) return;
        devSource = e.source || window.opener;
        if (typeof e.data.gl === "string") {
          try {
            localStorage.setItem("neo.gl", e.data.gl); // 站点页的后端开关由驱动方指定
          } catch (_) {
            /* 无存储 */
          }
        }
      }
      if (e.data.neoDev === "ping") tell({ neoDevPong: { href: location.href.slice(0, 60), panel: !!api.panel, mode: api.mode } });
      if (e.data.neoDev === "activate") activate().catch((err) => api.log(`activate: ${err.message}`));
      if (e.data.neoDev === "deactivate") deactivate();
      if (e.data.neoDev === "toggle" && api.panel) api.panel.toggle();
      if (e.data.neoDev === "hqop") {
        // 自检页：模型操作（seturl 只给自动化换成本地地址；download / cancel / delete / status 走宿主的 modelStore）
        const h = api.pageHost ? api.pageHost.host : null;
        const op = e.data.op;
        (async () => {
          try {
            if (op === "seturl") await chrome.runtime.sendMessage({ type: "neo-model", op: "seturl", url: e.data.url });
            else if (op === "gpuprobe") {
              tell({ neoDevHqop: { op, ok: true, probe: await chrome.runtime.sendMessage({ type: "neo-gpuprobe" }) } });
              return;
            }
            else if (h && h.modelStore && typeof h.modelStore[op] === "function") await h.modelStore[op]();
            tell({ neoDevHqop: { op, ok: true } });
          } catch (err) {
            tell({ neoDevHqop: { op, error: err.message } });
          }
        })();
      }
      if (e.data.neoDev === "stage") {
        // 虚拟舞台（阶段 4.2）：分离 Worker 状态与供给情况（自检页 ff-harness 用）
        const h = api.pageHost ? api.pageHost.host : null;
        const neo = h && h.neo;
        if (!neo || !neo.ui) {
          tell({ neoDevStage: { error: "no engine" } });
        } else {
          (async () => {
            const r = { hasStage: !!neo.ui.hasStage(), worker: neo.stageWorkerState, hq: Object.assign({}, neo.hqInfo), depth: neo.stageQueueDepth || 0, model: h.modelStore ? Object.assign({}, h.modelStore.state) : null };
            try {
              r.feeding = await neo.getParam(13, 0, 104);
              r.latency = await neo.getParam(13, 0, 103);
              r.stats = await neo.stageStats();
            } catch (err) {
              r.error = err.message;
            }
            tell({ neoDevStage: r });
          })();
        }
      }
      if (e.data.neoDev === "probe" && api.panel) {
        const r = displayProbe((v) => tell({ neoDevProbe2: { getParam: v } }));
        r.screen = [window.mozInnerScreenX, window.mozInnerScreenY, window.devicePixelRatio]; // 截屏换算用（Firefox）
        r.href = location.href.slice(0, 80);
        tell({ neoDevProbe: r });
      }
    });
  }

  // 页面（重新）加载：这个标签页如果已经开着，立刻把 UI 挂回来
  if (alive()) {
    chrome.runtime
      .sendMessage({ type: "neo-query" })
      .then((r) => {
        if (r) api.canCapture = !!r.canCapture;
        if (r && r.active && alive()) activate();
      })
      .catch(() => {});
  }
})();
