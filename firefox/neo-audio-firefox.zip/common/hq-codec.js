// Neo Audio — 分离通道的编码（阶段 4.5，方案 B）：音频跳与声部块经插件内部的 runtime.Port 来回（Chrome 的 Port 只能传 JSON），
// Float32 → Int16（±2.0 满幅，约 90 dB 信噪比，对声部足够）→ base64 字符串。每秒约 1.2 MB 字符串，编解码开销可忽略。

/** Int16 满幅对应的浮点值的倒数：±2.0 → ±32767。 */
const SCALE = 32767 / 2;
const INV = 2 / 32767;

const toB64 = typeof Uint8Array.prototype.toBase64 === "function" ? (u8) => u8.toBase64() : (u8) => {
  let s = "";
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  return btoa(s);
};
const fromB64 = typeof Uint8Array.fromBase64 === "function" ? (b64) => Uint8Array.fromBase64(b64) : (b64) => {
  const s = atob(b64);
  const u8 = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i);
  return u8;
};

/** Float32Array → base64（Int16 小端）。 */
export function encodeF32(f32) {
  const i16 = new Int16Array(f32.length);
  for (let i = 0; i < f32.length; i++) {
    const v = f32[i] * SCALE;
    i16[i] = v > 32767 ? 32767 : v < -32768 ? -32768 : Math.round(v);
  }
  return toB64(new Uint8Array(i16.buffer));
}

/** base64（Int16 小端）→ Float32Array。 */
export function decodeF32(b64) {
  const u8 = fromB64(b64);
  const i16 = new Int16Array(u8.buffer, u8.byteOffset, u8.byteLength >> 1);
  const f32 = new Float32Array(i16.length);
  for (let i = 0; i < i16.length; i++) f32[i] = i16[i] * INV;
  return f32;
}
