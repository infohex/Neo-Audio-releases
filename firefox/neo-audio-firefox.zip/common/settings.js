// Neo Audio — 设置与命名配置（阶段 3.1；BO 2026-10-07 决策）。
//
// 一条"配置记录"= 全部可写参数 + 模块开关 + 显示 / 界面附加项（extras）。
//   { version:1, name, savedAt, modules:{ "2":{enabled:true, params:{"0:0":3, "100":1}} }, extras:{...} }
// params 的键是 "index:field"；index 为 0 时省成 "field"。只存可写字段。
//
// 存储：有 chrome.storage / browser.storage 用 storage.local，否则 localStorage（测试页）。
//   neo.current  当前设置（任何改动防抖 500 ms 自动保存；启动时自动读回）
//   neo.profiles 命名配置 { name → record }
// 文件：导出 = 一条记录的 JSON 文本（页面负责下载）；导入 = 解析文本、校验后存成命名配置。

export const SETTINGS_VERSION = 1;
export const KEY_CURRENT = "neo.current";
export const KEY_PROFILES = "neo.profiles";
const AUTOSAVE_MS = 500;

/** 选一个可用的键值存储：{get(key), set(key, value), remove(key)}，全部返回 Promise。 */
export function createStore() {
  const g = typeof globalThis !== "undefined" ? globalThis : {};
  const ext = (g.browser && g.browser.storage && g.browser.storage.local) || (g.chrome && g.chrome.storage && g.chrome.storage.local) || null;
  if (ext) {
    return {
      kind: "extension",
      get: (key) => Promise.resolve(ext.get(key)).then((r) => (r ? r[key] : undefined)),
      set: (key, value) => Promise.resolve(ext.set({ [key]: value })),
      remove: (key) => Promise.resolve(ext.remove(key)),
    };
  }
  return {
    kind: "local",
    get: (key) => {
      try {
        const t = localStorage.getItem(key);
        return Promise.resolve(t === null ? undefined : JSON.parse(t));
      } catch (_) {
        return Promise.resolve(undefined);
      }
    },
    set: (key, value) => {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (_) {
        /* 隐私模式等情况下忽略 */
      }
      return Promise.resolve();
    },
    remove: (key) => {
      try {
        localStorage.removeItem(key);
      } catch (_) {
        /* 无存储 */
      }
      return Promise.resolve();
    },
  };
}

const paramKey = (index, field) => (index ? `${index}:${field}` : `${field}`);
function parseParamKey(k) {
  const i = k.indexOf(":");
  return i < 0 ? [0, parseInt(k, 10)] : [parseInt(k.slice(0, i), 10), parseInt(k.slice(i + 1), 10)];
}

export class Settings {
  /**
   * @param {{store?:object, controls:()=>Array, alwaysOff?:number[], extras?:{get:()=>object, set:(o:object)=>void}, log?:Function, onProfiles?:Function}} o
   *   controls()：控件登记表（fader / toggle / moduleSwitch …，见 common/ui/controls.js）
   *   extras：页面自己的附加项（显示风格、视图、FFT …），get 返回纯对象，set 恢复
   *   onProfiles(names, current)：命名配置列表变化时回调（刷新下拉）
   */
  constructor(o) {
    this.store = o.store || createStore();
    this.controls = o.controls;
    this.extras = o.extras || { get: () => ({}), set: () => {} };
    this.alwaysOff = o.alwaysOff || []; // 这些模块恢复设置时一律关（虚拟舞台：每次激活都手动开）
    this.log = o.log || (() => {});
    this.onProfiles = o.onProfiles || (() => {});
    this.currentName = ""; // 最近载入 / 保存的命名配置（空 = 未命名）
    this._timer = 0;
    this._restoring = false;
    this.lastSaved = null; // 自动化核对用
  }

  // ---- 序列化 ----

  serialize(name = this.currentName) {
    const modules = {};
    const mod = (m) => (modules[m] = modules[m] || { enabled: undefined, params: {} });
    for (const c of this.controls()) {
      if (c.module === undefined || c.module === null) continue;
      if (c.isModuleSwitch) {
        mod(c.module).enabled = !!c.input.checked;
        continue;
      }
      if (c.field === undefined || typeof c.value !== "number" || !Number.isFinite(c.value)) continue;
      if (c.info && c.info.readOnly) continue;
      mod(c.module).params[paramKey(c.index || 0, c.field)] = c.value;
    }
    for (const m of Object.values(modules)) if (m.enabled === undefined) delete m.enabled;
    return { version: SETTINGS_VERSION, name, savedAt: new Date().toISOString(), modules, extras: this.extras.get() };
  }

  /** 把一条记录恢复到控件（开关先、参数后）与附加项；有引擎时控件自己会下发。 */
  restore(rec) {
    if (!rec || typeof rec !== "object") return false;
    this._restoring = true;
    try {
      const modules = rec.modules || {};
      const ctls = this.controls();
      for (const c of ctls) {
        if (!c.isModuleSwitch) continue;
        const m = modules[c.module];
        const enabled = this.alwaysOff.includes(c.module) ? false : m && typeof m.enabled === "boolean" ? m.enabled : null;
        if (enabled !== null && c.input.checked !== enabled && !c.input.disabled) {
          c.input.checked = enabled;
          c.send();
        }
      }
      for (const c of ctls) {
        if (c.isModuleSwitch || c.field === undefined || !c.setValue) continue;
        const m = modules[c.module];
        if (!m || !m.params) continue;
        const v = m.params[paramKey(c.index || 0, c.field)];
        if (typeof v === "number" && Number.isFinite(v)) c.setValue(v, true);
      }
      if (rec.extras) this.extras.set(rec.extras);
      if (typeof rec.name === "string") this.currentName = rec.name;
    } finally {
      this._restoring = false;
    }
    return true;
  }

  /** 协议 apply 用的操作列表（引擎刚建好时整份下发）。 */
  toOps(rec = this.serialize()) {
    const ops = [];
    for (const [m, e] of Object.entries(rec.modules || {})) {
      if (typeof e.enabled === "boolean") ops.push({ t: "enable", m: parseInt(m, 10), on: e.enabled });
    }
    for (const [m, e] of Object.entries(rec.modules || {})) {
      for (const [k, v] of Object.entries(e.params || {})) {
        const [i, f] = parseParamKey(k);
        ops.push({ t: "set", m: parseInt(m, 10), i, f, v });
      }
    }
    return ops;
  }

  // ---- 当前设置：自动保存 / 读回 ----

  /** 任何改动后调用：防抖后把当前设置存成 neo.current。 */
  touch() {
    if (this._restoring) return;
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.saveCurrent(), AUTOSAVE_MS);
  }

  async saveCurrent() {
    clearTimeout(this._timer);
    const rec = this.serialize();
    this.lastSaved = rec;
    await this.store.set(KEY_CURRENT, rec);
    return rec;
  }

  /** 启动时读回；没有存过返回 false。 */
  async loadCurrent() {
    const rec = await this.store.get(KEY_CURRENT);
    if (!isRecord(rec)) return false;
    this.restore(rec);
    this.log(`已恢复上次设置${rec.name ? `（配置「${rec.name}」）` : ""}`);
    return true;
  }

  // ---- 命名配置 ----

  async _profiles() {
    const p = await this.store.get(KEY_PROFILES);
    return p && typeof p === "object" ? p : {};
  }
  async _putProfiles(p) {
    await this.store.set(KEY_PROFILES, p);
    this.onProfiles(Object.keys(p).sort(), this.currentName);
  }

  async list() {
    const p = await this._profiles();
    return Object.keys(p).sort();
  }

  /** 把当前设置存成命名配置（已有则覆盖）。 */
  async save(name) {
    name = String(name || "").trim();
    if (!name) throw new Error("配置名不能为空");
    const p = await this._profiles();
    p[name] = this.serialize(name);
    this.currentName = name;
    await this._putProfiles(p);
    await this.saveCurrent();
    this.log(`配置「${name}」已保存`);
    return p[name];
  }

  async load(name) {
    const p = await this._profiles();
    const rec = p[name];
    if (!isRecord(rec)) throw new Error(`没有配置「${name}」`);
    this.restore(rec);
    this.currentName = name;
    await this.saveCurrent();
    this.onProfiles(Object.keys(p).sort(), this.currentName);
    this.log(`已切换到配置「${name}」`);
    return rec;
  }

  async remove(name) {
    const p = await this._profiles();
    if (!(name in p)) return false;
    delete p[name];
    if (this.currentName === name) this.currentName = "";
    await this._putProfiles(p);
    await this.saveCurrent();
    this.log(`配置「${name}」已删除`);
    return true;
  }

  /** 导出：一条记录的 JSON 文本（name 为空 = 当前设置）。 */
  async exportText(name = "") {
    let rec;
    if (name) {
      const p = await this._profiles();
      rec = p[name];
      if (!isRecord(rec)) throw new Error(`没有配置「${name}」`);
    } else {
      rec = this.serialize(this.currentName);
    }
    return JSON.stringify(rec, null, 2);
  }

  /** 导入：解析文本，校验后存成命名配置（名字来自记录，可用 name 覆盖）；返回存下的名字。 */
  async importText(text, name = "") {
    let rec;
    try {
      rec = JSON.parse(text);
    } catch (e) {
      throw new Error("不是有效的 JSON");
    }
    if (!isRecord(rec)) throw new Error("不是 Neo Audio 的配置文件");
    const nm = String(name || rec.name || "").trim() || `导入 ${new Date().toLocaleString()}`;
    rec.name = nm;
    const p = await this._profiles();
    p[nm] = rec;
    await this._putProfiles(p);
    this.log(`已导入配置「${nm}」`);
    return nm;
  }

  /** 导出文件名。 */
  static fileName(name) {
    const safe = String(name || "settings").replace(/[\\/:*?"<>|]+/g, "_");
    return `neo-audio-${safe}.json`;
  }
}

function isRecord(rec) {
  return !!rec && typeof rec === "object" && rec.version === SETTINGS_VERSION && rec.modules && typeof rec.modules === "object";
}
