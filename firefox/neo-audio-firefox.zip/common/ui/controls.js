// Neo Audio — 参数控件（阶段 3.1 从测试页 app.js 抽出，测试页与插件面板共用）。
//
// 所有控件由参数表元数据驱动：推子只处理 0–1 位置，按标度换算成值；登记到 controls[]，带
// sync()（启动时从引擎读回初值）/ send()（下发）/ reset()（回到启动时读回的默认值）/ setValue()。
// 依赖由调用方注入（deps），这样同一套控件既能接测试页的 state，也能接插件面板的客户端：
//   paramInfo(module, field)        元数据（本地实例）
//   getP(module, index, field)      读回（Promise）
//   getEnabled(module)              模块开关读回（Promise<boolean>）
//   send(module, index, field, v)   写参数（没有引擎时应为空操作）
//   sendEnable(module, on)          模块开关
//   bypass()                        全部旁路中？（输出级的自动增益 / 限幅一并关掉）
//   $(id)                           按 id 找元素（Shadow DOM 里传 root.getElementById）
//   log(text)
//   changed()                       用户动过控件（自动保存用）

import { SCALE, UNIT, MODULE, positionToValue, valueToPosition } from "../../shared/wasm-abi.js";
import { t } from "../i18n.js";

const SLIDER_STEPS = 1000;

// 频率一律整数 Hz（BO 决策：频率取值不用浮点）
export function fmtHz(v) {
  return `${Math.round(v)} Hz`;
}

export function fmtValue(info, v) {
  switch (info.unit) {
    case UNIT.HZ:
      return fmtHz(v);
    case UNIT.DB:
      // 推子值都是整数 dB（1 dB 步进）；只读读数（补偿后增益等）保留一位小数
      return `${v >= 0 ? "+" : ""}${Math.abs(v - Math.round(v)) < 1e-6 ? Math.round(v).toFixed(0) : v.toFixed(1)} dB`;
    case UNIT.MS:
      return `${v.toFixed(0)} ms`;
    case UNIT.Q:
      return `Q ${v.toFixed(2)}`;
    case UNIT.PERCENT:
      return `${(v * 100).toFixed(0)} %`;
    case UNIT.SAMPLES:
      return `${v.toFixed(0)} ${t("unit.samples")}`;
    case UNIT.BOOL:
      return v ? t("on") : t("off");
    default:
      return v.toFixed(2);
  }
}

/**
 * 建一套控件工厂。返回 { controls, fader, toggle, moduleSwitch, segControl, headSwitch, channelSwitch, fmtValue, fmtHz }。
 */
export function createControls(deps) {
  const controls = [];
  const log = deps.log || (() => {});
  const changed = deps.changed || (() => {});
  const bypass = deps.bypass || (() => false);
  const $ = deps.$ || ((id) => document.getElementById(id));

  /**
   * 纵向推子：0–1 位置 ↔ 值（按元数据标度）。频率（Hz）字段一律取整；其他字段可用 integer:true 强制取整；
   * step 指定值的步长（例如 TrueTreble 频率 100 Hz），取整到步长的整数倍并夹在元数据范围内。
   * 结构：[名称] [推子] [读数]。
   */
  function fader(container, { module, index = 0, field, label, title = "", integer = false, step = 0, fmt = null }) {
    const info = deps.paramInfo(module, field);
    if (!info) {
      log(`没有参数元数据: 模块 ${module} 字段 ${field}`);
      return null;
    }
    const isInt = integer || info.unit === UNIT.HZ;
    // dB 推子一律 1 dB 步进、整数（BO 决策：浮点难调）；其它按传入的 step
    const stepv = step > 0 ? step : info.unit === UNIT.DB ? 1 : 0;
    // 线性标度且有步长：滑杆的格数 = 范围 / 步长，每格正好一步（键盘 / 滚轮也按步走）；其它 1000 格
    const steps = stepv > 0 && info.scale !== SCALE.LOG ? Math.max(1, Math.round((info.max - info.min) / stepv)) : SLIDER_STEPS;
    const show = fmt || ((v) => fmtValue(info, v));
    const quantize = (v) => {
      // 始终夹到参数范围：setValue / 恢复记忆值可能带来越界数字，引擎会夹取，控件显示要与之一致
      const c = Math.min(info.max, Math.max(info.min, v));
      if (stepv > 0) return Math.min(info.max, Math.max(info.min, Math.round(c / stepv) * stepv));
      return isInt ? Math.round(c) : c;
    };
    const col = document.createElement("div");
    col.className = "fader";
    const lab = document.createElement("span");
    lab.className = "flabel";
    lab.textContent = label;
    if (title && title !== label) lab.title = title; // 短名在推子上，完整名悬停可见（多语言）
    const input = document.createElement("input");
    input.type = "range";
    input.className = "v";
    input.min = 0;
    input.max = steps;
    input.step = 1;
    const out = document.createElement("output");
    const txt = document.createTextNode("");
    out.appendChild(txt);
    col.append(lab, input, out);
    container.appendChild(col);

    let value = info.default;
    const ctl = {
      row: col,
      label: lab,
      input,
      out,
      info,
      module,
      index,
      field,
      get value() {
        return value;
      },
      setValue(v, send = true) {
        value = quantize(v);
        input.value = Math.round(valueToPosition(info, value) * steps);
        txt.data = show(value);
        if (send) ctl.send();
      },
      send() {
        deps.send(module, index, field, value);
      },
      /** 启动时从引擎读回当前值初始化控件（不下发）；这个值也作为 Default 的目标。 */
      async sync() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) {
          ctl.setValue(v, false);
          ctl.initial = ctl.value;
        }
      },
      reset() {
        if (ctl.initial !== undefined) ctl.setValue(ctl.initial, true);
      },
      /** 从引擎读回当前值并把控件设到该值（不下发、不改 Default 目标）；预设切换后用。 */
      async pull() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) ctl.setValue(v, false);
      },
      /** 从引擎读回实际生效值（夹取后）并显示。 */
      async readback() {
        try {
          const v = await deps.getP(module, index, field);
          if (Number.isFinite(v) && Math.abs(v - value) > 1e-4) {
            txt.data = `${show(v)}*`;
          }
        } catch (e) {
          log(`读回失败 ${module}/${index}/${field}: ${e.message}`);
        }
      },
    };
    input.addEventListener("input", () => {
      const v = quantize(positionToValue(info, input.value / steps));
      if (v === value) return; // 取整/步长量化后没变，不重复下发
      value = v;
      txt.data = show(value);
      ctl.send();
      changed();
    });
    input.addEventListener("change", () => ctl.readback());
    ctl.setValue(info.default, false);
    controls.push(ctl);
    return ctl;
  }

  /** 布尔字段开关，排成与推子同高的一列。 */
  function toggle(container, { module, index = 0, field, label, onChange }) {
    const info = deps.paramInfo(module, field);
    if (!info) {
      log(`没有参数元数据: 模块 ${module} 字段 ${field}`);
      return null;
    }
    const col = document.createElement("div");
    col.className = "fader ftoggle";
    const lab = document.createElement("span");
    lab.className = "flabel";
    lab.textContent = label;
    const sw = document.createElement("label");
    sw.className = "switch";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = info.default !== 0;
    sw.append(input, document.createElement("span"));
    const out = document.createElement("output");
    out.textContent = fmtValue(info, input.checked ? 1 : 0);
    col.append(lab, sw, out);
    container.appendChild(col);
    const ctl = {
      row: col,
      input,
      info,
      module,
      index,
      field,
      get value() {
        return input.checked ? 1 : 0;
      },
      setValue(v, send = true) {
        input.checked = v > 0.5;
        out.textContent = fmtValue(info, ctl.value);
        if (send) ctl.send();
      },
      async sync() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) {
          input.checked = v > 0.5;
          out.textContent = fmtValue(info, ctl.value);
          ctl.initial = input.checked;
        }
      },
      reset() {
        if (ctl.initial !== undefined) {
          input.checked = ctl.initial;
          ctl.send();
        }
      },
      send() {
        // 旁路时输出级的自动增益 / 限幅一并关掉
        const v = bypass() && module === MODULE.OUTPUT ? 0 : ctl.value;
        deps.send(module, index, field, v);
        out.textContent = fmtValue(info, ctl.value);
      },
    };
    input.addEventListener("change", () => {
      ctl.send();
      changed();
      if (onChange) onChange(input.checked);
    });
    controls.push(ctl);
    return ctl;
  }

  /**
   * 模块级开关（旁路时强制关）。初值从引擎读回（引擎默认全关，BO 决策）；Default 不改开关。
   * 模块关闭时所在面板折叠成只剩标题与这个开关（BO 决策）：给 section.panel 加 .collapsed。
   */
  function moduleSwitch(id, module, group = null) {
    const input = typeof id === "string" ? $(id) : id;
    const panel = input.closest("section.panel");
    // 面板里可能有多个模块开关（高低音提升：低频 / 高频）：全部关闭才折叠；各开关自己的那组推子关掉时变淡
    const fold = () => {
      if (panel) {
        const any = [...panel.querySelectorAll(".module-switch input")].some((e) => e.checked);
        panel.classList.toggle("collapsed", !any);
      }
      if (group) group.classList.toggle("off", !input.checked);
    };
    const ctl = {
      input,
      module,
      isModuleSwitch: true,
      async sync() {
        try {
          input.checked = await deps.getEnabled(module);
        } catch (e) {
          log(`读回模块开关失败 ${module}: ${e.message}`);
        }
        fold();
      },
      send() {
        if (!input.disabled) deps.sendEnable(module, input.checked && !bypass());
        fold();
      },
    };
    input.addEventListener("change", () => {
      ctl.send();
      changed();
    });
    fold();
    controls.push(ctl);
    return ctl;
  }

  /**
   * 分段按钮控件：一组互斥按钮对应一个参数的离散取值（渲染方式、LFE 分频三档）。
   * 与推子一样登记进 controls（sync / reset / send / value）。
   */
  function segControl(el, { module, index = 0, field, options }) {
    const info = deps.paramInfo(module, field);
    if (!info) return null;
    const buttons = options.map(([v, text]) => {
      const b = document.createElement("button");
      b.type = "button";
      b.dataset.v = String(v);
      b.textContent = text;
      el.appendChild(b);
      return b;
    });
    let value = info.default;
    const paint = () => {
      // 高亮离当前值最近的一档（引擎可能把写入值吸附到别的档）
      let best = 0;
      options.forEach(([v], i) => {
        if (Math.abs(v - value) < Math.abs(options[best][0] - value)) best = i;
      });
      buttons.forEach((b, i) => b.classList.toggle("active", i === best));
    };
    const ctl = {
      input: el,
      info,
      module,
      index,
      field,
      get value() {
        return value;
      },
      setValue(v, send = true) {
        value = v;
        paint();
        if (send) ctl.send();
      },
      send() {
        deps.send(module, index, field, value);
      },
      async sync() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) {
          ctl.setValue(v, false);
          ctl.initial = ctl.value;
        }
      },
      reset() {
        if (ctl.initial !== undefined) ctl.setValue(ctl.initial, true);
      },
      async pull() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) ctl.setValue(v, false);
      },
    };
    buttons.forEach((b) =>
      b.addEventListener("click", () => {
        ctl.setValue(parseFloat(b.dataset.v), true);
        changed();
      })
    );
    paint();
    controls.push(ctl);
    return ctl;
  }

  /** 面板头里的布尔参数开关（不占推子列；音色修正）。 */
  function headSwitch(input, { module, index = 0, field }) {
    const info = deps.paramInfo(module, field);
    if (!info) return null;
    input.checked = info.default !== 0;
    const ctl = {
      input,
      info,
      module,
      index,
      field,
      get value() {
        return input.checked ? 1 : 0;
      },
      setValue(v, send = true) {
        input.checked = v > 0.5;
        if (send) ctl.send();
      },
      async sync() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) {
          input.checked = v > 0.5;
          ctl.initial = input.checked;
        }
      },
      reset() {
        if (ctl.initial !== undefined) {
          input.checked = ctl.initial;
          ctl.send();
        }
      },
      send() {
        deps.send(module, index, field, ctl.value);
      },
    };
    input.addEventListener("change", () => {
      ctl.send();
      changed();
    });
    controls.push(ctl);
    return ctl;
  }

  /**
   * 推子底部的声道 On/Off 开关（虚拟环绕六路）：开关 = 该路有声，Off 写静音字段 1，推子的增益值保留并变淡。
   * 与其它控件一样登记到 controls（sync / reset / send）。
   */
  function channelSwitch(faderCtl, { module, index = 0, field }) {
    const info = deps.paramInfo(module, field);
    if (!info) {
      log(`没有参数元数据: 模块 ${module} 字段 ${field}`);
      return null;
    }
    const sw = document.createElement("label");
    sw.className = "switch ch-switch";
    sw.title = t("mute.tip");
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = info.default === 0; // 字段是"静音"，开关是"有声"
    sw.append(input, document.createElement("span"));
    faderCtl.row.appendChild(sw);
    faderCtl.row.classList.add("has-switch");
    const paint = () => faderCtl.row.classList.toggle("off", !input.checked);
    const ctl = {
      row: faderCtl.row,
      input,
      info,
      module,
      index,
      field,
      /** 字段值：1 = 静音。 */
      get value() {
        return input.checked ? 0 : 1;
      },
      setValue(v, send = true) {
        input.checked = !(v > 0.5);
        paint();
        if (send) ctl.send();
      },
      async sync() {
        const v = await deps.getP(module, index, field);
        if (Number.isFinite(v)) {
          input.checked = !(v > 0.5);
          ctl.initial = input.checked;
          paint();
        }
      },
      reset() {
        if (ctl.initial !== undefined) {
          input.checked = ctl.initial;
          ctl.send();
        }
      },
      send() {
        paint();
        deps.send(module, index, field, ctl.value);
      },
    };
    input.addEventListener("change", () => {
      ctl.send();
      changed();
    });
    paint();
    controls.push(ctl);
    return ctl;
  }

  return { controls, fader, toggle, moduleSwitch, segControl, headSwitch, channelSwitch, fmtValue, fmtHz };
}
