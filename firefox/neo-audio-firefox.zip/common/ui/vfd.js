// Neo Audio — VFD 显示屏渲染器（阶段 3.2 从测试页 app.js 整段抽出，测试页与插件面板共用）。
//
// 仿 Kenwood GE-930 荧光数码管：深色玻璃上的分段点阵（波形 384×72、频程 31 柱 + L/R 两柱各 72 段、曲线），
// 底部常亮红基线，六种磷光色风格，辉光 / 余晖 / 溢光 / 栅极网。哪些灯亮、多亮由内核灯板给（feedLamp），这里只画像素。
// 后端：WebGL（extension/shared/vfd-gl.js，默认）/ Canvas 2D（兜底）。
//
// createVfd(o)：
//   o.canvas        显示屏 <canvas>（尺寸由 CSS 定，这里只按 DPR 设像素缓冲）
//   o.spillCanvas   边框溢光 <canvas>（可无）；o.bezel 边框元素（CSS 变量 --bezel；可无）
//   o.state         共享状态：theme / glowAmount / spillAmount / bezelPx / viewMode / overlay / lastBars / _colMap（渲染器读写）
//   o.feedLamp(d)   把一帧显示数据喂给灯板，返回灯板视图（没有引擎时返回空灯板或 null）
//   o.displayParam(field)  读模块 11 的生效值（刻度 γ 等，只用于文字）
//   o.fftSize()     当前 FFT 点数（文字），o.onInfo(text) 视图说明文字，o.log(text)，o.glMode（"0" 关 GL、"keep" 保留绘制缓冲）
//   o.onRestored()  WebGL 上下文恢复后回调（页面重画）
// 返回 { drawView, drawWave, drawSpectrum, applyTheme, VFD_THEMES, VFD_THEME_DEFAULT, VFD, GLOW, rendererName, glRenderer,
//        spillRenderer, readPixels, readSpillPixels, brightToBytes, beginFrame, endFrame, WAVE_COLS, WAVE_ROWS }。

import { LAMP, FIELD } from "../../shared/wasm-abi.js";
import { createVfdGl, createSpillGl } from "../../shared/vfd-gl.js";

export function createVfd(o) {
  const state = o.state;
  // 像素缓冲密度：屏幕 DPR × 面板的 CSS zoom（o.zoom()），缩放后显示屏仍然清晰
  const dprOf = () => (window.devicePixelRatio || 1) * (o.zoom ? o.zoom() : 1);
  const log = o.log || (() => {});
  const feedLamp = (d) => o.feedLamp(d);
  const displayParam = (field) => o.displayParam(field);
  const fftLabel = () => {
    const n = o.fftSize ? o.fftSize() : null;
    return n || "—";
  };
  const fmtHz = (v) => `${Math.round(v)} Hz`;

  const displayCanvas = o.canvas;
  const waveCanvas = displayCanvas;
  const specCanvas = displayCanvas;

  // 2D 上下文只创建一次并复用；willReadFrequently 让 Firefox 走软件画布，绕开 Windows 上 GPU 加速画布
  // 把整块画布合成为黑色的问题（Firefox 156 实测：fillRect 青灰色矩形显示为纯黑）。
  const ctxCache = new WeakMap();
  // 广色域（BO 决策：发光体感）：Chrome/Safari 支持 display-p3 画布，磷光绿/青能比 sRGB 更饱和；Firefox 忽略该选项。
  // 只有画布真的拿到了 p3 且 fillStyle 能解析 color(display-p3 …) 时才用 P3 颜色串，否则一律 sRGB，避免 fillStyle 解析失败被静默忽略。
  const CANVAS_OPTS = { willReadFrequently: true, alpha: true, colorSpace: "display-p3" };
  function detectP3() {
    try {
      const c = document.createElement("canvas");
      const g = c.getContext("2d", CANVAS_OPTS);
      const attrs = g.getContextAttributes ? g.getContextAttributes() : {};
      if (attrs.colorSpace !== "display-p3") return false;
      g.fillStyle = "color(display-p3 0 1 0)";
      return typeof g.fillStyle === "string" && g.fillStyle.includes("display-p3");
    } catch (_) {
      return false;
    }
  }
  const HAS_P3 = detectP3();
  function ctx2d(cv) {
    let g = ctxCache.get(cv);
    if (!g) {
      g = cv.getContext("2d", CANVAS_OPTS);
      ctxCache.set(cv, g);
    }
    return g;
  }

  function fitCanvas(cv) {
    // 显示屏尺寸由 CSS 固定（不随窗口变化）；这里只按 DPR 设置像素缓冲，保证高分屏清晰
    const dpr = dprOf();
    const w = Math.max(1, Math.round(cv.clientWidth * dpr));
    const h = Math.max(1, Math.round(cv.clientHeight * dpr));
    if (cv.width !== w || cv.height !== h) {
      cv.width = w;
      cv.height = h;
    }
    return dpr;
  }

  // 显示窗：仿荧光数码管（VFD）——深色玻璃面板上的分段点阵，未点亮的段隐约可见（幽灵段），
  // 点亮的段 = 近白的核心 + 荧光色边缘 + 溢出到段外的辉光（bloom，见 litLayer/bloom）。
  // 显示风格可全局切换（BO 决策）：每种风格只由一个"磷光色"tint 派生出全套颜色，红色基线不随风格变。
  const VFD_THEMES = {
    kenwood: { name: "Kenwood 青白", tint: [120, 225, 255] },
    green: { name: "经典 VFD 绿", tint: [80, 245, 165] },
    purple: { name: "紫色荧光", tint: [205, 125, 255] },
    neon: { name: "氖红霓虹", tint: [255, 75, 55] },
    xenon: { name: "氙气白", tint: [228, 236, 255] },
    amber: { name: "琥珀", tint: [255, 178, 64] },
  };
  const VFD_THEME_DEFAULT = "kenwood";
  const VFD = {
    screen: "#05070a", // 玻璃底：压到接近纯黑，点亮段与周围的对比才拉得开（BO 决策：发光体感）
    vignette: "rgba(0, 0, 0, 0.5)",
    redCore: "#ff5a3a", // 底部常亮的红色基线行（BO 决策，参照 VFD 频谱仪实物）
    redGlow: "rgba(255, 90, 60, 0.55)",
    // 以下由 applyTheme 按 tint 派生
    core: "", glow: "", dim: "", ghost: "", fill: "", grid: "", text: "", textDim: "",
  };
  // 六边形栅极网（BO 指出真管子前面有一层极细的金属网）：线宽不到半个像素，靠透明度呈现；
  // 点亮的段被网"切"出暗线（carve），未点亮的玻璃区只隐约看到一点（faint）。side = 六边形边长（CSS px）。
  const MESH = { side: 3.0, lineWidth: 0.45, carve: 0.65, faint: 0.04 };
  const meshCache = new Map();
  /** 平顶六边形网格的最小重复单元（3·side × √3·side），线条为纯白，使用时靠 globalAlpha 调深浅。 */
  function meshTile(dpr) {
    const key = `${dpr}x${MESH.side}x${MESH.lineWidth}`;
    let t = meshCache.get(key);
    if (t) return t;
    const s = MESH.side * dpr;
    const w = 3 * s;
    const h = Math.sqrt(3) * s;
    const c = offscreen(w, h);
    const g = c.ctx;
    g.strokeStyle = "#fff";
    g.lineWidth = MESH.lineWidth * dpr;
    const hex = (cx, cy) => {
      g.beginPath();
      for (let k = 0; k < 6; k++) {
        const a = (Math.PI / 3) * k;
        const x = cx + s * Math.cos(a);
        const y = cy + s * Math.sin(a);
        if (k) g.lineTo(x, y);
        else g.moveTo(x, y);
      }
      g.closePath();
      g.stroke();
    };
    // 单元四角各一个 + 中心一个，重复平铺后正好是完整的蜂窝
    hex(0, 0);
    hex(w, 0);
    hex(0, h);
    hex(w, h);
    hex(w / 2, h / 2);
    t = { tile: c, pattern: g.createPattern(c, "repeat") };
    meshCache.set(key, t);
    return t;
  }

  // 辉光强度：远晕（1/8 尺寸放大回来，约 8–12 px）、宽晕（1/4）、近晕（1/2）各自的不透明度与遍数；
  // 多画一遍让密集点亮区连成一片亮（真管子里相邻段的光会叠加）
  const GLOW = { far: 0.9, farRepeat: 3, wide: 0.8, wideRepeat: 1, near: 0.6 };
  function applyTheme(id) {
    const t = VFD_THEMES[id] || VFD_THEMES[VFD_THEME_DEFAULT];
    const [r, g, b] = t.tint;
    const mix = (k) => [Math.round(255 + (r - 255) * k), Math.round(255 + (g - 255) * k), Math.round(255 + (b - 255) * k)];
    // P3 可用时把同样的分量当作 P3 坐标：P3 的三原色更饱和，同样的数值颜色就更"毒"；核心白不变
    const rgba = HAS_P3
      ? (c, a) => `color(display-p3 ${(c[0] / 255).toFixed(4)} ${(c[1] / 255).toFixed(4)} ${(c[2] / 255).toFixed(4)} / ${a})`
      : (c, a) => `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${a})`;
    VFD.coreRgb = mix(0.06);
    VFD.core = rgba(VFD.coreRgb, 1); // 段本体：接近白（实物照片：发光部分近白，周围的辉光才是磷光色）
    VFD.glow = rgba(t.tint, 1); // 溢光颜色：bloom 只保留发光层的形状（alpha），颜色统一染成磷光色
    VFD.dim = rgba(mix(0.45), 0.8); // 半亮段（只有一个声道到达）
    VFD.ghost = rgba(t.tint, 0.06); // 未点亮段（比原来再暗一档，黑更黑）
    VFD.fill = rgba(t.tint, 0.14);
    VFD.grid = rgba(t.tint, 0.1);
    VFD.text = rgba(mix(0.35), 0.62);
    VFD.textDim = rgba(mix(0.35), 0.35);
    // 数值形式（WebGL 渲染器用；P3 开着时同样的分量按 display-p3 解释，与上面的字符串一致）
    VFD.rgb = { core: VFD.coreRgb, dim: mix(0.45), dimAlpha: 0.8, tint: t.tint, red: [255, 90, 58] };
    state.theme = VFD_THEMES[id] ? id : VFD_THEME_DEFAULT;
    ghostCache = new WeakMap(); // 幽灵层含颜色，换风格后重建
    staticCache = new WeakMap();
    if (glr) glr.setColors(VFD.rgb);
  }
  const WAVE_COLS = LAMP.WAVE_COLS; // 波形窗点阵 384 × 72（BO 决策；尺寸与内核灯板一致）
  const WAVE_ROWS = LAMP.WAVE_ROWS; // 单块显示，L/R 叠加

  function screen(g, W, H) {
    g.clearRect(0, 0, W, H);
    g.fillStyle = VFD.screen;
    g.fillRect(0, 0, W, H);
    const v = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.8);
    v.addColorStop(0, "rgba(0,0,0,0)");
    v.addColorStop(1, VFD.vignette);
    g.fillStyle = v;
    g.fillRect(0, 0, W, H);
    // 玻璃上隐约可见的栅极网
    g.globalAlpha = MESH.faint;
    g.fillStyle = meshTile(dprOf()).pattern;
    g.fillRect(0, 0, W, H);
    g.globalAlpha = 1;
  }

  /** 玻璃感：一道很淡的斜向高光 + 顶边一条细亮线，画在内容之上，让内容"在玻璃后面"。 */
  function glassOverlay(g, W, H) {
    const dpr = dprOf();
    const lg = g.createLinearGradient(0, 0, W * 0.6, H);
    lg.addColorStop(0, "rgba(255,255,255,0.07)");
    lg.addColorStop(0.45, "rgba(255,255,255,0.015)");
    lg.addColorStop(0.5, "rgba(255,255,255,0)");
    g.fillStyle = lg;
    g.fillRect(0, 0, W, H);
    g.fillStyle = "rgba(255,255,255,0.10)";
    g.fillRect(0, 0, W, 1 * dpr);
  }

  /**
   * 溢光（BO 决策：光要洒到屏幕外面）：把发光层最模糊的那级放大一圈画到黑色边框上，只画边框环（玻璃区域挖空），
   * 强度随信号自然变化（发光层本身就是当前帧的亮段）。state.spillAmount 0–2，0 关。
   */
  const spillCanvas = o.spillCanvas || null;
  function spill(e) {
    const amt = state.spillAmount;
    const bezel = o.bezel || null;
    if (!spillCanvas || !bezel) return;
    const dpr = fitCanvas(spillCanvas);
    const g = ctx2d(spillCanvas);
    const W = spillCanvas.width;
    const H = spillCanvas.height;
    g.clearRect(0, 0, W, H);
    if (amt <= 0) return;
    const b = state.bezelPx * dpr;
    if (b <= 0) return;
    const gw = displayCanvas.clientWidth * dpr;
    const gh = displayCanvas.clientHeight * dpr;
    g.save();
    g.beginPath();
    g.rect(0, 0, W, H);
    g.rect(b, b, gw, gh);
    g.clip("evenodd");
    g.imageSmoothingEnabled = true;
    const m = b * 0.75; // 再向外铺一点，光斑边缘落在边框外侧才自然
    const src = e.s16 || e.s8; // 最模糊的一级：洒在边框上的光不该有块状感
    if (!src) return; // GL 后端异步读回的第一帧还没有数据：只清空
    g.globalAlpha = Math.min(1, 0.9 * amt);
    g.drawImage(src, b - m, b - m, gw + 2 * m, gh + 2 * m);
    g.globalAlpha = Math.min(1, 0.5 * amt);
    g.drawImage(src, b - 2 * m, b - 2 * m, gw + 4 * m, gh + 4 * m);
    g.globalAlpha = 1;
    g.restore();
  }

  /** 对已建好的路径做辉光描边（曲线模式用；画在发光层上，溢光由 bloom 生成）。 */
  function glowStroke(g, dpr) {
    g.lineJoin = "round";
    g.lineCap = "round";
    g.strokeStyle = VFD.core;
    g.lineWidth = 1.6 * dpr;
    g.stroke();
  }

  /**
   * 分段点阵几何：把区域 [x0, x0+width] × [yTop, yBottom] 分成 cols 列 × rows 行的小段。
   * 返回每段的绘制函数与坐标换算。
   */
  function segGrid({ x0, width, yTop, yBottom, cols, rows, dpr }) {
    const colW = width / cols;
    const rowH = (yBottom - yTop) / rows;
    const segW = Math.max(1, colW - 2 * dpr);
    const segH = Math.max(1, rowH * 0.55);
    return {
      colW,
      rowH,
      segW,
      segH,
      x: (c) => x0 + c * colW + dpr,
      // 行号 0 在底部
      y: (r) => yBottom - (r + 1) * rowH + (rowH - segH) / 2,
    };
  }

  /** 离屏画布（与目标画布同尺寸）。 */
  function offscreen(w, h) {
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    c.ctx = c.getContext("2d", CANVAS_OPTS);
    return c;
  }

  /**
   * 发光层：每帧把所有点亮的段先画到这层，再由 bloom() 叠到屏幕上。
   * 溢光不用 canvas filter（各浏览器支持不一、软件画布上慢），而是把发光层缩到 1/2、1/4 再放大回来——
   * 双线性放大就是一次廉价的模糊，密集点亮的区域会自然连成一片亮，和真管子一样。
   */
  const litCache = new WeakMap();
  function litLayer(cv) {
    let e = litCache.get(cv);
    if (!e || e.off.width !== cv.width || e.off.height !== cv.height) {
      e = { off: offscreen(cv.width, cv.height), s2: offscreen(cv.width / 2, cv.height / 2), s4: offscreen(cv.width / 4, cv.height / 4), s8: offscreen(cv.width / 8, cv.height / 8), s16: offscreen(cv.width / 16, cv.height / 16) };
      litCache.set(cv, e);
    }
    e.off.ctx.clearRect(0, 0, e.off.width, e.off.height);
    return e;
  }

  /**
   * 把发光层连同溢光叠到 g 上：远晕（1/8）+ 宽晕（1/4）+ 近晕（1/2）+ 清晰的段本体。
   * 辉光强度 state.glowAmount（0–2，1 = 标准）：0 只画段本体；> 1.3 时远晕多画一遍。
   */
  function bloom(g, e, color = VFD.glow, withSpill = true) {
    const { off, s2, s4, s8 } = e;
    const amt = state.glowAmount;
    const needPyramid = amt > 0 || (withSpill && state.spillAmount > 0);
    // 先让栅极网把点亮的段"切"出暗线（网在磷光层前面，溢光也是透过网出来的）
    if (MESH.carve > 0) {
      const oc = off.ctx;
      oc.globalCompositeOperation = "destination-out";
      oc.globalAlpha = MESH.carve;
      oc.fillStyle = meshTile(dprOf()).pattern;
      oc.fillRect(0, 0, off.width, off.height);
      oc.globalAlpha = 1;
      oc.globalCompositeOperation = "source-over";
    }
    if (needPyramid) {
      s2.ctx.clearRect(0, 0, s2.width, s2.height);
      s2.ctx.drawImage(off, 0, 0, s2.width, s2.height);
      // 溢光只取形状、统一染成磷光色（段本体保持近白）：source-in 保留 alpha、替换颜色
      s2.ctx.globalCompositeOperation = "source-in";
      s2.ctx.fillStyle = color;
      s2.ctx.fillRect(0, 0, s2.width, s2.height);
      s2.ctx.globalCompositeOperation = "source-over";
      s4.ctx.clearRect(0, 0, s4.width, s4.height);
      s4.ctx.drawImage(s2, 0, 0, s4.width, s4.height);
      s8.ctx.clearRect(0, 0, s8.width, s8.height);
      s8.ctx.drawImage(s4, 0, 0, s8.width, s8.height);
      if (withSpill && e.s16) {
        e.s16.ctx.clearRect(0, 0, e.s16.width, e.s16.height);
        e.s16.ctx.drawImage(s8, 0, 0, e.s16.width, e.s16.height);
      }
    }
    if (amt > 0) {
      g.imageSmoothingEnabled = true;
      g.globalAlpha = Math.min(1, GLOW.far * amt);
      for (let i = 0; i < GLOW.farRepeat + (amt > 1.3 ? 1 : 0); i++) g.drawImage(s8, 0, 0, off.width, off.height);
      g.globalAlpha = Math.min(1, GLOW.wide * amt);
      for (let i = 0; i < GLOW.wideRepeat; i++) g.drawImage(s4, 0, 0, off.width, off.height);
      g.globalAlpha = Math.min(1, GLOW.near * amt);
      g.drawImage(s2, 0, 0, off.width, off.height);
    }
    g.globalAlpha = 1;
    g.drawImage(off, 0, 0);
    if (withSpill) {
      glassOverlay(g, off.width, off.height);
      spill(e);
    }
  }

  // ---------------------------------------------------------------- 渲染后端：WebGL（默认）/ Canvas 2D（兜底）
  // 阶段 2.9 第 3 批（BO 决策：怎样性能高怎样改）：静态层（玻璃底 + 幽灵段 + 文字 + 基线）仍由 Canvas 2D 画一次、
  // 上传成纹理；每帧变化的点亮格子由 extension/shared/vfd-gl.js 在 GPU 上画，辉光/栅极网/玻璃高光/溢光逐步复现
  // bloom() 的 Canvas 版。拿不到 WebGL（或 ?gl=0）退回原来的 Canvas 2D 路径；?gl=keep 保留绘制缓冲供自动化读像素。
  const GL_MODE = o.glMode || null;
  let glr = null;
  let spillGl = null; // 边框溢光画布也走 GL（两次放大的 drawImage 在软件画布上一帧要 1–4 ms）
  function initGl() {
    try {
      const r = createVfdGl(displayCanvas, { p3: HAS_P3, preserve: GL_MODE === "keep" });
      if (!r) return null;
      // 上下文丢失期间 drawView 直接跳过；恢复后在同一个上下文上重建渲染器（画布已经是 WebGL 的，退不回 2D）
      r.onLost = () => log("WebGL 上下文丢失，显示屏暂停绘制（等恢复）");
      r.onRestored = () => {
        glr = initGl();
        if (glr && VFD.rgb) glr.setColors(VFD.rgb);
        staticCache = new WeakMap();
        log(glr ? "WebGL 上下文已恢复，渲染器重建" : "WebGL 上下文恢复失败");
        if (glr && o.onRestored) o.onRestored();
      };
      if (!spillGl && spillCanvas) initSpillGl();
      return r;
    } catch (err) {
      log(`WebGL 渲染器不可用（${err.message}），改用 Canvas 2D`);
      return null;
    }
  }
  function initSpillGl() {
    spillGl = createSpillGl(spillCanvas, { p3: HAS_P3, preserve: GL_MODE === "keep" });
    if (spillGl) spillGl.onRestored = () => initSpillGl();
  }
  if (GL_MODE !== "0") glr = initGl();
  const rendererName = () => (glr ? `WebGL${glr.p3 ? "·P3" : ""}` : "Canvas 2D");
  log(`显示屏渲染器：${rendererName()}${GL_MODE ? `（glMode=${GL_MODE}）` : ""}`);
  const glRenderer = () => glr; // 调试/自动化
  const spillRenderer = () => spillGl;
  let staticCache = new WeakMap();
  const curveLayerCache = new WeakMap();
  const spillTiny = { cv: null, img: null };

  /**
   * 一帧开始：按 key 准备静态层（玻璃底 + painter 画的幽灵段/文字/基线），返回帧对象 F。
   * 2D：直接画到画布，F.g 可继续画基底内容；GL：静态层缓存成离屏画布并上传，F.g 为 null。
   * painter(og, lg)：幽灵段与文字画到 og，常亮段（红基线）画到 lg（其溢光染红）；key = null 表示每帧重画（曲线视图的基底）。
   */
  function beginFrame(cv, key, painter) {
    const dpr = fitCanvas(cv);
    const W = cv.width;
    const H = cv.height;
    const F = { cv, dpr, W, H, g: null, lit: null, gl: !!glr };
    if (!glr) {
      F.g = ctx2d(cv);
      screen(F.g, W, H);
      if (key !== null) F.g.drawImage(ghostLayer(cv, key, painter), 0, 0);
      else painter(F.g, null);
      return F;
    }
    glr.resize(W, H, dpr);
    let st = staticCache.get(cv);
    if (!st || st.key !== key || key === null || st.off.width !== W || st.off.height !== H) {
      // 同尺寸的离屏复用（每帧重画的基底不反复分配）
      const off = st && st.off.width === W && st.off.height === H ? st.off : offscreen(W, H);
      screen(off.ctx, W, H);
      if (key !== null) off.ctx.drawImage(ghostLayer(cv, key, painter), 0, 0);
      else painter(off.ctx, null);
      st = { key, off };
      staticCache.set(cv, st);
    }
    glr.setStatic(key === null ? `frame${performance.now()}` : key, st.off);
    const mt = meshTile(dpr);
    glr.setMesh(`${dpr}x${MESH.side}x${MESH.lineWidth}`, mt.tile, MESH.carve);
    glr.begin();
    return F;
  }

  /** 2D 路径的发光层（GL 路径不用）。 */
  function litCtx(F) {
    if (!F.lit) F.lit = litLayer(F.cv);
    return F.lit.off.ctx;
  }

  /** 一帧结束：辉光、玻璃高光、溢光。 */
  const overlayLayerCache = new WeakMap();
  function endFrame(F) {
    // 叠加层（启动走马灯等）：画进发光层，跟段一样发光
    if (state.overlay) {
      if (F.gl) {
        let ol = overlayLayerCache.get(F.cv);
        if (!ol || ol.width !== F.W || ol.height !== F.H) {
          ol = offscreen(F.W, F.H);
          overlayLayerCache.set(F.cv, ol);
        }
        ol.ctx.clearRect(0, 0, F.W, F.H);
        state.overlay(ol.ctx, F);
        glr.layer2d(ol);
      } else {
        state.overlay(litCtx(F), F);
      }
    }
    if (!glr) {
      if (F.lit) bloom(F.g, F.lit);
      return;
    }
    const sp = glr.end({ amt: state.glowAmount, far: GLOW.far, farRepeat: GLOW.farRepeat, wide: GLOW.wide, near: GLOW.near, spill: state.spillAmount > 0 && state.bezelPx > 0 });
    if (sp) spillFromBytes(sp);
    else spillClear();
  }

  function spillClear() {
    if (!spillCanvas) return;
    if (spillGl) {
      // 边框画布已是 WebGL 的，退不回 2D；上下文丢失期间什么都不画
      if (spillGl.lost) return;
      fitCanvas(spillCanvas);
      spillGl.clear(spillCanvas.width, spillCanvas.height);
    } else {
      spill({ s16: null, s8: null });
    }
  }

  /** GL 路径的溢光：1/16 级读回的透明度 → 边框画布的 GL 渲染器；没有则染成磷光色的小画布 → 复用 2D 的 spill()。 */
  function spillFromBytes({ w, h, data }) {
    if (spillGl && spillCanvas) {
      if (spillGl.lost) return;
      const amt = state.spillAmount;
      const dpr = fitCanvas(spillCanvas);
      const b = state.bezelPx * dpr;
      if (amt <= 0 || b <= 0) {
        spillGl.clear(spillCanvas.width, spillCanvas.height);
        return;
      }
      spillGl.draw(spillCanvas.width, spillCanvas.height, { w, h, data }, { b, gw: displayCanvas.clientWidth * dpr, gh: displayCanvas.clientHeight * dpr, amt, tint: VFD.rgb.tint.map((v) => v / 255) });
      return;
    }
    if (!spillTiny.cv || spillTiny.cv.width !== w || spillTiny.cv.height !== h) {
      spillTiny.cv = offscreen(w, h);
      spillTiny.img = HAS_P3 ? new ImageData(w, h, { colorSpace: "display-p3" }) : new ImageData(w, h);
    }
    const px = spillTiny.img.data;
    const [r, g, b] = VFD.rgb.tint;
    for (let i = 0; i < w * h; i++) {
      px[i * 4] = r;
      px[i * 4 + 1] = g;
      px[i * 4 + 2] = b;
      px[i * 4 + 3] = data[i * 4];
    }
    spillTiny.cv.ctx.putImageData(spillTiny.img, 0, 0);
    spill({ s16: spillTiny.cv });
  }

  /** 读屏幕像素（自动化用；两种后端一致：RGBA 字节、顶行在前）。GL 下在帧外读需要 ?gl=keep。 */
  const readPixels = (x, y, w, h) => (glr ? glr.readPixels(x, y, w, h) : ctx2d(displayCanvas).getImageData(x, y, w, h).data);
  /** 读边框溢光画布的像素（自动化用）。 */
  const readSpillPixels = (x, y, w, h) => {
    if (spillGl && !spillGl.lost) {
      const gl = spillCanvas.getContext("webgl2") || spillCanvas.getContext("webgl");
      const H = spillCanvas.height;
      const buf = new Uint8Array(w * h * 4);
      gl.readPixels(x, H - y - h, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
      const out = new Uint8ClampedArray(w * h * 4);
      for (let r = 0; r < h; r++) out.set(buf.subarray((h - 1 - r) * w * 4, (h - r) * w * 4), r * w * 4);
      return out;
    }
    return ctx2d(spillCanvas).getImageData(x, y, w, h).data;
  };

  /** 灯板亮度 → 纹理字节（亮度²，与 2D 路径的不透明度一致）；两通道：全亮、半亮。 */
  const brightBytes = { buf: null };
  function brightToBytes(lit, dim, n) {
    if (!brightBytes.buf || brightBytes.buf.length !== n * 2) brightBytes.buf = new Uint8Array(n * 2);
    const o = brightBytes.buf;
    for (let i = 0; i < n; i++) {
      const a = lit[i];
      o[i * 2] = a > 0 ? Math.round(a * a * 255) : 0;
      const b = dim ? dim[i] : 0;
      o[i * 2 + 1] = b > 0 ? Math.round(b * b * 255) : 0;
    }
    return o;
  }

  /** 把一张 [列][行] 的亮度格子（全亮 lit / 半亮 dim 两层）画到发光层：xy(i) 给出格子左上角坐标。 */
  function paintCells(lg, lit, dim, cells, xy, w, h, dpr) {
    for (let i = 0; i < cells; i++) {
      const a = lit[i];
      const b = dim ? dim[i] : 0;
      if (a <= 0 && b <= 0) continue;
      const p = xy(i);
      if (!p) continue;
      if (a >= b) {
        lg.globalAlpha = a * a;
        litSeg(lg, p[0], p[1], w, h, dpr);
      } else {
        lg.globalAlpha = b * b;
        dimSeg(lg, p[0], p[1], w, h, dpr);
      }
    }
    lg.globalAlpha = 1;
  }

  /** 未点亮的幽灵段（含常亮红色基线及其溢光）画一次缓存起来（软件画布下每帧几千个矩形太贵）。 */
  let ghostCache = new WeakMap();
  function ghostLayer(cv, key, painter) {
    let e = ghostCache.get(cv);
    if (!e || e.key !== key) {
      const off = offscreen(cv.width, cv.height);
      const lit = { off: offscreen(cv.width, cv.height), s2: offscreen(cv.width / 2, cv.height / 2), s4: offscreen(cv.width / 4, cv.height / 4), s8: offscreen(cv.width / 8, cv.height / 8) };
      painter(off.ctx, lit.off.ctx); // 幽灵段与文字画到 og；基线等常亮段画到 lg
      bloom(off.ctx, lit, VFD.redGlow, false); // 基线的溢光是红的，不随风格；不参与玻璃高光/外溢
      e = { key, off };
      ghostCache.set(cv, e);
    }
    return e.off;
  }

  /** 画一个点亮的段（到发光层）：近白本体，比几何段稍大一点点让白色能盖住像素；磷光色溢光由 bloom 生成。 */
  function litSeg(g, x, y, w, h, dpr) {
    g.fillStyle = VFD.core;
    g.fillRect(x - 0.3 * dpr, y - 0.3 * dpr, w + 0.6 * dpr, h + 0.6 * dpr);
  }

  /** 半亮段（只有一个声道到达）：偏磷光色、较暗，没有白心。 */
  function dimSeg(g, x, y, w, h, dpr) {
    g.fillStyle = VFD.dim;
    g.fillRect(x - 0.2 * dpr, y - 0.2 * dpr, w + 0.4 * dpr, h + 0.4 * dpr);
  }

  /** 红色基线段（到发光层，溢光在 ghostLayer 里染成红色）。 */
  function redSeg(g, x, y, w, h, dpr) {
    g.fillStyle = VFD.redCore;
    g.fillRect(x - 0.3 * dpr, y - 0.3 * dpr, w + 0.6 * dpr, h + 0.6 * dpr);
  }

  /** 三块显示窗统一的点阵密度：以波形窗 384 列为基准，按 CSS 像素宽度换算（列/像素）。 */
  function dotDensity() {
    const w = waveCanvas.clientWidth || 577;
    return WAVE_COLS / w;
  }

  function fmtBand(hz) {
    if (hz < 1000) return `${Math.round(hz)}`;
    const k = hz / 1000;
    return `${Number.isInteger(k) ? k : k.toFixed(k < 10 ? 2 : 1).replace(/\.?0+$/, "")}k`;
  }

  // ---- 波形：单块分段点阵，L/R 叠加显示——两声道都点亮的段全亮，只有一个声道到达的段半亮（哪些格亮由内核给）
  function drawWave(d) {
    const lamp = feedLamp(d);
    const dpr = dprOf();
    const W = Math.max(1, Math.round(waveCanvas.clientWidth * dpr));
    const H = Math.max(1, Math.round(waveCanvas.clientHeight * dpr));
    const padX = 8 * dpr;
    const padY = 8 * dpr;
    const gr = segGrid({
      x0: padX,
      width: W - padX - 22 * dpr,
      yTop: padY,
      yBottom: H - padY,
      cols: WAVE_COLS,
      rows: WAVE_ROWS + 1, // 最底一行是常亮红色基线
      dpr,
    });
    const grY = gr.y;
    gr.y = (r) => grY(r + 1); // 数据行从 1 起
    const F = beginFrame(waveCanvas, `w${W}x${H}${state.theme}`, (og, lg) => {
      og.fillStyle = VFD.ghost;
      for (let c = 0; c < WAVE_COLS; c++) for (let r = 0; r < WAVE_ROWS; r++) og.fillRect(gr.x(c), gr.y(r), gr.segW, gr.segH);
      for (let c = 0; c < WAVE_COLS; c++) redSeg(lg, gr.x(c), grY(0), gr.segW, gr.segH, dpr);
      og.fillStyle = VFD.textDim;
      og.font = `${7 * dpr}px sans-serif`;
      // 右侧线性刻度
      for (const [v, label] of [[1, "+1"], [0, "0"], [-1, "-1"]]) {
        const r = Math.round((WAVE_ROWS - 1) / 2 + v * ((WAVE_ROWS - 1) / 2));
        og.fillText(label, W - 20 * dpr, gr.y(r) + gr.segH);
      }
      og.fillText("L+R", W - 20 * dpr, H - 3 * dpr);
    });
    if (!lamp) {
      if (F.gl) endFrame(F);
      return;
    }
    const cells = WAVE_COLS * WAVE_ROWS;
    if (F.gl) {
      glr.cells({ x0: padX, colW: gr.colW, rowH: gr.rowH, yBottom: H - padY - gr.rowH, segW: gr.segW, segH: gr.segH, cols: WAVE_COLS, rows: WAVE_ROWS, bars: WAVE_COLS, bright: brightToBytes(lamp.scopeLit(), lamp.scopeDim(), cells) });
    } else {
      paintCells(litCtx(F), lamp.scopeLit(), lamp.scopeDim(), cells, (i) => [gr.x(Math.floor(i / WAVE_ROWS)), gr.y(i % WAVE_ROWS)], gr.segW, gr.segH, dpr);
    }
    endFrame(F);
    const win = lamp.scopeInfo()[0];
    o.onInfo(win > 0 ? `${win} 样本 (${((win / d.sampleRate) * 1000).toFixed(0)} ms) · ${WAVE_COLS}×${WAVE_ROWS} 点阵` : `等待样本… · ${WAVE_COLS}×${WAVE_ROWS} 点阵`);
  }

  // ---- 通用：VFD 点阵柱状（频谱 31 柱 + 右侧 L/R 电平柱，与内核灯板的 33 根柱一一对应）。每根柱由 colsPerBar 个
  // 细点列组成，柱间空 1 列，分组之间（gap:true）多空 groupGap 列；72 行；峰值保持点、OVER、不可用、余晖亮度全部来自灯板。
  const BAR_ROWS = 72; // 与波形窗同密度
  /**
   * 点阵柱状图。bars[] 只描述版面：{label, forceLabel, gap, side}（side = 右侧另有一列刻度的电平柱）；
   * 第 k 根非 gap 的柱对应灯板第 k 根柱。刻度档位（行号与数值）由灯板给：主刻度 = 频谱柱刻度，侧刻度 = 电平柱 K-14。
   */
  function drawDotBars(cv, key, lamp, bars, { titles = [], labelEvery = 1, groupGap = 3 }) {
    const dpr = dprOf();
    const W = Math.max(1, Math.round(cv.clientWidth * dpr));
    const H = Math.max(1, Math.round(cv.clientHeight * dpr));
    const hasSide = bars.some((b) => b.side);
    // 左右刻度文字：两侧留同样的边距（22 px），文字与柱区之间 4 px；左侧右对齐、右侧左对齐
    const padL = 22 * dpr;
    const padR = (hasSide ? 22 : 6) * dpr;
    const labelH = 12 * dpr;
    const overH = 8 * dpr;
    const titleH = titles.length ? 10 * dpr : 0; // 分组标题（PEAK）单独占一行，不再挤在屏幕顶边
    const yTop = 4 * dpr + titleH + overH;
    const yBottom = H - labelH - 3 * dpr;
    // 列布局：可用列数按统一密度换算，再平均分给各柱（柱间空 1 列，分组间空 groupGap 列）；
    // 整除剩下的列全部加到最后一个分组间隔里（有间隔时）——柱区正好填满宽度、点距与波形窗一致，
    // 右侧的 PEAK 电平表贴着右刻度；没有分组时按比例微调点距填满
    const nBars = bars.filter((b) => !b.gap).length;
    const nGaps = bars.filter((b) => b.gap).length;
    const availCols = Math.floor(((W - padL - padR) / dpr) * dotDensity());
    const colsPerBar = Math.max(1, Math.floor((availCols - (nBars - 1) - nGaps * groupGap) / nBars));
    const spare = Math.max(0, availCols - (nBars * (colsPerBar + 1) - 1 + nGaps * groupGap));
    const lastGap = bars.map((b) => !!b.gap).lastIndexOf(true);
    let totalCols = 0;
    const starts = [];
    bars.forEach((b, i) => {
      if (b.gap) {
        totalCols += groupGap + (i === lastGap ? spare : 0);
        starts.push(null);
        return;
      }
      starts.push(totalCols);
      totalCols += colsPerBar + 1;
    });
    totalCols -= 1;
    const gr = segGrid({ x0: padL, width: W - padL - padR, yTop, yBottom, cols: totalCols, rows: BAR_ROWS + 1, dpr });
    const grY = gr.y;
    gr.y = (r) => grY(r + 1); // 最底一行是常亮红色基线，数据行从 1 起
    // 刻度档位来自灯板：[柱档数, 电平档数, 柱档行×8, 柱档值×8, 电平档行×8, 电平档值×8]；行号随 γ 变，所以进幽灵层的键
    const ticks = lamp.ticks();
    const T = LAMP.MAX_TICKS;
    const mainTicks = { count: ticks[0], rows: ticks.subarray(2, 2 + T), values: ticks.subarray(2 + T, 2 + 2 * T) };
    const sideTicks = { count: ticks[1], rows: ticks.subarray(2 + 2 * T, 2 + 3 * T), values: ticks.subarray(2 + 3 * T, 2 + 4 * T) };
    const tickKey = Array.from(ticks).join(",");
    const F = beginFrame(cv, `${key}x${H}x${totalCols}x${tickKey}x${hasSide}x${state.theme}`, (og, lg) => {
      og.fillStyle = VFD.ghost;
      bars.forEach((b, i) => {
        if (b.gap) return;
        for (let k = 0; k < colsPerBar; k++) {
          const c = starts[i] + k;
          for (let r = 0; r < BAR_ROWS; r++) og.fillRect(gr.x(c), gr.y(r), gr.segW, gr.segH);
          og.fillRect(gr.x(c), yTop - overH + 1.5 * dpr, gr.segW, gr.segH); // OVER 段
        }
      });
      bars.forEach((b, i) => {
        if (b.gap) return;
        for (let k = 0; k < colsPerBar; k++) redSeg(lg, gr.x(starts[i] + k), grY(0), gr.segW, gr.segH, dpr);
      });
      og.fillStyle = VFD.text;
      og.font = `${7.5 * dpr}px sans-serif`;
      og.textAlign = "center";
      bars.forEach((b, i) => {
        if (b.gap || !b.label || (i % labelEvery && !b.forceLabel)) return;
        og.fillText(b.label, gr.x(starts[i]) + (colsPerBar * gr.colW - 2 * dpr) / 2, H - 3 * dpr);
      });
      // 分组标题（PEAK）用与底部基线相同的红色（BO 决策）
      og.fillStyle = VFD.redCore;
      // 标题居中在 t.at 与 t.at + 1 两根柱的正中（PEAK 在 L / R 之间，BO 2026-10-04）
      for (const t of titles) {
        const c1 = gr.x(starts[t.at]) + (colsPerBar * gr.colW - 2 * dpr) / 2;
        const c2 = gr.x(starts[t.at + 1]) + (colsPerBar * gr.colW - 2 * dpr) / 2;
        og.fillText(t.text, (c1 + c2) / 2, 4 * dpr + titleH - 2 * dpr);
      }
      og.font = `${7 * dpr}px sans-serif`;
      // 刻度：档位与行号由灯板给（已按 γ 映射）；参考点 0 用亮字，其余暗字；正值带 +；
      // 非线性映射下刻度上疏下密，底部两档离得太近（< 一个字高）时跳过上面那档，不让文字叠在一起（像素避让留在页面）
      const drawScale = (tk, x) => {
        let lastY = -Infinity;
        const n = tk.count;
        if (!n) return;
        const yAt = (i) => gr.y(tk.rows[i] - 1) + gr.segH;
        const bottomY = yAt(n - 1);
        for (let i = 0; i < n; i++) {
          const y = yAt(i);
          if (i !== n - 1 && (y - lastY < 8 * dpr || bottomY - y < 8 * dpr)) continue;
          lastY = y;
          const v = tk.values[i];
          og.fillStyle = v === 0 ? VFD.text : VFD.textDim;
          og.fillText(`${v > 0 ? "+" : ""}${v}`, x, y);
        }
      };
      og.textAlign = "right";
      drawScale(mainTicks, padL - 4 * dpr);
      og.textAlign = "left";
      if (hasSide) drawScale(sideTicks, W - padR + 4 * dpr);
    });
    const info = lamp.barInfo();
    const S = LAMP.INFO_STRIDE;
    const barIdx = [];
    bars.forEach((b, i) => {
      if (!b.gap) barIdx.push(i);
    });
    // 调试/自动化：记录每根柱实际点亮的行数（自动化据此核对刻度映射，不用读像素）
    state.lastBars = state.lastBars || {};
    state.lastBars[cv.id] = barIdx.map((i, bi) => ({ label: bars[i].label, rows: info[bi * S], peakRow: info[bi * S + 1], over: info[bi * S + 2] > 0.5, inactive: info[bi * S + 3] > 0.5, x: gr.x(starts[i]) + (colsPerBar * gr.colW) / 2, y0: gr.y(0) + gr.segH / 2 }));
    const pl = lamp.bars();
    if (F.gl) {
      // 列 → 柱号查找表（空列 255），随版面缓存；亮度纹理每帧上传
      const colKey = `${key}x${totalCols}x${colsPerBar}x${groupGap}`;
      if (!state._colMap || state._colMap.key !== colKey) {
        const m = new Uint8Array(totalCols).fill(255);
        barIdx.forEach((i, bi) => {
          for (let k = 0; k < colsPerBar; k++) m[starts[i] + k] = bi;
        });
        state._colMap = { key: colKey, m };
      }
      glr.cells({ x0: padL, colW: gr.colW, rowH: gr.rowH, yBottom: yBottom - gr.rowH, segW: gr.segW, segH: gr.segH, cols: totalCols, rows: BAR_ROWS, bars: barIdx.length, bright: brightToBytes(pl, null, barIdx.length * BAR_ROWS), colMap: state._colMap.m, colKey });
      const red = VFD.rgb.red.map((v) => v / 255);
      barIdx.forEach((i, bi) => {
        if (info[bi * S + 2] > 0.5) for (let k = 0; k < colsPerBar; k++) glr.rect(gr.x(starts[i] + k), yTop - overH + 1.5 * dpr, gr.segW, gr.segH, 0.3 * dpr, red);
      });
      endFrame(F);
      return;
    }
    const lg = litCtx(F);
    // OVER（削波）红色：由灯板保持计时
    barIdx.forEach((i, bi) => {
      if (info[bi * S + 2] > 0.5) for (let k = 0; k < colsPerBar; k++) redSeg(lg, gr.x(starts[i] + k), yTop - overH + 1.5 * dpr, gr.segW, gr.segH, dpr);
    });
    // 柱身：从底部起连续全亮的一段用缓存的"整列亮段条"一次 drawImage 画出（软件画布下逐段 fillRect
    // 一帧要几万次，是最大的开销）；上方零散的段（峰值保持点、正在淡出的余晖）逐段按亮度画
    const strip = stripLayer(cv, `${key}x${H}x${gr.segW}x${gr.segH}x${gr.rowH}x${state.theme}`, gr, dpr);
    const pad = 0.3 * dpr;
    for (let bi = 0; bi < barIdx.length; bi++) {
      const x0 = starts[barIdx[bi]];
      let full = 0;
      while (full < BAR_ROWS && pl[bi * BAR_ROWS + full] >= 0.999) full++;
      if (full > 0) {
        const sy = gr.y(full - 1) - pad;
        const sh = gr.y(0) + gr.segH + pad - sy;
        lg.globalAlpha = 1; // 上一根柱的淡出段可能把 globalAlpha 留在很小的值——柱身必须全亮
        for (let k = 0; k < colsPerBar; k++) lg.drawImage(strip, 0, sy, strip.width, sh, gr.x(x0 + k) - pad, sy, strip.width, sh);
      }
      for (let r = full; r < BAR_ROWS; r++) {
        const a = pl[bi * BAR_ROWS + r];
        if (a <= 0) continue;
        lg.globalAlpha = a * a;
        for (let k = 0; k < colsPerBar; k++) litSeg(lg, gr.x(x0 + k), gr.y(r), gr.segW, gr.segH, dpr);
      }
    }
    lg.globalAlpha = 1;
    endFrame(F);
  }

  /** 一整列点亮段的缓存条（与画布同高，宽 = 段宽 + 两侧辉光边），供柱身整段 drawImage。 */
  const stripCache = new WeakMap();
  function stripLayer(cv, key, gr, dpr) {
    let e = stripCache.get(cv);
    if (!e || e.key !== key) {
      const pad = 0.3 * dpr;
      const off = offscreen(gr.segW + 2 * pad, cv.height);
      for (let r = 0; r < BAR_ROWS; r++) litSeg(off.ctx, pad, gr.y(r), gr.segW, gr.segH, dpr);
      e = { key, off };
      stripCache.set(cv, e);
    }
    return e.off;
  }

  // ---- 频谱：1/3 倍频程 31 根点阵柱 + 峰值保持 + 右侧 L/R PEAK 电平表（K-14）；曲线模式为连续辉光线
  // 曲线视图的网格只是版面：0 … −96 dB 每 24 dB 一条，与内核 BAR_SCALE 同刻度（曲线高度本身由灯板归一）
  const SPEC_BOTTOM_DB = -96;
  const SPEC_GRID_STEP_DB = 24;

  function drawSpectrum(d) {
    const lamp = feedLamp(d);
    if (state.viewMode === "bars") {
      if (!lamp) return;
      const n = d.barsDb.length;
      const bars = [];
      for (let i = 0; i < n; i++) bars.push({ label: fmtBand(d.barFreq[i]) });
      // 右侧 L/R：PEAK 电平表（BO 决策：代替原来的总电平柱）——块峰值柱身 + 峰值保持点 + OVER，K-14 刻度，跟随同一 γ
      bars.push({ gap: true });
      bars.push({ label: "L", forceLabel: true, side: true });
      bars.push({ label: "R", forceLabel: true, side: true });
      drawDotBars(specCanvas, `s${specCanvas.width}`, lamp, bars, {
        labelEvery: 3,
        groupGap: 5,
        titles: [{ text: "PEAK", at: bars.length - 2 }],
      });
      const gamma = displayParam(FIELD.DP_GAMMA);
      o.onInfo(`1/3 倍频程 ${n} 段 · FFT ${fftLabel()} · 刻度${gamma === 1 ? "线性" : `非线性 γ=${gamma}`} · 右侧 L/R = PEAK（K-14）`);
      return;
    }

    // 曲线：幽灵网格线 + 淡填充 + 辉光线；各点高度（0..1）与历史曲线由灯板给。基底（网格 + 填充 + 文字）每帧随曲线变，
    // 两种后端都按帧画：2D 直接画到画布，GL 画到静态层离屏后上传（曲线视图是次要视图，不做格子化）
    const dpr = dprOf();
    const W = Math.max(1, Math.round(specCanvas.clientWidth * dpr));
    const H = Math.max(1, Math.round(specCanvas.clientHeight * dpr));
    const yTop = 7 * dpr;
    const yBottom = H - 14 * dpr;
    const m = d.curveDb.length;
    if (!m || !lamp) return;
    const yOfH = (h) => yTop + (1 - h) * (yBottom - yTop);
    const yOfDb = (db) => yOfH((Math.max(SPEC_BOTTOM_DB, Math.min(0, db)) - SPEC_BOTTOM_DB) / -SPEC_BOTTOM_DB);
    const x = (i) => (i / (m - 1)) * W;
    const cy = lamp.curve(m);
    const F = beginFrame(specCanvas, null, (g) => {
      g.strokeStyle = VFD.grid;
      g.lineWidth = dpr;
      g.fillStyle = VFD.textDim;
      g.font = `${9 * dpr}px sans-serif`;
      for (let db = 0; db >= SPEC_BOTTOM_DB; db -= SPEC_GRID_STEP_DB) {
        const y = yOfDb(db);
        g.beginPath();
        g.moveTo(0, y);
        g.lineTo(W, y);
        g.stroke();
        g.fillText(`${db}`, 3 * dpr, y - 2 * dpr);
      }
      g.beginPath();
      g.moveTo(x(0), yBottom);
      for (let i = 0; i < m; i++) g.lineTo(x(i), yOfH(cy[i]));
      g.lineTo(x(m - 1), yBottom);
      g.closePath();
      g.fillStyle = VFD.fill;
      g.fill();
      g.fillStyle = VFD.text;
      for (const f of [100, 1000, 10000]) {
        let best = 0;
        for (let i = 1; i < m; i++) if (Math.abs(d.curveFreq[i] - f) < Math.abs(d.curveFreq[best] - f)) best = i;
        g.fillText(fmtHz(f), x(best) + 3 * dpr, H - 3 * dpr);
      }
    });
    let lg;
    if (F.gl) {
      // 曲线用 2D 描边到与画布同尺寸的离屏层，再整层叠进发光层
      let cl = curveLayerCache.get(specCanvas);
      if (!cl || cl.width !== W || cl.height !== H) {
        cl = offscreen(W, H);
        curveLayerCache.set(specCanvas, cl);
      }
      cl.ctx.clearRect(0, 0, W, H);
      lg = cl.ctx;
    } else {
      lg = litCtx(F);
    }
    // 曲线的余晖：灯板保留最近若干帧的曲线，按各自剩余亮度画在当前曲线下面（当帧那一槽亮度 1，与当前曲线重合）
    const br = lamp.curveHistBr();
    for (let s = 0; s < LAMP.CURVE_HISTORY; s++) {
      if (br[s] <= 0 || br[s] >= 1) continue;
      const hy = lamp.curveHist(s, m);
      lg.globalAlpha = br[s] * br[s];
      lg.beginPath();
      for (let i = 0; i < m; i++) (i ? lg.lineTo : lg.moveTo).call(lg, x(i), yOfH(hy[i]));
      glowStroke(lg, dpr);
    }
    lg.globalAlpha = 1;
    if (!d.idle) {
      lg.beginPath();
      for (let i = 0; i < m; i++) (i ? lg.lineTo : lg.moveTo).call(lg, x(i), yOfH(cy[i]));
      glowStroke(lg, dpr);
    }
    if (F.gl) glr.layer2d(curveLayerCache.get(specCanvas));
    endFrame(F);
    o.onInfo(`频谱曲线 ${m} 点 · FFT ${fftLabel()}`);
  }


  // 视图切换：波形 / 频程 / 曲线（同一块屏）
  function drawView(d) {
    if (glr && glr.lost) return; // 上下文丢失：等恢复
    if (state.viewMode === "scope") drawWave(d);
    else drawSpectrum(d);
  }

  return {
    drawView,
    drawWave,
    drawSpectrum,
    applyTheme,
    VFD_THEMES,
    VFD_THEME_DEFAULT,
    VFD,
    GLOW,
    MESH,
    rendererName,
    glRenderer,
    spillRenderer,
    readPixels,
    readSpillPixels,
    brightToBytes,
    beginFrame,
    endFrame,
    fitCanvas,
    WAVE_COLS,
    WAVE_ROWS,
  };
}
