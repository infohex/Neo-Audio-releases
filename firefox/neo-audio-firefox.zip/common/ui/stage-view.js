// Neo Audio — 虚拟舞台顶视图（阶段 4.2，BO 2026-10-15）。
//
// 一块 canvas：听者在圆心、正前方朝上，每个声音元素是一个带标签的圆点（颜色按种类），
// 鼠标按住拖动 → 方位角（0° 正前方，顺时针为右侧，±180° 正后方）与距离（0 圆心 … 1 外圈）实时下发到引擎；
// 元素的宽度画成圆点所在半径上的一段弧（声部左右声道落在弧的两端）。静音的元素变淡。
// 坐标换算用 getBoundingClientRect，所以面板整体 zoom 不影响命中。
// 视觉（颜色 / 尺寸）由 BO 自己调：颜色在 KIND_COLORS，尺寸在 DOT_R / 边距。

import { t } from "../i18n.js";

/** 元素种类 → 圆点颜色（鼓 / 贝斯 / 人声 / 其它）。 */
export const KIND_COLORS = ["#d9774f", "#5b8dd6", "#c99a58", "#8c9a80"];
const DOT_R = 9;
const MARGIN = 26;
/** 演示：人声绕听者的角速度（度 / 秒，360° 一圈 10 s）与刷新间隔（ms；用定时器而不是 rAF，标签页在后台音乐照放、圈也照转）。 */
const DEMO_DEG_PER_S = 36;
const DEMO_TICK_MS = 40;

/**
 * @param {{canvas:HTMLCanvasElement, elements:()=>Array<{kind:number,label:string,az:any,dist:any,width:any,gain:any}>, touch?:()=>void, changed?:()=>void}} o
 *   elements()：面板建好的元素（az / dist / width 是登记在 controls 里的虚拟控件，gain 是增益推子）。
 * 返回 { redraw(), demo(on?), destroy() }。示意图右上角有"演示"键（BO 2026-10-16）：人声按当前半径绕听者顺时针转，
 * 拖动人声时暂停跟随、松手后从新位置 / 新半径继续；再点一次停止。
 */
export function createStageView(o) {
  const canvas = o.canvas;
  const ctx = canvas.getContext("2d");
  const W = canvas.width;
  const H = canvas.height;
  const cx = W / 2;
  const cy = H / 2;
  const R = Math.min(W, H) / 2 - MARGIN;
  const touch = o.touch || (() => {});
  const css = (name, fallback) => {
    try {
      const v = getComputedStyle(canvas).getPropertyValue(name).trim();
      return v || fallback;
    } catch (_) {
      return fallback;
    }
  };
  const rad = (deg) => (deg * Math.PI) / 180;
  const posOf = (el) => {
    const r = el.dist.value * R;
    return { x: cx + Math.sin(rad(el.az.value)) * r, y: cy - Math.cos(rad(el.az.value)) * r };
  };

  function draw() {
    const ink = css("--ink", "#333");
    const line = css("--line", "rgba(0,0,0,0.2)");
    const muted = css("--muted", "rgba(0,0,0,0.5)");
    ctx.clearRect(0, 0, W, H);
    ctx.lineWidth = 1;
    ctx.strokeStyle = line;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, R / 2, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - R, cy);
    ctx.lineTo(cx + R, cy);
    ctx.moveTo(cx, cy - R);
    ctx.lineTo(cx, cy + R);
    ctx.stroke();
    ctx.fillStyle = muted;
    ctx.font = "11px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(t("st.front"), cx, cy - R - 12);
    // 听者：圆头 + 朝前的鼻子
    ctx.fillStyle = ink;
    ctx.beginPath();
    ctx.arc(cx, cy, 7, 0, 2 * Math.PI);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - 4, cy - 5);
    ctx.lineTo(cx, cy - 12);
    ctx.lineTo(cx + 4, cy - 5);
    ctx.closePath();
    ctx.fill();
    for (const el of o.elements()) {
      const p = posOf(el);
      const col = KIND_COLORS[el.kind] || ink;
      const off = !!(el.gain && el.gain.row && el.gain.row.classList.contains("off"));
      const r = el.dist.value * R;
      const w = rad(el.width.value);
      ctx.globalAlpha = off ? 0.35 : 1;
      if (w > 0.01 && r > 4) {
        const a0 = rad(el.az.value) - Math.PI / 2;
        ctx.strokeStyle = col;
        ctx.lineWidth = 3;
        ctx.globalAlpha = off ? 0.15 : 0.4;
        ctx.beginPath();
        ctx.arc(cx, cy, r, a0 - w / 2, a0 + w / 2);
        ctx.stroke();
        ctx.globalAlpha = off ? 0.35 : 1;
      }
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.arc(p.x, p.y, DOT_R, 0, 2 * Math.PI);
      ctx.fill();
      ctx.strokeStyle = ink;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillStyle = ink;
      ctx.font = "bold 11px system-ui, sans-serif";
      ctx.fillText(el.label, p.x, p.y + DOT_R + 10);
      ctx.globalAlpha = 1;
    }
  }

  // ---- 拖动
  let drag = null; // { el, pending:boolean }
  const toCanvas = (e) => {
    const rect = canvas.getBoundingClientRect();
    return { x: ((e.clientX - rect.left) * W) / rect.width, y: ((e.clientY - rect.top) * H) / rect.height };
  };
  const hit = (pt) => {
    let best = null;
    let bd = 16;
    for (const el of o.elements()) {
      const p = posOf(el);
      const d = Math.hypot(p.x - pt.x, p.y - pt.y);
      if (d < bd) {
        bd = d;
        best = el;
      }
    }
    return best;
  };
  const apply = (el, pt) => {
    const dx = pt.x - cx;
    const dy = pt.y - cy;
    let az = (Math.atan2(dx, -dy) * 180) / Math.PI;
    if (az <= -180) az += 360;
    const dist = Math.min(1, Math.hypot(dx, dy) / R);
    const azQ = Math.round(az * 2) / 2; // 0.5° 步进，拖动时少发几条消息
    const distQ = Math.round(dist * 200) / 200;
    if (el.az.value !== azQ) el.az.setValue(azQ, true);
    if (el.dist.value !== distQ) el.dist.setValue(distQ, true);
  };
  canvas.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const el = hit(toCanvas(e));
    if (!el) return;
    drag = { el };
    canvas.setPointerCapture(e.pointerId);
    canvas.classList.add("dragging");
    e.preventDefault();
    e.stopPropagation();
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!drag) return;
    apply(drag.el, toCanvas(e));
    draw();
    e.preventDefault();
    e.stopPropagation();
  });
  const end = (e) => {
    if (!drag) return;
    drag = null;
    canvas.classList.remove("dragging");
    try {
      canvas.releasePointerCapture(e.pointerId);
    } catch (_) {
      /* 已释放 */
    }
    touch();
    if (o.changed) o.changed();
    draw();
  };
  canvas.addEventListener("pointerup", end);
  canvas.addEventListener("pointercancel", end);
  canvas.addEventListener("contextmenu", (e) => e.preventDefault());

  // ---- 演示：人声绕听者转圈
  let demo = null; // { last, timer }
  const vocals = () => o.elements().find((el) => el.kind === 2) || null;
  const box = canvas.parentElement;
  let btn = null;
  if (box) {
    btn = document.createElement("button");
    btn.type = "button";
    btn.className = "stage-demo";
    btn.textContent = t("st.demo");
    btn.title = t("st.demo.tip");
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      setDemo(!demo);
    });
    btn.addEventListener("pointerdown", (e) => e.stopPropagation()); // 别当成拖面板
    box.appendChild(btn);
  }
  function tick() {
    if (!demo) return;
    const el = vocals();
    const now = performance.now();
    const dt = Math.min(0.2, (now - demo.last) / 1000);
    demo.last = now;
    if (el && !(drag && drag.el === el)) {
      let az = el.az.value + DEMO_DEG_PER_S * dt;
      while (az > 180) az -= 360;
      az = Math.round(az * 2) / 2; // 0.5° 步进，同拖动
      if (az !== el.az.value) el.az.setValue(az, true);
      draw();
    }
  }
  function setDemo(on) {
    if (on && !demo) {
      if (!vocals()) return;
      demo = { last: performance.now(), timer: setInterval(tick, DEMO_TICK_MS) };
      if (btn) btn.classList.add("active");
    } else if (!on && demo) {
      clearInterval(demo.timer);
      demo = null;
      if (btn) btn.classList.remove("active");
      touch(); // 停下的位置记进设置
      if (o.changed) o.changed();
      draw();
    }
  }

  draw();
  return {
    redraw: draw,
    demo: setDemo,
    get demoOn() {
      return !!demo;
    },
    destroy() {
      setDemo(false);
      if (btn) btn.remove();
    },
  };
}
