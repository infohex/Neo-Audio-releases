// Neo Audio — 页内面板（阶段 3.2；BO 2026-10-07：页底常驻一个半透明按钮，点开才是完整面板；显示屏可关；设置自动保存 + 命名配置）。
//
// 挂在页面 documentElement 下的一个自定义元素里，closed Shadow DOM，样式来自 panel.css（adoptedStyleSheets），
// 不受页面样式 / CSP 影响也不污染页面。引擎在别处（Chrome：offscreen 宿主；Firefox：同一 content script 的宿主），
// 这里只有 EngineClient + 自己的 wasm 实例（灯板、模块 11、参数元数据）。控件 / 面板 / 显示屏 / 设置全部复用 common 下的模块。
//
// mountPanel(env)：
//   env.assetUrl(path)   扩展内资源 URL（panel.css 等）
//   env.wasmUrl          dsp_wasm.wasm 的 URL（UI 侧本地实例用）
//   env.connect(onDisconnect) → runtime.Port（或任何协议端点；有 onMessage.addListener 的按 runtime.Port 处理）
//   env.onStop()         电源键：请求停止处理（Chrome：SW 关掉捕获与宿主，再让这里卸载）
//   env.store            可选，Settings 的存储；默认自动选（扩展里是 storage.local）
//   env.log(text)
// 返回 { unmount, open, close, toggle, state, root, $ }（自动化用 window.__neoAudio.panel）。

import { NeoAudio, MODULE, FIELD, METER } from "../../shared/neo-audio-node.js";
import { EngineClient } from "../client.js";
import { wrapJsonPort, createLocalChannel } from "../protocol.js";
import { Settings } from "../settings.js";
import { createControls } from "./controls.js";
import { createPanels } from "./panels.js";
import { createStageView } from "./stage-view.js";
import { createVfd } from "./vfd.js";
import { t, ts, setLang, lang, LANGS } from "../i18n.js";
import { createStore } from "../settings.js";

const NONLINEAR_GAMMA = 2;
/** 界面配色预设（panel.css 里的 .root[data-ui]）；默认 Neo Dark（BO 2026-10-08），莫兰迪只留给测试页。 */
export const UI_THEMES = [
  { id: "E", name: () => "Neo Dark" },
  { id: "A", name: () => t("theme.A") },
  { id: "B", name: () => t("theme.B") },
  { id: "C", name: () => t("theme.C") },
  { id: "D", name: () => t("theme.D") },
];
const UI_THEME_DEFAULT = "E";
/** 整体缩放档位（BO 2026-10-09） */
export const UI_ZOOMS = [0.5, 0.75, 1, 1.5, 2];
/** 显示屏弹出态的缩放档位与透明度档位（BO 2026-10-15） */
export const POP_ZOOMS = [0.5, 0.75, 1, 1.5, 2, 3];
export const POP_ALPHAS = [1, 0.8, 0.6, 0.4];
const METER_COUNT_IDLE = 11;
const RESET_MODULES = {
  output: [MODULE.OUTPUT],
  eq: [MODULE.EQ],
  tone: [MODULE.TRUEBASS, MODULE.TREBLE],
  width: [MODULE.WIDTH],
  reverb: [MODULE.REVERB],
  surround: [MODULE.SURROUND],
  stage: [MODULE.STAGE],
};

export function panelHtml() {
  return `
<div class="root" id="root" data-open="false">
  <button class="fab" id="fab" title="Neo Audio" aria-label="Neo Audio"><span class="dot"></span>N</button>
  <div class="panel" id="panel" hidden>
    <div class="corner"><button class="icon" id="collapse" title="${t("collapse")}">&#x25BE;</button><button class="icon" id="power" title="${t("power")}">&#x23FB;</button></div>
    <div class="head">
      <div class="brand"><b class="title">Neo Audio</b></div>
    </div>
    <div class="head head-ctl">

      <label class="vol" title="${t("volume.tip")}"><span>${t("volume")}</span><input id="volume" type="range" min="0" max="1" step="0.01" /></label>
      <label title="${t("bypass.tip")}"><span>${t("bypass")}</span><label class="switch"><input id="bypass" type="checkbox" /><span></span></label></label>
      <span class="status" id="status">—</span>
    </div>
    <div class="warn" id="warn" hidden></div>
    <div class="prefs">
      <div class="pmenu" id="pmenu" title="${t("profiles.tip")}">
        <button class="pbtn" id="profile-btn" aria-haspopup="menu" aria-expanded="false"><span class="plabel">${t("profile")}</span><span class="pcur" id="profile-cur">${t("profile.unnamed")}</span><span class="caret">&#x25BE;</span></button>
        <div class="pmenu-list" id="profile-menu" role="menu" hidden>
          <div class="pmenu-items" id="profile-items"></div>
          <div class="pmenu-sep"></div>
          <button class="pitem" id="profile-save" disabled title="${t("profile.save.tip")}">${t("profile.save")}</button>
          <button class="pitem" id="profile-saveas" title="${t("profile.saveas.tip")}">${t("profile.saveas")}</button>
          <input id="profile-name" type="text" placeholder="${t("profile.namePh")}" hidden />
          <button class="pitem" id="profile-delete" disabled>${t("profile.delete")}</button>
          <div class="pmenu-sep"></div>
          <button class="pitem" id="profile-export" title="${t("profile.export.tip")}">${t("profile.export")}</button>
          <button class="pitem" id="profile-import" title="${t("profile.import.tip")}">${t("profile.import")}</button>
          <input id="profile-file" type="file" accept="application/json,.json" hidden />
        </div>
      </div>
      <label class="ui-theme" title="${t("theme.tip")}">${t("theme")} <select id="ui-theme"></select></label>
      <label class="ui-lang" title="${t("lang.tip")}">${t("lang")} <select id="ui-lang"></select></label>
      <label class="ui-zoom" title="${t("zoom.tip")}">${t("zoom")} <select id="ui-zoom"></select></label>
    </div>
    <div class="screen" id="screen">
      <div class="bezel" id="bezel" title="${t("display.hint")}"><canvas id="display"></canvas><canvas id="spill"></canvas></div>
      <div class="screen-tools" id="screen-tools">
        <label title="${t("display.tip")}"><label class="switch"><input id="display-on" type="checkbox" checked /><span></span></label></label>
        <span class="seg"><button id="mode-scope">${t("view.scope")}</button><button id="mode-bars" class="active">${t("view.bars")}</button><button id="mode-curve">${t("view.curve")}</button></span>
        <label>${t("scale")} <span class="seg"><button id="scale-linear">${t("scale.linear")}</button><button id="scale-nonlinear" class="active">${t("scale.nonlinear")}</button></span></label>
        <label>${t("vfdStyle")} <select id="vfd-theme"></select></label>
      </div>
      <div class="screen-tools screen-tools2" id="screen-tools2">
        <label>${t("glow")} <input id="vfd-glow" type="range" min="0" max="2" step="0.1" /></label>
        <label>${t("afterglow")} <input id="vfd-afterglow" type="range" min="0" max="300" step="10" /></label>
        <label>${t("spill")} <input id="vfd-spill" type="range" min="0" max="2" step="0.1" /></label>
        <label>${t("bezel")} <input id="vfd-bezel" type="range" min="0" max="40" step="4" /></label>
      </div>
    </div>
    <div class="tabs" id="tabs">
      <button data-tab="eq" class="active">${t("tab.eq")}</button><button data-tab="tone">${t("tab.tone")}</button><button data-tab="width">${t("tab.width")}</button><button data-tab="reverb">${t("tab.reverb")}</button><button data-tab="surround">${t("tab.surround")}</button><button data-tab="stage">${t("tab.stage")}</button><button data-tab="output">${t("tab.output")}</button>
    </div>
    <section class="panel-sec" id="panel-eq" data-tab="eq">
      <div class="panel-head"><div class="mod"><h2>${t("mod.eq")}</h2><label class="module-switch" title="${t("module.tip")}"><label class="switch"><input id="en-eq" type="checkbox" /><span></span></label></label></div><div class="tools"><label>${t("eq.comp")} <label class="switch"><input id="eq-comp" type="checkbox" checked /><span></span></label></label><button class="btn-default" data-reset="eq">Default</button></div></div>
      <div class="faders eq" id="eq"></div>
    </section>
    <section class="panel-sec" id="panel-tone" data-tab="tone" hidden>
      <div class="panel-head"><div class="mod"><h2>${t("mod.tone")}</h2><label class="module-switch">${t("tone.bass")} <label class="switch"><input id="en-truebass" type="checkbox" /><span></span></label></label><label class="module-switch">${t("tone.treble")} <label class="switch"><input id="en-treble" type="checkbox" /><span></span></label></label></div><div class="tools"><button class="btn-default" data-reset="tone">Default</button></div></div>
      <div class="faders" id="tone"><div class="fgroup" id="truebass"></div><span class="fsep"></span><div class="fgroup" id="treble"></div></div>
      <div class="readouts"><span>${t("ro.bass")}</span><output id="ro-tb">—</output><span>${t("ro.treble")}</span><output id="ro-tr">—</output></div>
    </section>
    <section class="panel-sec" id="panel-width" data-tab="width" hidden>
      <div class="panel-head"><div class="mod"><h2 title="${t("mod.width.tip")}">${t("mod.width")}</h2><label class="module-switch" title="${t("module.tip")}"><label class="switch"><input id="en-width" type="checkbox" /><span></span></label></label></div><div class="tools"><button class="btn-default" data-reset="width">Default</button></div></div>
      <div class="faders" id="width"></div>
      <div class="readouts" id="w-hint" hidden><span>${t("w.hint")}</span></div>
    </section>
    <section class="panel-sec" id="panel-reverb" data-tab="reverb" hidden>
      <div class="panel-head"><div class="mod"><h2>${t("mod.reverb")}</h2><label class="module-switch" title="${t("module.tip")}"><label class="switch"><input id="en-reverb" type="checkbox" /><span></span></label></label></div><div class="tools"><label>${t("preset")} <select id="reverb-preset"></select></label><button class="btn-default" data-reset="reverb">Default</button></div></div>
      <div class="faders" id="reverb"></div>
    </section>
    <section class="panel-sec" id="panel-surround" data-tab="surround" hidden>
      <div class="panel-head"><div class="mod"><h2 class="sr-hint" id="sr-hint">${t("mod.surround")} <svg class="spk" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M3 9v6h4l5 4V5L7 9H3z" fill="currentColor"/><path d="M15.5 8.5a4.5 4.5 0 0 1 0 7M18.5 5.5a8.5 8.5 0 0 1 0 13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg><img class="sr-pop" id="sr-pop" alt="5.1" draggable="false" /></h2><label class="module-switch" title="${t("module.tip")}"><label class="switch"><input id="en-surround" type="checkbox" /><span></span></label></label></div><div class="tools"><label>${t("render")} <span class="seg" id="sr-mode"></span></label><label>LFE <span class="seg" id="sr-xover"></span></label><label>${t("timbre")} <label class="switch"><input id="sr-timbre" type="checkbox" /><span></span></label></label><button class="btn-default" data-reset="surround">Default</button></div></div>
      <div class="faders" id="surround"></div>
      <div class="readouts"><span>${t("ro.lr")}</span><output id="ro-sr-lr">—</output><span>${t("ro.cs")}</span><output id="ro-sr-cs">—</output><span>${t("ro.delay")}</span><output id="ro-sr-delay">—</output></div>
    </section>
    <section class="panel-sec" id="panel-stage" data-tab="stage" hidden>
      <div class="panel-head"><div class="mod"><h2 title="${t("mod.stage.tip")}">${t("mod.stage")}</h2><label class="module-switch" title="${t("module.tip")}"><label class="switch"><input id="en-stage" type="checkbox" /><span></span></label></label></div><div class="tools"><label>${t("render")} <span class="seg" id="st-mode"></span></label><label>${t("st.device")} <span class="seg" id="st-device"></span></label><button class="btn-default" id="st-layout" type="button">${t("st.layoutReset")}</button><button class="btn-default" data-reset="stage">Default</button></div></div>
      <div class="stage-row fit-row" id="stage-row"><div class="stage-col"><div class="faders" id="stage"></div><div class="faders" id="stage-mod"></div></div><div class="stage-box" id="stage-box" title="${t("st.hint.drag")}"><canvas id="stage-view" width="300" height="300"></canvas></div></div>
      <div class="readouts model-row callout" id="st-setup" hidden><span id="st-setup-text"></span><button id="st-setup-dl" type="button">${t("st.model.download")}</button></div>
      <div class="readouts model-row" id="st-model"><span>${t("st.model")}</span><output id="ro-st-model">—</output><progress id="st-model-bar" max="1" value="0" hidden></progress><button id="st-model-dl" type="button">${t("st.model.download")}</button><button id="st-model-del" type="button" hidden>${t("st.model.delete")}</button><output id="ro-st-engine">—</output></div>
      <div class="readouts"><span>${t("ro.stLatency")}</span><output id="ro-st-latency">—</output><span>${t("ro.stRtf")}</span><output id="ro-st-rtf">—</output><span>${t("ro.stLate")}</span><output id="ro-st-late">—</output><span class="sys" title="${t("ro.sys.tip")}">${t("ro.cpu")}</span><output class="sys" id="ro-st-cpu" title="${t("ro.sys.tip")}">—</output><span class="sys" title="${t("ro.sys.tip")}">${t("ro.mem")}</span><output class="sys" id="ro-st-mem" title="${t("ro.sys.tip")}">—</output></div>
      <div class="readouts" id="st-hint" hidden><span>${t("st.hint.fallback")}</span></div>
      <div class="readouts"><span>${t("st.hint.video")}</span></div>
    </section>
    <section class="panel-sec" id="panel-output" data-tab="output" hidden>
      <div class="panel-head"><div class="mod"><h2>${t("mod.output")}</h2></div><div class="tools"><button class="btn-default" data-reset="output">Default</button></div></div>
      <div class="faders" id="output-controls"></div>
    </section>
    <div class="hbar" id="hbar" title="${t("hbar.tip")}"><span class="tri"></span></div>
  </div>
  <div class="pop" id="pop" hidden></div>
  <div class="pmenu-list dmenu" id="dmenu" role="menu" hidden>
    <div class="dmenu-title">${t("pop.zoom")}</div>
    <div class="dmenu-row" id="dmenu-zoom"></div>
    <div class="pmenu-sep"></div>
    <div class="dmenu-title">${t("pop.alpha")}</div>
    <div class="dmenu-row" id="dmenu-alpha"></div>
  </div>
</div>`;
}

/**
 * 面板宽度自适应（BO 2026-10-14，第二版）：以最宽的那个页签为准——量每个页签（临时显示隐藏的）里各推子行一行排开所需的宽度
 * （.fsep 占满一行的算换行），取最大值，加面板内边距，夹在 560 与视口之间；切页签时宽度不变。高度随内容。导出给预览页用。
 */
export function fitPanelWidth(panel, zoom = 1) {
  if (panel.hidden || !panel.getBoundingClientRect().width) return 0; // 没渲染（整个 UI 被藏着，如视频全屏）时量不到东西，别改宽度
  const secs = [...panel.querySelectorAll("section.panel-sec")];
  if (!secs.length) return 0;
  let need = 0;
  const rows = [];
  for (const s of secs) {
    if (!s.hidden) {
      rows.push(...s.querySelectorAll(".faders"));
      continue;
    }
    s.hidden = false; // 量完立刻藏回去，同一帧内不会画出来
    rows.push(...s.querySelectorAll(".faders"));
    s.dataset.measuring = "1";
  }
  for (const row of rows) {
    if (row.querySelector(".faders")) continue; // 只量最内层的推子行
    const gap = parseFloat(getComputedStyle(row).columnGap) || 0;
    const cs = getComputedStyle(row);
    const pad = (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
    let sum = 0;
    let n = 0;
    for (const ch of row.children) {
      if (ch.classList.contains("fsep") && getComputedStyle(ch).flexBasis === "100%") {
        need = Math.max(need, sum + pad);
        sum = 0;
        n = 0;
        continue;
      }
      if (!ch.offsetWidth) continue;
      sum += ch.offsetWidth + (n ? gap : 0);
      n++;
    }
    need = Math.max(need, sum + pad);
  }
  // 固定宽度的块也要放得下；.fit-row 是并排的一行（舞台：推子 + 顶视图），按子元素宽度之和算
  for (const el of panel.querySelectorAll(".fit-width")) if (el.offsetWidth) need = Math.max(need, el.offsetWidth);
  for (const row of panel.querySelectorAll(".fit-row")) {
    const gap = parseFloat(getComputedStyle(row).columnGap) || 0;
    let sum = 0;
    let n = 0;
    for (const ch of row.children) {
      if (!ch.offsetWidth) continue;
      sum += ch.scrollWidth + (n ? gap : 0);
      n++;
    }
    need = Math.max(need, sum);
  }
  for (const s of secs) {
    if (s.dataset.measuring) {
      s.hidden = true;
      delete s.dataset.measuring;
    }
  }
  // 显示屏（固定 560 px 画布 + 边框）开着时也要放得下
  const bezel = panel.querySelector(".bezel");
  if (bezel && bezel.offsetWidth) need = Math.max(need, bezel.offsetWidth);
  const pcs = getComputedStyle(panel);
  const chrome = (parseFloat(pcs.paddingLeft) || 0) + (parseFloat(pcs.paddingRight) || 0) + (parseFloat(pcs.borderLeftWidth) || 0) + (parseFloat(pcs.borderRightWidth) || 0);
  const maxW = Math.floor((window.innerWidth - 16) / zoom);
  const w = Math.max(560, Math.min(maxW, Math.ceil(need + chrome + 2)));
  panel.style.width = `${w}px`; // 面板 overflow: hidden；区块滚动条占的宽度由 fitSectionHeight 补
  panel.dataset.secSb = "0";
  return w;
}

/**
 * 面板放不下（被 max-height / 手动高度压住）时，让当前模块区块在自己里面滚：区块 max-height = 它现在的高 − 面板多出来的部分。
 * 出了滚动条就把它占的宽度补进面板宽度（滚动条从布局里扣宽度，推子 + 顶视图那行会被裁）。每次都从头算，重复调用不累加。
 */
export function fitSectionHeight(panel, zoom = 1) {
  const secs = [...panel.querySelectorAll("section.panel-sec")];
  for (const s of secs) {
    s.style.maxHeight = "";
    s.style.overflowY = ""; // 平时 visible：弹出的 5.1 示意图等不能被区块裁掉
    s.style.overflowX = "";
  }
  const prevSb = parseFloat(panel.dataset.secSb || "0") || 0;
  if (prevSb) panel.style.width = `${parseFloat(panel.style.width) - prevSb}px`;
  panel.dataset.secSb = "0";
  const sec = secs.find((s) => !s.hidden);
  if (!sec || panel.hidden) return 0;
  const extra = panel.scrollHeight - panel.clientHeight;
  if (extra <= 0) return 0;
  sec.style.maxHeight = `${Math.max(120, sec.offsetHeight - extra)}px`;
  sec.style.overflowY = "auto";
  sec.style.overflowX = "hidden";
  const sb = sec.offsetWidth - sec.clientWidth;
  if (sb > 0) {
    const maxW = Math.floor((window.innerWidth - 16) / zoom);
    panel.style.width = `${Math.min(maxW, parseFloat(panel.style.width) + sb)}px`;
    panel.dataset.secSb = String(sb);
  }
  return sb;
}

export async function mountPanel(env) {
  const log = env.log || (() => {});
  // 语言：保存过的设置优先，否则英文（BO 2026-10-08：默认英文）；要在建模板之前定下来
  const store = env.store || createStore();
  try {
    const rec = await store.get("neo.current");
    setLang((rec && rec.extras && rec.extras.lang) || "en");
  } catch (_) {
    setLang("en");
  }
  const hostEl = document.createElement("neo-audio-root");
  // open：页面脚本能看到面板 DOM（自动化靠这个驱动），样式仍由 Shadow DOM 隔离；JS 对象在 content script 的隔离世界里，页面碰不到
  const root = hostEl.attachShadow({ mode: "open" });
  // 样式：adoptedStyleSheets（不受页面 CSP 的 style-src 限制），老浏览器退回 <style>
  const cssText = await (await fetch(env.assetUrl("common/ui/panel.css"))).text();
  try {
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(cssText);
    root.adoptedStyleSheets = [sheet];
  } catch (_) {
    const st = document.createElement("style");
    st.textContent = cssText;
    root.appendChild(st);
  }
  const wrap = document.createElement("div");
  wrap.innerHTML = panelHtml();
  root.appendChild(wrap);
  const $ = (id) => root.getElementById(id);
  const fab = $("fab");
  const panel = $("panel");
  // 显示屏弹出态用到的元素（BO 2026-10-15）：设置读回时就会调用 applyPop / setPopup，所以在这里先拿到
  const bezel = $("bezel");
  const popBox = $("pop");
  const screenBox = $("screen");
  const dmenu = $("dmenu");
  const VIEW_CYCLE = ["scope", "bars", "curve"];
  $("root").setAttribute("lang", lang()); // 字体栈、断行与推子宽度按语言（panel.css）
  (document.body || document.documentElement).appendChild(hostEl);

  const state = {
    theme: "kenwood",
    glowAmount: 0.3,
    afterglowMs: 50,
    spillAmount: 1,
    bezelPx: 10,
    viewMode: "bars",
    barScale: "nonlinear",
    overlay: null,
    lastBars: null,
    _colMap: null,
    lastDisplay: null,
    displayOn: true,
    open: false,
    hover: false, // 鼠标悬在圆钮上：取显示帧让圆钮随电平跳动（BO 2026-10-08）
    bypass: false,
    volume: 1,
    tab: "eq",
    fab: null, // {x: 视口宽度比例, y: 距底 px}
    panelPos: null, // {x, y}：面板左上角（视口 px）；空 = 锚在圆钮上方
    uiTheme: UI_THEME_DEFAULT, // 界面配色预设 id（UI_THEMES）
    pop: { on: false, x: null, y: null, zoom: 1, alpha: 1 }, // 显示屏弹出态（BO 2026-10-15）：单独浮在页面上，可拖，有自己的缩放与透明度
    fold: "full", // 面板高度（BO 2026-10-14 底部红线设计）："full" 展开到内容高 | "fold" 折到页签栏 | 数字 = 手动拖出的高度（未缩放 px）
    uiZoom: 1, // 整个面板 + 圆钮的 CSS zoom（UI_ZOOMS；BO 2026-10-09：4K 屏合适的尺寸在 1080p 上太大）
    source: null, // 音源偏好（element / tab），空 = 自动
    module: null,
    local: null,
    neo: null,
    settings: null,
    controls: null,
    unmounted: false,
    reconnects: 0,
  };
  const api = { state, root, $, hostEl };

  // ---- UI 侧 wasm 实例：参数元数据 / 默认值、模块 11、灯板、频点表
  state.module = await NeoAudio.loadModule(env.wasmUrl);
  state.local = await NeoAudio.localEngine(state.module, 48_000);
  state.local.analyzerInit(48_000, 2048, 256);
  state.local.displayCheckDims();
  state.displayParams = { [FIELD.DP_GAMMA]: NONLINEAR_GAMMA, [FIELD.DP_AFTERGLOW_MS]: state.afterglowMs };
  const applyDisplayParams = (target) => {
    for (const [f, v] of Object.entries(state.displayParams)) target.setParam(MODULE.DISPLAY, 0, parseInt(f, 10), v);
  };
  applyDisplayParams(state.local);
  const sendDisplayParam = (field, value) => {
    state.displayParams[field] = value;
    state.local.setParam(MODULE.DISPLAY, 0, field, value); // 客户端的 ui 就是 state.local
  };
  const displayParam = (field) => {
    const v = state.local.getParam(MODULE.DISPLAY, 0, field);
    return Number.isNaN(v) ? state.displayParams[field] : v;
  };

  const engineReady = () => !!(state.neo && state.neo.started);
  const paramInfo = (module, field) => state.local.paramInfo(module, field);
  const getP = (module, index, field) => {
    if (engineReady()) return state.neo.getParam(module, index, field);
    const v = state.local.getParam(module, index, field);
    return Number.isNaN(v) ? Promise.reject(new Error(`本地读回失败 ${module}/${index}/${field}`)) : Promise.resolve(v);
  };
  const getEnabled = (module) => (engineReady() ? state.neo.getModuleEnabled(module) : Promise.resolve(state.local.moduleEnabled(module) > 0));
  const send = (module, index, field, value) => {
    if (state.neo) state.neo.setParam(module, index, field, value);
  };
  const sendEnable = (module, on) => {
    if (state.neo) state.neo.setModuleEnabled(module, on);
  };

  // ---- 控件与面板
  const C = createControls({ paramInfo, getP, getEnabled, send, sendEnable, bypass: () => state.bypass, $, log, changed: () => state.settings && state.settings.touch() });
  state.controls = C.controls;
  const panels = createPanels({ C, $, paramInfo, getP, send, hasEngine: () => !!state.neo, log, touch: () => state.settings && state.settings.touch(), eqBands: 10, localGet: (m, i, f) => state.local.getParam(m, i, f), localIndexCount: (m) => state.local.indexCount(m), sampleRate: () => (state.neo ? state.neo.sampleRate : 0), hqOp, sysInfo: env.sysInfo, sysAvail: env.sysAvail, hqCpu: env.hqCpu });
  panels.buildAll();
  // 虚拟舞台顶视图（BO 2026-10-15）：拖圆点摆元素；与虚拟环绕互斥，开一个自动关另一个（引擎里也强制）
  if ($("stage-view") && panels.stageElements) {
    const sv = createStageView({ canvas: $("stage-view"), elements: () => panels.stageElements, touch: () => state.settings && state.settings.touch() });
    panels.onStageChange = () => sv.redraw();
    panels.onStageReset = () => sv.demo(false); // 开 / 关舞台：停掉演示旋转（摆位复位在 panels.js 里）
    state.stageView = sv;
  }
  const exclusive = (a, b) => {
    const ea = $(a);
    const eb = $(b);
    if (!ea || !eb) return;
    ea.addEventListener("change", () => {
      if (ea.checked && eb.checked) {
        eb.checked = false;
        eb.dispatchEvent(new Event("change"));
      }
    });
  };
  exclusive("en-stage", "en-surround");
  exclusive("en-surround", "en-stage");
  // 虚拟舞台（方案 B，BO 2026-10-16）：分离 Worker 在插件源的文档里、音频经 Port 来回，引擎留在页面里，不需要切音源；
  // 面板上不再有"音源"选项（状态栏已显示音源），标签页捕获只在页面 CSP 挡住引擎时由 content script 自动兜底
  // 虚拟环绕：模块名 + 小喇叭图标，悬停时在上方弹出 5.1 摆位示意图（原始尺寸），移开即消失（BO 2026-10-08）
  $("sr-pop").src = env.assetUrl("common/ui/img/surround-51.webp");
  // 示意图搬到面板根下，悬停模块名时按模块名的位置摆到它上方（面板坐标 ÷ zoom）；区块滚动时也不会被裁
  {
    const pop = $("sr-pop");
    const hint = $("sr-hint");
    panel.appendChild(pop);
    const place = () => {
      const hr = hint.getBoundingClientRect();
      const pr = panel.getBoundingClientRect();
      const z = state.uiZoom || 1;
      pop.classList.add("show");
      const top = (hr.top - pr.top) / z - pop.offsetHeight - 10;
      pop.style.left = `${Math.max(0, (hr.left - pr.left) / z)}px`;
      pop.style.top = `${Math.max(0, top)}px`;
    };
    hint.addEventListener("mouseenter", place);
    hint.addEventListener("mouseleave", () => pop.classList.remove("show"));
  }
  for (const c of state.controls) if (c.sync) await c.sync();
  const applyAll = () => {
    for (const c of state.controls) c.send();
  };
  let polling = false;
  async function pollReadonly() {
    if (polling || !engineReady()) return;
    polling = true;
    try {
      // 一条读回卡住（引擎 / SW 不回话）不能把整个轮询吊死：单条最多等 3 s，超了记一笔、下一条照跑
      for (const p of panels.readonlyPolls) {
        let timer = 0;
        const late = new Promise((r) => (timer = setTimeout(r, 3000, "late")));
        if ((await Promise.race([p(), late])) === "late") log("只读读回 3 s 没回来，跳过");
        clearTimeout(timer);
      }
    } catch (e) {
      log(`只读读回失败: ${e.message}`);
    } finally {
      polling = false;
    }
  }
  // 页签上的小圆点：模块开着
  const paintTabDots = () => {
    const on = (m) => {
      const c = state.controls.find((x) => x.isModuleSwitch && x.module === m);
      return !!(c && c.input.checked);
    };
    const dots = { eq: on(MODULE.EQ), tone: on(MODULE.TRUEBASS) || on(MODULE.TREBLE), width: on(MODULE.WIDTH), reverb: on(MODULE.REVERB), surround: on(MODULE.SURROUND), stage: on(MODULE.STAGE), output: false };
    for (const b of $("tabs").querySelectorAll("button")) b.classList.toggle("on", !!dots[b.dataset.tab]);
  };
  for (const c of state.controls) if (c.isModuleSwitch) c.input.addEventListener("change", paintTabDots);

  // ---- 显示屏
  const idleLampCache = { abi: null, lamp: null };
  const idleLamp = () => {
    const abi = state.local;
    abi.displayReset();
    if (idleLampCache.abi !== abi) {
      idleLampCache.abi = abi;
      idleLampCache.lamp = {
        bars: () => abi.lampBars(),
        barInfo: () => abi.lampBarInfo(),
        ticks: () => abi.lampTicks(),
        scopeLit: () => abi.lampScopeLit(),
        scopeDim: () => abi.lampScopeDim(),
        scopeInfo: () => abi.lampScopeInfo(),
        curve: (n) => abi.lampCurve(n),
        curveHist: (slot, n) => abi.lampCurveHist(slot, n),
        curveHistBr: () => abi.lampCurveHistBr(),
      };
    }
    return idleLampCache.lamp;
  };
  const idleFrame = () => {
    const abi = state.local;
    const n = abi.curvePoints();
    return {
      meters: new Float32Array(METER_COUNT_IDLE).fill(-100),
      barsDb: new Float32Array(31).fill(-100),
      barActive: new Float32Array(31).fill(1),
      barFreq: Float32Array.from(abi.barFreq()),
      curveDb: new Float32Array(n).fill(-100),
      curveFreq: Float32Array.from(abi.curveFreq()),
      scopeL: new Float32Array(0),
      scopeR: new Float32Array(0),
      frames: 0,
      latency: 0,
      sampleRate: state.neo ? state.neo.sampleRate : 48000,
      idle: true,
    };
  };
  const feedLamp = (d) => {
    if (state.neo && state.neo.lamp && !d.idle) {
      state.neo.feedLamp(d);
      return state.neo.lamp;
    }
    return idleLamp();
  };
  const vfd = createVfd({
    canvas: $("display"),
    spillCanvas: $("spill"),
    bezel: $("bezel"),
    state,
    zoom: () => (state.pop.on ? state.pop.zoom : state.uiZoom),
    // 显示屏后端默认 WebGL（Firefox 实机黑屏在查：docs/phase3-04 追加三）；
    // 调试开关：页面 localStorage 里 neo.gl = "webgl" | "keep" | "2d"（按站点，刷新生效），Chrome 默认 WebGL
    glMode: (() => {
      let v = null;
      try {
        v = localStorage.getItem("neo.gl");
      } catch (_) {
        /* 无存储 */
      }
      if (v === "webgl") return null;
      if (v === "keep") return "keep";
      if (v === "2d") return "0";
      return null; // 两家默认都用 WebGL（Firefox 黑屏排查中，neo.gl="2d" 可按站点退回）
    })(),
    log,
    feedLamp,
    displayParam,
    fftSize: () => (state.neo ? state.neo.opts.fftSize : null),
    onInfo: () => {}, // 视图说明文字不显示（BO 2026-10-08：去掉 i 图标）
    onRestored: () => redraw(),
  });
  api.vfd = vfd;
  vfd.applyTheme(state.theme); // 颜色表由风格派生，画任何东西之前必须先算一次
  applyScreenColor();
  const drawIdle = () => vfd.drawView(idleFrame());
  const redraw = () => {
    if (!state.open && !state.pop.on) return; // 面板关着且没弹出 → 没有可见的显示屏
    if (state.lastDisplay && state.displayOn) vfd.drawView(state.lastDisplay);
    else drawIdle();
  };
  const applyBezel = () => $("bezel").style.setProperty("--bezel", `${state.bezelPx}px`);
  applyBezel();
  {
    const sel = $("ui-theme");
    for (const th of UI_THEMES) {
      const o = document.createElement("option");
      o.value = th.id;
      o.textContent = th.name();
      sel.appendChild(o);
    }
    sel.addEventListener("change", () => setUiTheme(sel.value, true));
    setUiTheme(UI_THEME_DEFAULT, false);
    // 语言下拉：换语言 = 记进设置并整个面板重建（文字都烤在 DOM 里）
    const ls = $("ui-lang");
    for (const l of LANGS) {
      const o = document.createElement("option");
      o.value = l.id;
      o.textContent = l.name;
      ls.appendChild(o);
    }
    ls.value = lang();
    ls.addEventListener("change", async () => {
      setLang(ls.value);
      await state.settings.saveCurrent();
      if (env.remount) env.remount();
    });
    const zs = $("ui-zoom");
    for (const z of UI_ZOOMS) {
      const o = document.createElement("option");
      o.value = String(z);
      o.textContent = `${z}×`;
      zs.appendChild(o);
    }
    zs.addEventListener("change", () => setUiZoom(parseFloat(zs.value), true));
    setUiZoom(1, false);
  }
  /** 整体缩放：CSS zoom 作用在面板和圆钮上（布局随之缩放，拖动 / 改宽都按未缩放的坐标记）；显示屏像素缓冲按 dpr × zoom 保持清晰。 */
  function setUiZoom(z, user) {
    if (!UI_ZOOMS.includes(z)) z = 1;
    state.uiZoom = z;
    $("panel").style.zoom = z === 1 ? "" : String(z); // 圆钮不缩放（BO 2026-10-09）
    // CSS zoom 会把元素自己的 left/top/max-width 等长度也乘上 zoom：视口上限按 zoom 折算（摆放时的坐标同理，见 placePanel / placeFab）
    $("panel").style.maxWidth = z === 1 ? "" : `calc((100vw - 16px) / ${z})`;
    $("panel").style.maxHeight = z === 1 ? "" : `calc((100vh - 80px) / ${z})`;
    $("ui-zoom").value = String(z);
    fitWidth();
    if (user) {
      placePanel();
      redraw();
      state.settings.touch();
    }
  }
  function setUiTheme(id, user) {
    if (!UI_THEMES.some((t) => t.id === id)) id = UI_THEME_DEFAULT;
    state.uiTheme = id;
    $("root").dataset.ui = id;
    $("ui-theme").value = id;
    if (user) state.settings.touch();
  }
  function hqOp(op) {
    if (state.neo) state.neo.hqOp(op);
  }
  /** 页内媒体 + 舞台开着（Chrome）→ 显示"需要标签页捕获，重新加载页面"的提示行。 */
  /** 音源切换：先停旧宿主再起新的（content script 做），然后面板重连；失败时 env 会退回页内媒体并给出原因。 */
  async function switchSource(mode, user) {
    const cur = env.getSource ? env.getSource() : null;
    if (mode === cur) return;
    setStatus(t("source.switching"));
    const r = await env.setSource(mode);
    state.source = r && r.mode ? r.mode : cur;
    reconnect();
    if (user) state.settings.touch();
  }
  function paintWarn(list) {
    const w = $("warn");
    const err = env.getSourceError ? env.getSourceError() : null;
    if (err) warnOnce = typeof err === "string" ? err : `${t(err.key)}${err.detail ? "：" + err.detail : ""}`;
    const all = [...(list || [])];
    if (warnOnce) all.unshift(warnOnce);
    w.textContent = all.join("　|　");
    w.hidden = all.length === 0;
  }
  let warnOnce = null;
  {
    const sel = $("vfd-theme");
    for (const [id, th] of Object.entries(vfd.VFD_THEMES)) {
      const o = document.createElement("option");
      o.value = id;
      o.textContent = t(`vfd.${id}`) === `vfd.${id}` ? th.name : t(`vfd.${id}`);
      sel.appendChild(o);
    }
    sel.addEventListener("change", () => setTheme(sel.value, true));
    $("vfd-glow").addEventListener("input", (e) => {
      state.glowAmount = parseFloat(e.target.value);
      redraw();
      state.settings.touch();
    });
    $("vfd-afterglow").addEventListener("input", (e) => {
      state.afterglowMs = parseInt(e.target.value, 10);
      sendDisplayParam(FIELD.DP_AFTERGLOW_MS, state.afterglowMs);
      state.settings.touch();
    });
    $("vfd-spill").addEventListener("input", (e) => {
      state.spillAmount = parseFloat(e.target.value);
      redraw();
      state.settings.touch();
    });
    $("vfd-bezel").addEventListener("input", (e) => {
      state.bezelPx = parseInt(e.target.value, 10);
      applyBezel();
      redraw();
      state.settings.touch();
    });
    for (const m of ["scope", "bars", "curve"]) $(`mode-${m}`).addEventListener("click", () => setMode(m, true));
    for (const k of ["linear", "nonlinear"]) $(`scale-${k}`).addEventListener("click", () => setBarScale(k, true));
  }
  /** 显示屏磷光色 → CSS 变量（标题辉光等跟着显示屏风格走） */
  function applyScreenColor() {
    $("root").style.setProperty("--screen-rgb", vfd.VFD.rgb.tint.join(", "));
  }
  function setTheme(id, user) {
    vfd.applyTheme(id);
    applyScreenColor();
    $("vfd-theme").value = state.theme;
    redraw();
    if (user) state.settings.touch();
  }
  function setMode(m, user) {
    state.viewMode = m;
    for (const k of ["scope", "bars", "curve"]) $(`mode-${k}`).classList.toggle("active", k === m);
    redraw();
    if (user) state.settings.touch();
  }
  function setBarScale(mode, user) {
    state.barScale = mode === "linear" ? "linear" : "nonlinear";
    for (const k of ["linear", "nonlinear"]) $(`scale-${k}`).classList.toggle("active", k === state.barScale);
    sendDisplayParam(FIELD.DP_GAMMA, state.barScale === "linear" ? 1 : NONLINEAR_GAMMA);
    redraw();
    if (user) state.settings.touch();
  }
  function paintDisplayControls() {
    $("vfd-theme").value = state.theme;
    $("vfd-glow").value = state.glowAmount;
    $("vfd-afterglow").value = state.afterglowMs;
    $("vfd-spill").value = state.spillAmount;
    $("vfd-bezel").value = state.bezelPx;
    $("ui-theme").value = state.uiTheme;
    $("ui-zoom").value = String(state.uiZoom);
    $("display-on").checked = state.displayOn;
    $("volume").value = state.volume;
    $("bypass").checked = state.bypass;
    for (const k of ["scope", "bars", "curve"]) $(`mode-${k}`).classList.toggle("active", k === state.viewMode);
    for (const k of ["linear", "nonlinear"]) $(`scale-${k}`).classList.toggle("active", k === state.barScale);
  }
  /** 显示屏实际开关 = 面板开着且显示屏打开；宿主没人要帧时 worklet 停发。 */
  function applyDisplay() {
    const on = ((state.open || state.pop.on) && state.displayOn) || state.hover;
    if (state.neo) state.neo.setDisplay(on);
    $("bezel").hidden = !state.displayOn;
    $("screen-tools2").hidden = !state.displayOn;
    if (!on) state.lastDisplay = null;
    redraw();
  }
  $("display-on").addEventListener("change", (e) => {
    state.displayOn = e.target.checked;
    applyDisplay();
    state.settings.touch();
  });
  $("volume").addEventListener("input", (e) => {
    state.volume = parseFloat(e.target.value);
    if (state.neo) state.neo.setVolume(state.volume);
    state.settings.touch();
  });
  $("bypass").addEventListener("change", (e) => {
    state.bypass = e.target.checked;
    applyAll();
  });

  // ---- 页签
  function setTab(name, user) {
    state.tab = name;
    for (const b of $("tabs").querySelectorAll("button")) b.classList.toggle("active", b.dataset.tab === name);
    for (const s of root.querySelectorAll("section.panel-sec")) s.hidden = s.dataset.tab !== name;
    fitWidth();
    applyFold();
    if (user) state.settings.touch();
  }
  /** 面板宽度 = 最宽页签所需（开着时才量得到） */
  function fitWidth() {
    if (!state.open || panel.hidden) return;
    fitPanelWidth(panel, state.uiZoom);
    placePanel();
  }
  $("tabs").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-tab]");
    if (b) setTab(b.dataset.tab, true);
  });
  for (const btn of root.querySelectorAll(".btn-default")) {
    btn.addEventListener("click", () => {
      const mods = RESET_MODULES[btn.dataset.reset] || [];
      for (const c of state.controls) {
        if (c.isModuleSwitch || !mods.includes(c.module) || !c.reset) continue;
        c.reset();
      }
      state.settings.touch();
    });
  }

  // ---- 设置与命名配置
  state.settings = new Settings({
    store,
    controls: () => state.controls,
    alwaysOff: [MODULE.STAGE], // 每次激活插件舞台默认关（BO 2026-10-16）：不恢复上次的开关状态，用的时候手动开
    extras: {
      get: () => ({ theme: state.theme, glow: state.glowAmount, afterglowMs: state.afterglowMs, spill: state.spillAmount, bezel: state.bezelPx, view: state.viewMode, scale: state.barScale, displayOn: state.displayOn, volume: state.volume, tab: state.tab, fab: state.fab, panelPos: state.panelPos, uiTheme: state.uiTheme, zoom: state.uiZoom, fold: state.fold, pop: state.pop, lang: lang() }),
      set: (o) => {
        if (o.theme && vfd.VFD_THEMES[o.theme]) setTheme(o.theme, false);
        if (Number.isFinite(o.glow)) state.glowAmount = Math.max(0, Math.min(2, o.glow));
        if (Number.isFinite(o.afterglowMs)) {
          state.afterglowMs = Math.max(0, Math.min(300, Math.round(o.afterglowMs)));
          sendDisplayParam(FIELD.DP_AFTERGLOW_MS, state.afterglowMs);
        }
        if (o.view && ["scope", "bars", "curve"].includes(o.view)) setMode(o.view, false);
        if (o.scale) setBarScale(o.scale, false);
        if (typeof o.displayOn === "boolean") state.displayOn = o.displayOn;
        if (Number.isFinite(o.volume)) {
          state.volume = Math.max(0, Math.min(1, o.volume));
          if (state.neo) state.neo.setVolume(state.volume);
        }
        if (o.tab && RESET_MODULES[o.tab]) setTab(o.tab, false);
        if (Number.isFinite(o.spill)) state.spillAmount = Math.max(0, Math.min(2, o.spill));
        if (Number.isFinite(o.bezel)) {
          state.bezelPx = Math.max(0, Math.min(40, Math.round(o.bezel)));
          applyBezel();
        }
        if (o.fab && Number.isFinite(o.fab.x) && Number.isFinite(o.fab.y)) {
          state.fab = { x: o.fab.x, y: o.fab.y };
          placeFab();
        }
        if (o.panelPos && Number.isFinite(o.panelPos.x) && Number.isFinite(o.panelPos.y)) {
          state.panelPos = { x: o.panelPos.x, y: o.panelPos.y };
          placePanel();
        }
        if (typeof o.uiTheme === "string") setUiTheme(o.uiTheme, false);
        if (Number.isFinite(o.zoom)) {
          setUiZoom(o.zoom, false);
          placePanel();
        }
        if (o.fold === "full" || o.fold === "fold" || (Number.isFinite(o.fold) && o.fold > 0)) setFold(o.fold, false);
        if (o.pop && typeof o.pop === "object") {
          if (POP_ZOOMS.includes(o.pop.zoom)) state.pop.zoom = o.pop.zoom;
          if (POP_ALPHAS.includes(o.pop.alpha)) state.pop.alpha = o.pop.alpha;
          if (Number.isFinite(o.pop.x) && Number.isFinite(o.pop.y)) {
            state.pop.x = o.pop.x;
            state.pop.y = o.pop.y;
          }
          applyPop();
          setPopup(!!o.pop.on, false);
        }
        paintDisplayControls();
        applyDisplay();
      },
    },
    log,
    onProfiles: (names, current) => paintProfileSelect(names, current),
  });
  // 配置菜单（BO 2026-10-14）：「配置名 ▾」按钮，菜单上半是配置列表（点选切换），下半是 保存 / 另存为… / 删除 / 导出 / 导入
  const menuBtn = $("profile-btn");
  const menu = $("profile-menu");
  const profileName = $("profile-name");
  function menuOpen(on) {
    menu.hidden = !on;
    menuBtn.setAttribute("aria-expanded", on ? "true" : "false");
    if (!on) profileName.hidden = true;
  }
  menuBtn.addEventListener("click", () => menuOpen(menu.hidden));
  document.addEventListener("pointerdown", (e) => {
    if (!menu.hidden && !e.composedPath().includes($("pmenu"))) menuOpen(false);
  });
  root.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !menu.hidden) menuOpen(false);
  });
  function paintProfileSelect(names, current) {
    const cur = names.includes(current) ? current : "";
    const items = $("profile-items");
    items.innerHTML = "";
    for (const n of names) {
      const b = document.createElement("button");
      b.className = "pitem" + (n === cur ? " current" : "");
      b.dataset.profile = n;
      b.textContent = n;
      items.appendChild(b);
    }
    items.hidden = names.length === 0;
    items.nextElementSibling.hidden = names.length === 0; // 列表为空时不画分隔线
    $("profile-cur").textContent = cur || t("profile.unnamed");
    $("profile-delete").disabled = !cur;
    $("profile-save").disabled = !cur;
  }
  $("profile-items").addEventListener("click", async (e) => {
    const b = e.target.closest("button[data-profile]");
    if (!b) return;
    menuOpen(false);
    try {
      await state.settings.load(b.dataset.profile);
    } catch (err) {
      log(`切换配置失败: ${err.message}`);
    }
  });
  $("profile-save").addEventListener("click", async () => {
    menuOpen(false);
    const name = state.settings.currentName;
    if (name) await state.settings.save(name);
  });
  $("profile-saveas").addEventListener("click", () => {
    profileName.hidden = false;
    profileName.value = "";
    profileName.focus();
  });
  profileName.addEventListener("keydown", async (e) => {
    e.stopPropagation(); // 页面的快捷键别抢
    if (e.key === "Escape") {
      profileName.hidden = true;
      return;
    }
    if (e.key !== "Enter") return;
    e.preventDefault();
    const name = profileName.value.trim();
    if (!name) return;
    menuOpen(false);
    try {
      await state.settings.save(name);
    } catch (err) {
      log(`保存配置失败: ${err.message}`);
    }
  });
  $("profile-delete").addEventListener("click", async () => {
    menuOpen(false);
    const name = state.settings.currentName;
    if (name) await state.settings.remove(name);
  });
  $("profile-export").addEventListener("click", async () => {
    menuOpen(false);
    const name = state.settings.currentName;
    const text = await state.settings.exportText(name);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "application/json" }));
    a.download = Settings.fileName(name || state.settings.currentName || "current");
    root.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  $("profile-import").addEventListener("click", () => {
    menuOpen(false);
    $("profile-file").click();
  });
  $("profile-file").addEventListener("change", async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!f) return;
    try {
      const name = await state.settings.importText(await f.text());
      await state.settings.load(name);
    } catch (err) {
      log(`导入配置失败: ${err.message}`);
    }
  });
  await state.settings.loadCurrent();
  paintProfileSelect(await state.settings.list(), state.settings.currentName);
  paintDisplayControls();
  paintTabDots();
  setTab(state.tab, false);

  // ---- 引擎客户端（断开后重连几次；宿主没建好时先等 ready）
  const setStatus = (t, title = "") => {
    $("status").textContent = t;
    $("status").title = title;
  };
  function connectEngine() {
    if (state.unmounted) return;
    let port;
    try {
      port = env.connect(() => {
        if (state.neo) state.neo.destroy();
        state.neo = null;
        $("fab").classList.remove("live");
        setStatus(t("status.disconnected"));
        if (!state.unmounted && state.reconnects++ < 5) setTimeout(connectEngine, 1000);
      });
    } catch (e) {
      log(`连接宿主失败: ${e.message}`);
      return;
    }
    let ep;
    if (port && port.kind === "local") {
      // 页内宿主：同页通道，零拷贝
      const ch = createLocalChannel();
      port.attach(ch.host);
      ep = ch.ui;
    } else {
      ep = port && port.onMessage && port.onMessage.addListener ? wrapJsonPort(port) : port;
    }
    const neo = new EngineClient(ep, { lampAbi: state.local, sampleRate: 48_000, fftSize: 4096, curvePoints: 256 });
    const srcLabel = (s) => (s === "element" ? t("source.element") : s === "tab" ? t("source.tab") : s === "none" ? t("source.none") : s);
    state.neo = neo;
    neo.onReady = (m) => {
      state.reconnects = 0;
      applyAll();
      neo.setVolume(state.volume);
      applyDisplay();
      $("fab").classList.add("live");
      setStatus(`${t("status.ready")} · ${m.sampleRate} Hz · ${srcLabel(m.source)}`);
      paintWarn([]);
      pollReadonly();
    };
    neo.onState = (s) => {
      if (!s.started) setStatus(t("status.waiting"), (s.warnings || []).join("\n"));
      else setStatus(`${s.idle ? t("status.idle") : t("status.ready")} · ${neo.sampleRate} Hz · ${srcLabel(s.source)}${s.warnings && s.warnings.length ? " · ⚠" : ""}`, (s.warnings || []).join("\n"));
      paintWarn(s.warnings);
    };
    neo.onIdle = (on) => setStatus(`${on ? t("status.idle") : t("status.ready")} · ${neo.sampleRate} Hz · ${srcLabel(neo.source)}`);
    neo.onError = (e) => log(`引擎错误: ${e.message}`);
    neo.onHq = (m) => panels.onHq && panels.onHq(m); // 虚拟舞台的模型下载 / 分离 Worker 状态
    neo.onDisplay = (d) => {
      if (d.meters[METER.CLIP_L] > 0.5 || d.meters[METER.CLIP_R] > 0.5) neo.clearClip();
      state.lastDisplay = d;
      if (state.hover) pulse(d);
      if ((state.open || state.pop.on) && state.displayOn) {
        try {
          vfd.drawView(d);
        } catch (err) {
          log(`绘制失败: ${err.message}`);
        }
      }
    };
  }
  connectEngine();
  /** 音源切换 / 宿主重建后：丢掉旧客户端，重新连。 */
  function reconnect() {
    if (state.neo) {
      try {
        state.neo.destroy();
      } catch (_) {
        /* 已销毁 */
      }
    }
    state.neo = null;
    state.reconnects = 0;
    connectEngine();
  }

  // ---- 按钮：点开 / 收起；拖动；全屏时隐藏
  let pollTimer = 0;
  function open() {
    if (state.pop.on) setPopup(false, true); // 面板一开，显示屏回到面板里
    state.open = true;
    $("root").dataset.open = "true";
    panel.hidden = false;
    fitWidth();
    applyFold();
    placeFab();
    placePanel();
    applyDisplay();
    clearInterval(pollTimer);
    pollTimer = setInterval(pollReadonly, 500);
    pollReadonly();
  }
  function close() {
    state.open = false;
    $("root").dataset.open = "false";
    panel.hidden = true;
    clearInterval(pollTimer);
    pollTimer = 0;
    applyDisplay();
  }
  const toggle = () => (state.open ? close() : open());
  $("collapse").addEventListener("click", close);
  $("power").addEventListener("click", () => {
    close();
    if (env.onStop) env.onStop();
  });
  function placeFab() {
    if (!state.fab) {
      fab.style.left = "";
      fab.style.bottom = "";
    } else {
      const x = Math.max(24, Math.min(window.innerWidth - 24, state.fab.x * window.innerWidth));
      const y = Math.max(8, Math.min(window.innerHeight - 46, state.fab.y));
      fab.style.left = `${x}px`;
      fab.style.bottom = `${y}px`;
    }
    placePanel();
  }
  /** 面板位置：拖过就用记住的左上角（夹在视口内），否则锚在圆钮上方。 */
  /** 面板高度的两个参考值（未缩放 px）：折到页签栏底、展开到内容底（都含底部横条） */
  function foldHeights() {
    const bar = $("hbar").offsetHeight || 14;
    const tabs = $("tabs");
    const pcs = getComputedStyle(panel);
    const padB = parseFloat(pcs.paddingBottom) || 0;
    const fold = Math.ceil(tabs.offsetTop + tabs.offsetHeight + bar + 2);
    const prev = panel.style.height;
    panel.style.height = "";
    const full = Math.ceil(panel.offsetHeight); // 展开 = 内容高（max-height 仍可能截）
    panel.style.height = prev;
    return { fold, full: Math.max(full, fold), padB };
  }
  /** 按 state.fold 把高度写进面板；拖过的数值夹在折叠高与展开高之间 */
  function applyFold() {
    if (!state.open || panel.hidden) return;
    const h = foldHeights();
    let mode = state.fold;
    if (mode === "full") panel.style.height = "";
    else if (mode === "fold") panel.style.height = `${h.fold}px`;
    else {
      const v = Math.max(h.fold, Math.min(h.full, Math.round(mode)));
      if (v >= h.full) mode = "full";
      else if (v <= h.fold) mode = "fold";
      panel.style.height = mode === "full" ? "" : `${v}px`;
    }
    panel.dataset.fold = mode === "full" ? "full" : mode === "fold" ? "fold" : "manual";
  }
  function setFold(mode, user) {
    state.fold = mode;
    applyFold();
    placePanel();
    if (user) state.settings.touch();
  }
  // ---- 显示屏交互（BO 2026-10-15）：单击切 波形 / 频程 / 曲线；双击 弹出 / 收回；弹出态可拖；右键菜单设弹出缩放与透明度
  function applyPop() {
    popBox.style.zoom = state.pop.zoom === 1 ? "" : String(state.pop.zoom);
    popBox.style.opacity = state.pop.alpha === 1 ? "" : String(state.pop.alpha);
    for (const b of dmenu.querySelectorAll("button[data-zoom]")) b.classList.toggle("current", parseFloat(b.dataset.zoom) === state.pop.zoom);
    for (const b of dmenu.querySelectorAll("button[data-alpha]")) b.classList.toggle("current", parseFloat(b.dataset.alpha) === state.pop.alpha);
    placePop();
  }
  /** 弹出容器位置：记住的左上角（屏幕 px，夹在视口内），没有就居中靠下；CSS zoom 会再乘一次，所以写 ÷ zoom */
  function placePop() {
    if (!state.pop.on || popBox.hidden) return;
    const z = state.pop.zoom;
    const r = popBox.getBoundingClientRect();
    const w = r.width || 580 * z;
    const h = r.height || 170 * z;
    let x = state.pop.x;
    let y = state.pop.y;
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      x = Math.round((window.innerWidth - w) / 2);
      y = Math.round(window.innerHeight - h - 80);
    }
    x = Math.max(0, Math.min(window.innerWidth - Math.min(w, window.innerWidth), x));
    y = Math.max(0, Math.min(window.innerHeight - Math.min(h, window.innerHeight), y));
    popBox.style.left = `${x / z}px`;
    popBox.style.top = `${y / z}px`;
  }
  function setPopup(on, user) {
    if (state.pop.on === on) return;
    state.pop.on = on;
    $("root").dataset.popup = on ? "true" : "false";
    if (on) {
      popBox.appendChild(bezel); // 从面板里搬出来；弹出态下面板隐藏
      popBox.hidden = false;
      if (state.open) close();
      applyPop();
    } else {
      screenBox.insertBefore(bezel, screenBox.firstChild);
      popBox.hidden = true;
    }
    applyDisplay();
    redraw();
    if (user) state.settings.touch();
  }
  {
    // 单击 / 双击 / 拖动都从 pointer 事件自己判：按下不动抬起 = 点击，350 ms 内两次 = 双击；移动 ≥ 4 px = 拖（仅弹出态）
    let press = null;
    let clickTimer = 0;
    let lastUp = 0;
    bezel.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const r = popBox.getBoundingClientRect();
      press = { x0: e.clientX, y0: e.clientY, left: r.left, top: r.top, moved: false };
      try {
        bezel.setPointerCapture(e.pointerId);
      } catch (_) {
        /* 合成事件 */
      }
      e.preventDefault();
      e.stopPropagation(); // 不触发面板的空白处拖动
    });
    bezel.addEventListener("pointermove", (e) => {
      if (!press) return;
      const dx = e.clientX - press.x0;
      const dy = e.clientY - press.y0;
      if (!press.moved && Math.hypot(dx, dy) < 4) return;
      press.moved = true;
      if (state.pop.on) {
        state.pop.x = press.left + dx;
        state.pop.y = press.top + dy;
        placePop();
      }
    });
    const end = (e) => {
      if (!press) return;
      const p = press;
      press = null;
      try {
        bezel.releasePointerCapture(e.pointerId);
      } catch (_) {
        /* 已释放 */
      }
      if (p.moved) {
        if (state.pop.on) state.settings.touch();
        return;
      }
      const now = performance.now();
      if (now - lastUp < 350) {
        lastUp = 0;
        clearTimeout(clickTimer);
        clickTimer = 0;
        setPopup(!state.pop.on, true); // 双击：弹出 ⇄ 收回
        if (!state.pop.on && !state.open) open();
        return;
      }
      lastUp = now;
      clickTimer = setTimeout(() => {
        clickTimer = 0;
        const i = VIEW_CYCLE.indexOf(state.viewMode);
        setMode(VIEW_CYCLE[(i + 1) % VIEW_CYCLE.length], true); // 单击：切视图
      }, 350);
    };
    bezel.addEventListener("pointerup", end);
    bezel.addEventListener("pointercancel", () => {
      press = null;
    });
    // 右键菜单：弹出缩放 / 透明度（在面板里也能设，效果在弹出态显现）
    for (const z of POP_ZOOMS) {
      const b = document.createElement("button");
      b.dataset.zoom = String(z);
      b.textContent = `${z}×`;
      b.addEventListener("click", () => {
        state.pop.zoom = z;
        applyPop();
        redraw();
        dmenu.hidden = true;
        state.settings.touch();
      });
      $("dmenu-zoom").appendChild(b);
    }
    for (const a of POP_ALPHAS) {
      const b = document.createElement("button");
      b.dataset.alpha = String(a);
      b.textContent = `${Math.round(a * 100)}%`;
      b.addEventListener("click", () => {
        state.pop.alpha = a;
        applyPop();
        dmenu.hidden = true;
        state.settings.touch();
      });
      $("dmenu-alpha").appendChild(b);
    }
    bezel.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      e.stopPropagation();
      dmenu.hidden = false;
      const r = dmenu.getBoundingClientRect();
      dmenu.style.left = `${Math.max(0, Math.min(window.innerWidth - r.width - 4, e.clientX))}px`;
      dmenu.style.top = `${Math.max(0, Math.min(window.innerHeight - r.height - 4, e.clientY))}px`;
    });
    document.addEventListener("pointerdown", (e) => {
      if (!dmenu.hidden && !e.composedPath().includes(dmenu)) dmenu.hidden = true;
    });
    root.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !dmenu.hidden) dmenu.hidden = true;
    });
    applyPop();
  }

  // 底部横条（BO 2026-10-14）：悬停点亮；点击在 展开 / 折叠 间切换；按住拖动手动改高度
  {
    const bar = $("hbar");
    let drag = null;
    bar.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      drag = { y0: e.clientY, h0: panel.offsetHeight, moved: false };
      try {
        bar.setPointerCapture(e.pointerId);
      } catch (_) {
        /* 合成事件 */
      }
      e.preventDefault();
      e.stopPropagation();
    });
    bar.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dy = (e.clientY - drag.y0) / state.uiZoom;
      if (!drag.moved && Math.abs(dy) < 3) return;
      drag.moved = true;
      panel.classList.add("hdragging");
      const h = foldHeights();
      const v = Math.max(h.fold, Math.min(h.full, Math.round(drag.h0 + dy)));
      panel.style.height = `${v}px`;
      panel.dataset.fold = v >= h.full ? "full" : v <= h.fold ? "fold" : "manual";
      placePanel();
    });
    const end = (e) => {
      if (!drag) return;
      const moved = drag.moved;
      drag = null;
      panel.classList.remove("hdragging");
      try {
        bar.releasePointerCapture(e.pointerId);
      } catch (_) {
        /* 已释放 */
      }
      if (moved) {
        const h = foldHeights();
        const v = panel.offsetHeight;
        setFold(v >= h.full ? "full" : v <= h.fold ? "fold" : v, true);
      } else {
        setFold(panel.dataset.fold === "full" ? "fold" : "full", true); // 点击：展开 ⇄ 折叠
      }
    };
    bar.addEventListener("pointerup", end);
    bar.addEventListener("pointercancel", end);
  }
  function placePanel() {
    placePanelBox();
    fitSectionHeight(panel, state.uiZoom);
  }
  function placePanelBox() {
    const pr = panel.hidden ? null : panel.getBoundingClientRect(); // zoom 后 offsetWidth 是未缩放的，屏幕尺寸要看 rect
    const w = (pr && pr.width) || Math.min(620 * state.uiZoom, window.innerWidth - 16);
    const h = (pr && pr.height) || 400 * state.uiZoom;
    if (state.panelPos) {
      const x = Math.max(0, Math.min(window.innerWidth - Math.min(w, window.innerWidth), state.panelPos.x));
      const y = Math.max(0, Math.min(window.innerHeight - Math.min(h, window.innerHeight), state.panelPos.y));
      panel.style.transform = "none";
      panel.style.left = `${x / state.uiZoom}px`; // 屏幕坐标 ÷ zoom
      panel.style.top = `${y / state.uiZoom}px`;
      panel.style.bottom = "auto";
      panel.style.maxHeight = `${Math.max(240, window.innerHeight - y - 8) / state.uiZoom}px`; // 拖过的面板：顶边到窗口底部
      return;
    }
    panel.style.top = "auto";
    if (!state.fab) {
      panel.style.transform = "";
      panel.style.left = "";
      panel.style.bottom = "";
      panel.style.maxHeight = "";
      return;
    }
    const x = Math.max(24, Math.min(window.innerWidth - 24, state.fab.x * window.innerWidth));
    const y = Math.max(8, Math.min(window.innerHeight - 46, state.fab.y));
    const left = Math.max(8 + w / 2, Math.min(window.innerWidth - 8 - w / 2, x));
    panel.style.transform = "";
    panel.style.left = `${left / state.uiZoom}px`; // 屏幕坐标 ÷ zoom
    panel.style.bottom = `${(y + 46) / state.uiZoom}px`; // 圆钮上方 46 px（屏幕坐标 ÷ zoom）
    // 圆钮上方放不下整个面板（矮窗口）：最大高度 = 圆钮上方到窗口顶部的空间，面板自己上下滚动（换页签高度变了也不用重算）
    panel.style.maxHeight = `${Math.max(240, window.innerHeight - (y + 46) - 8) / state.uiZoom}px`;
  }
  // 圆钮随音乐跳动（BO 2026-10-08）：鼠标悬停时取显示帧，按块峰值把圆钮放大 0…25%，快起慢落；移开即复原
  let pulseLevel = 0;
  function pulse(d) {
    const meters = d.meters;
    const db = Math.max(meters[METER.BLOCK_PEAK_L], meters[METER.BLOCK_PEAK_R]); // dBFS，−100…0
    const peak = Math.max(0, Math.min(1, (db + 36) / 36)); // −36 dBFS 以下不动，0 dBFS 最大
    // 节奏来自低频（BO 2026-10-08）：1/3 倍频程里 60 Hz 附近（45…90 Hz，即 50 / 63 / 80 Hz 三根柱）最高的一根，
    // 频程柱的 dB 比峰值低一截，按 −45…−5 dBFS 映射到 0…1
    let bassDb = -100;
    if (d.barsDb && d.barFreq) {
      for (let i = 0; i < d.barFreq.length; i++) {
        const f = d.barFreq[i];
        if (f >= 45 && f <= 90 && d.barActive[i] > 0.5 && d.barsDb[i] > bassDb) bassDb = d.barsDb[i];
      }
    }
    const bass = Math.max(0, Math.min(1, (bassDb + 45) / 40));
    const target = 0.35 * peak + 0.65 * bass;
    pulseLevel = target > pulseLevel ? pulseLevel + (target - pulseLevel) * 0.6 : pulseLevel * 0.82;
    const s = 1 + 1 * pulseLevel * pulseLevel;
    fab.style.setProperty("--pulse", s.toFixed(3));
    fab.style.setProperty("--pulse-glow", pulseLevel.toFixed(3));
  }
  function pulseReset() {
    pulseLevel = 0;
    fab.style.setProperty("--pulse", "1");
    fab.style.setProperty("--pulse-glow", "0");
  }
  fab.addEventListener("pointerenter", () => {
    state.hover = true;
    fab.classList.add("hover");
    applyDisplay();
  });
  fab.addEventListener("pointerleave", () => {
    state.hover = false;
    fab.classList.remove("hover");
    pulseReset();
    applyDisplay();
  });

  // 面板本身可拖：按住任何没有控件的空白处（标题 / 状态 / 说明文字也行）；控件、推子、显示屏、右下角改宽把手、滚动条不算（BO 2026-10-09）
  {
    let drag = null;
    panel.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      if (e.target.closest("button, input, select, textarea, a, canvas, img, label, .seg, .switch, .fader, .sr-hint, .warn, .pmenu, .hbar")) return;
      const r = panel.getBoundingClientRect();
      const z = state.uiZoom;
      drag = { x0: e.clientX, y0: e.clientY, left: r.left, top: r.top, moved: false };
      try {
        panel.setPointerCapture(e.pointerId);
      } catch (_) {
        /* 同上 */
      }
      e.preventDefault();
    });
    panel.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x0;
      const dy = e.clientY - drag.y0;
      if (!drag.moved && Math.hypot(dx, dy) < 3) return;
      drag.moved = true;
      panel.classList.add("dragging");
      state.panelPos = { x: drag.left + dx, y: drag.top + dy };
      placePanel();
    });
    const end = (e) => {
      if (!drag) return;
      const moved = drag.moved;
      drag = null;
      panel.classList.remove("dragging");
      try {
        panel.releasePointerCapture(e.pointerId);
      } catch (_) {
        /* 已释放 */
      }
      if (moved) state.settings.touch();
    };
    panel.addEventListener("pointerup", end);
    panel.addEventListener("pointercancel", end);
  }
  {
    let drag = null;
    fab.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const r = fab.getBoundingClientRect();
      drag = { x0: e.clientX, y0: e.clientY, cx: r.left + r.width / 2, cy: r.top + r.height / 2, hh: r.height / 2, moved: false };
      try {
        fab.setPointerCapture(e.pointerId);
      } catch (_) {
        /* 合成事件没有活动指针（自动化）：不捕获也能用 */
      }
    });
    fab.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x0;
      const dy = e.clientY - drag.y0;
      if (!drag.moved && Math.hypot(dx, dy) < 4) return;
      drag.moved = true;
      fab.classList.add("dragging");
      // x 记圆心的视口宽度比例（CSS 里 translateX(-50%)），y 记圆钮底边到视口底边的像素
      state.fab = { x: (drag.cx + dx) / window.innerWidth, y: window.innerHeight - (drag.cy + dy) - drag.hh };
      placeFab();
    });
    // 拖过的那一次不算点击：点开 / 收起走标准 click（鼠标、触屏、键盘、合成事件一致）
    let justDragged = false;
    const end = (e) => {
      if (!drag) return;
      const moved = drag.moved;
      drag = null;
      fab.classList.remove("dragging");
      try {
        fab.releasePointerCapture(e.pointerId);
      } catch (_) {
        /* 已释放 */
      }
      justDragged = moved;
      if (moved) state.settings.touch();
    };
    fab.addEventListener("pointerup", end);
    fab.addEventListener("pointercancel", end);
    fab.addEventListener("click", () => {
      if (justDragged) {
        justDragged = false;
        return;
      }
      toggle();
    });
  }
  // 视频全屏时整个 UI 藏起来；全屏期间的 resize 会在一切都不占位（offsetWidth 全 0）时量宽度，量出的是最小值 560，
  // 退出全屏后面板就窄了一截把顶视图遮住（BO 2026-10-16）→ 退出全屏时重新量一次；fitPanelWidth 在没渲染时也不动宽度
  const onFullscreen = () => {
    $("root").hidden = !!document.fullscreenElement;
    if (!document.fullscreenElement) onResize();
  };
  document.addEventListener("fullscreenchange", onFullscreen);
  const onResize = () => {
    placePop();
    fitWidth();
    applyFold();
    placeFab();
    redraw();
  };
  window.addEventListener("resize", onResize);
  onFullscreen();

  function unmount() {
    state.unmounted = true;
    if (state.stageView && state.stageView.destroy) state.stageView.destroy(); // 停掉演示转圈
    close();
    if (state.neo) state.neo.destroy();
    state.neo = null;
    document.removeEventListener("fullscreenchange", onFullscreen);
    window.removeEventListener("resize", onResize);
    hostEl.remove();
  }

  Object.assign(api, { unmount, open, close, toggle, applyAll, pollReadonly, redraw, reconnect, switchSource, settings: state.settings });
  log("面板已挂载");
  return api;
}
