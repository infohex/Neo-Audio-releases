// Neo Audio — 各模块面板的控件布局（阶段 3.2 从测试页 app.js 抽出，测试页与插件面板共用）。
//
// 每个 build* 按参数表元数据往既定 id 的容器里建控件（推子 / 开关 / 分段 / 下拉），并登记只读读数的轮询。
// 容器 id 约定（测试页 index.html 与插件面板模板都按这套）：
//   output-controls | eq, eq-comp, en-eq | truebass, treble, en-truebass, en-treble, ro-tb, ro-tr
//   width, en-width（3D 立体声宽度） | reverb, reverb-preset, en-reverb | surround, sr-mode, sr-xover, sr-timbre, en-surround, ro-sr-lr, ro-sr-cs, ro-sr-delay
//   stage, stage-mod（可省）, st-mode, st-layout, en-stage, st-hint（虚拟舞台；顶视图 canvas 由调用方用 stage-view.js 建，读 P.stageElements）
// deps：C（createControls 的返回）、$(id)、paramInfo、getP、send(m,i,f,v)、hasEngine()、log、touch()（自动保存）、onBalanceChange()、eqBands（默认 10）、
//       localGet(m,i,f) / localIndexCount(m)（本地实例的同步读回：虚拟舞台元素的种类与个数，可省）

import { MODULE, FIELD, REVERB_PRESETS, REVERB_PRESET_CUSTOM, SURROUND_LFE_XOVER_CHOICES, OUTPUT_BALANCE_FIELDS, STAGE_KINDS } from "../../shared/wasm-abi.js";
import { t, ts } from "../i18n.js";

/** 推子标签：短名 + 完整名（悬停）。 */
const L = (key) => ({ label: ts(key), title: t(key) });

export function createPanels(deps) {
  const C = deps.C;
  const { fader, toggle, moduleSwitch, segControl, headSwitch, channelSwitch, fmtHz } = C;
  const $ = deps.$;
  const paramInfo = deps.paramInfo;
  const getP = deps.getP;
  const log = deps.log || (() => {});
  const EQ_BANDS = deps.eqBands || 10;
  const P = { balance: null, readonlyPolls: null, stageElements: null, onStageChange: null, onStageReset: null };

  const readonlyPolls = []; // 每 500 ms 刷新一次的只读读回
    P.readonlyPolls = readonlyPolls;

  function buildOutput() {
    const c = $("output-controls");
    fader(c, { module: MODULE.OUTPUT, field: FIELD.OUT_MANUAL_GAIN, ...L("out.manual") });
    toggle(c, { module: MODULE.OUTPUT, field: FIELD.OUT_AUTO_ENABLED, label: ts("out.auto") });
    fader(c, { module: MODULE.OUTPUT, field: FIELD.OUT_AUTO_AMOUNT, ...L("out.autoAmount") });
    fader(c, { module: MODULE.OUTPUT, field: FIELD.OUT_AUTO_LIMIT, ...L("out.autoLimit") });
    // 前瞻限幅 / 限幅阈值 / 释放时间不再出现在页面上（BO 2026-10-04：影响音质，尤其开了 EQ 与高低音提升之后）；
    // 内核默认关、延迟仍为 2 ms，字段 104–106 仍在参数表里，超过 0 dBFS 由显示屏的削波指示提示
    // 耳机平衡（BO 决策：两耳听力不对称 / 耳机单元误差，由用户把单声道调到正中；记在 localStorage）
    if (paramInfo(MODULE.OUTPUT, FIELD.OUT_TRIM_L)) {
      // 带说明的分组：不熟悉的人也能看出这四个推子是干什么的（BO 要求）
      const box = document.createElement("div");
      box.className = "fgroup2 balance";
      const cap = document.createElement("div");
      cap.className = "gcap";
      cap.innerHTML = `<b>${t("out.balance")}</b>${t("out.balance.tip")}`;
      const row = document.createElement("div");
      row.className = "faders";
      box.append(row, cap); // 推子与其它推子顶对齐，说明文字在下面
      c.appendChild(box);
      const keys = ["out.trimL", "out.trimR", "out.hfL", "out.hfR"];
      P.balance = OUTPUT_BALANCE_FIELDS.map((field, i) => fader(row, { module: MODULE.OUTPUT, field, ...L(keys[i]) }));
      for (const ctl of P.balance) {
        ctl.input.addEventListener("change", () => deps.onBalanceChange && deps.onBalanceChange());
      }
    }
  }

  function buildEq() {
    const c = $("eq");
    const bands = [];
    for (let i = 0; i < EQ_BANDS; i++) {
      const ctl = fader(c, { module: MODULE.EQ, index: i, field: FIELD.EQ_GAIN, label: "…" });
      ctl.row.classList.add("band");
      bands.push({ ctl });
    }
    // 读数只显示推子值；补偿后的滤波器增益（EQ_FILTER_DB）不再附在后面——位置太挤，读数会互相重叠（BO）
    readonlyPolls.push(async () => {
      for (let i = 0; i < EQ_BANDS; i++) {
        const b = bands[i];
        const [freq, inRange] = await Promise.all([
          getP(MODULE.EQ, i, FIELD.EQ_FREQ),
          getP(MODULE.EQ, i, FIELD.EQ_IN_RANGE),
        ]);
        b.ctl.label.textContent = fmtHz(freq);
        b.ctl.row.classList.toggle("off", !inRange);
      }
    });
    const comp = $("eq-comp");
    const compCtl = {
      input: comp,
      module: MODULE.EQ,
      index: 0,
      field: FIELD.EQ_COMPENSATION,
      get value() {
        return comp.checked ? 1 : 0;
      },
      setValue(v, send = true) {
        comp.checked = v > 0.5;
        if (send) compCtl.send();
      },
      async sync() {
        const v = await getP(MODULE.EQ, 0, FIELD.EQ_COMPENSATION);
        if (Number.isFinite(v)) {
          comp.checked = v > 0.5;
          compCtl.initial = comp.checked;
        }
      },
      reset() {
        if (compCtl.initial !== undefined) {
          comp.checked = compCtl.initial;
          compCtl.send();
        }
      },
      send() {
        deps.send(MODULE.EQ, 0, FIELD.EQ_COMPENSATION, comp.checked ? 1 : 0);
      },
    };
    comp.addEventListener("change", () => {
      compCtl.send();
      deps.touch();
    });
    C.controls.push(compCtl);
    moduleSwitch("en-eq", MODULE.EQ);
  }

  /** 混响：预设下拉（面板头）+ 11 个 I3DL2 参数推子。改任何推子 → 引擎回到"自定义"，下拉随之显示。 */
  function buildReverbPanel() {
    const c = $("reverb");
    const sel = $("reverb-preset");
    if (!paramInfo(MODULE.REVERB, FIELD.RB_PRESET)) {
      c.textContent = "当前 wasm 不含混响模块（需要重新构建 wasm）";
      $("en-reverb").disabled = true;
      sel.disabled = true;
      return;
    }
    REVERB_PRESETS.forEach((name, i) => {
      const o = document.createElement("option");
      o.value = String(i);
      o.textContent = name;
      sel.appendChild(o);
    });
    const custom = document.createElement("option");
    custom.value = String(REVERB_PRESET_CUSTOM);
    custom.textContent = t("preset.custom");
    custom.disabled = true;
    sel.appendChild(custom);
    const faders = [
      [FIELD.RB_ROOM, "rb.room"],
      [FIELD.RB_ROOM_HF, "rb.roomHf"],
      [FIELD.RB_DECAY, "rb.decay"],
      [FIELD.RB_DECAY_HF_RATIO, "rb.decayHf"],
      [FIELD.RB_REFLECTIONS, "rb.er"],
      [FIELD.RB_REFLECTIONS_DELAY, "rb.erDelay"],
      [FIELD.RB_REVERB, "rb.late"],
      [FIELD.RB_REVERB_DELAY, "rb.lateDelay"],
      [FIELD.RB_DIFFUSION, "rb.diffusion"],
      [FIELD.RB_DENSITY, "rb.density"],
      [FIELD.RB_HF_REFERENCE, "rb.hfRef"],
    ].map(([field, key]) => fader(c, { module: MODULE.REVERB, field, ...L(key) }));
    const ctl = {
      input: sel,
      module: MODULE.REVERB,
      index: 0,
      field: FIELD.RB_PRESET,
      get value() {
        return parseInt(sel.value, 10);
      },
      setValue(v, send = true) {
        sel.value = String(Math.round(v));
        if (send) ctl.send();
      },
      send() {
        if (!deps.hasEngine()) return;
        const v = ctl.value;
        if (v >= REVERB_PRESET_CUSTOM) return;
        deps.send(MODULE.REVERB, 0, FIELD.RB_PRESET, v);
        // 预设载入后各参数都变了：把推子拉到引擎的新值（消息按序到达，不需要等待）
        for (const f of faders) f.pull();
      },
      async sync() {
        const v = await getP(MODULE.REVERB, 0, FIELD.RB_PRESET);
        if (Number.isFinite(v)) {
          ctl.setValue(v, false);
          ctl.initial = ctl.value;
        }
      },
      reset() {
        if (ctl.initial !== undefined) ctl.setValue(ctl.initial, true);
      },
    };
    sel.addEventListener("change", () => {
      ctl.send();
      deps.touch();
    });
    C.controls.push(ctl);
    readonlyPolls.push(async () => {
      const v = await getP(MODULE.REVERB, 0, FIELD.RB_PRESET);
      if (Number.isFinite(v) && ctl.value !== Math.round(v)) ctl.setValue(v, false);
    });
    moduleSwitch("en-reverb", MODULE.REVERB);
  }

  function buildSurroundPanel() {
    const c = $("surround");
    if (!paramInfo(MODULE.SURROUND, FIELD.SR_MODE)) {
      c.textContent = "当前 wasm 不含虚拟环绕模块（需要重新构建 wasm）";
      $("en-surround").disabled = true;
      return;
    }
    segControl($("sr-mode"), {
      module: MODULE.SURROUND,
      field: FIELD.SR_MODE,
      options: [
        [0, t("render.headphones")],
        [1, t("render.speakers")],
      ],
    });
    segControl($("sr-xover"), {
      module: MODULE.SURROUND,
      field: FIELD.SR_LFE_XOVER,
      options: SURROUND_LFE_XOVER_CHOICES.map((hz) => [hz, `${hz} Hz`]),
    });
    // 六路增益（前方四路 −20…+12 dB，环绕两路 −20…+20 dB），每路推子底部一个 On/Off 开关，Off = 静音（增益值保留；BO 决策）
    const gains = [
      [FIELD.SR_GAIN_FL, FIELD.SR_MUTE_FL, "sr.fl"],
      [FIELD.SR_GAIN_FR, FIELD.SR_MUTE_FR, "sr.fr"],
      [FIELD.SR_GAIN_C, FIELD.SR_MUTE_C, "sr.c"],
      [FIELD.SR_GAIN_LFE, FIELD.SR_MUTE_LFE, "sr.lfe"],
      [FIELD.SR_GAIN_LS, FIELD.SR_MUTE_LS, "sr.ls"],
      [FIELD.SR_GAIN_RS, FIELD.SR_MUTE_RS, "sr.rs"],
    ].map(([field, muteField, key]) => {
      const f = fader(c, { module: MODULE.SURROUND, field, ...L(key) });
      if (f) channelSwitch(f, { module: MODULE.SURROUND, field: muteField });
      return f;
    });
    const sep = document.createElement("span");
    sep.className = "fsep";
    c.appendChild(sep);
    // 上混与渲染参数
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_STEER, ...L("sr.steer") });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_FRONT_KEEP, ...L("sr.frontKeep") });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_CENTER_HPF, ...L("sr.centerHpf"), step: 10 });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_SURROUND_WRAP, ...L("sr.wrap") });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_SURROUND_DELAY, ...L("sr.delay"), integer: true });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_SURROUND_LPF, ...L("sr.lpf"), step: 100, fmt: (v) => (v >= 20000 ? t("off") : fmtHz(v)) });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_SURROUND_ANGLE, ...L("sr.angle"), step: 5, fmt: (v) => `${Math.round(v)}°` });
    fader(c, { module: MODULE.SURROUND, field: FIELD.SR_ROOM, ...L("sr.room") });
    headSwitch($("sr-timbre"), { module: MODULE.SURROUND, field: FIELD.SR_TIMBRE });
    readonlyPolls.push(async () => {
      const [lr, cs, d] = await Promise.all([
        getP(MODULE.SURROUND, 0, FIELD.SR_DOM_LR),
        getP(MODULE.SURROUND, 0, FIELD.SR_DOM_CS),
        getP(MODULE.SURROUND, 0, FIELD.SR_DELAY_SAMPLES),
      ]);
      const side = (v, neg, pos) => (!Number.isFinite(v) || Math.abs(v) < 0.05 ? t("ro.center") : `${v < 0 ? neg : pos} ${Math.abs(v).toFixed(2)}`);
      $("ro-sr-lr").textContent = side(lr, t("ro.left"), t("ro.right"));
      $("ro-sr-cs").textContent = side(cs, t("ro.surround"), t("ro.centerCh"));
      $("ro-sr-delay").textContent = Number.isFinite(d) ? `${d.toFixed(0)} ${t("unit.samples")}` : "—";
    });
    moduleSwitch("en-surround", MODULE.SURROUND);
    return gains;
  }

  // 高低音提升面板：TrueBass（低频）与 TrueTreble（高频）两组推子在同一个面板里，各自的模块开关在面板头（BO 决策 2026-10-04）
  function buildTrueBass() {
    const c = $("truebass");
    if (!paramInfo(MODULE.TRUEBASS, FIELD.TB_GAIN)) {
      c.textContent = "当前 wasm 不含 TrueBass 模块（需要重新构建 wasm）";
      $("en-truebass").disabled = true;
      return;
    }
    fader(c, { module: MODULE.TRUEBASS, field: FIELD.TB_FREQ, ...L("tone.freq") });
    fader(c, { module: MODULE.TRUEBASS, field: FIELD.TB_GAIN, ...L("tone.gain") });
    readonlyPolls.push(async () => {
      const [inRange, active] = await Promise.all([
        getP(MODULE.TRUEBASS, 0, FIELD.TB_IN_RANGE),
        getP(MODULE.TRUEBASS, 0, FIELD.TB_ACTIVE),
      ]);
      // 合并面板里关掉的一组仍可见：模块开关关着时读数显示"关"，不显示内核里的生效标志
      $("ro-tb").textContent = !$("en-truebass").checked ? t("ro.off") : !inRange ? t("ro.outOfRange") : active ? t("ro.active") : t("ro.passthrough");
    });
    moduleSwitch("en-truebass", MODULE.TRUEBASS, c);
  }

  function buildTreble() {
    const c = $("treble");
    if (!paramInfo(MODULE.TREBLE, FIELD.TR_GAIN)) {
      c.textContent = "当前 wasm 不含 TrueTreble 模块（需要重新构建 wasm）";
      $("en-treble").disabled = true;
      return;
    }
    fader(c, { module: MODULE.TREBLE, field: FIELD.TR_FREQ, ...L("tone.freq"), step: 100 });
    fader(c, { module: MODULE.TREBLE, field: FIELD.TR_GAIN, ...L("tone.gain") });
    // "生效频点"读数已去掉（BO 2026-10-04：多余）；夹取到全局上限时推子读数本身会带 * 号提示
    readonlyPolls.push(async () => {
      const active = await getP(MODULE.TREBLE, 0, FIELD.TR_ACTIVE);
      $("ro-tr").textContent = !$("en-treble").checked ? t("ro.off") : active ? t("ro.active") : t("ro.passthrough");
    });
    moduleSwitch("en-treble", MODULE.TREBLE, c);
  }


  // "3D" 立体声宽度（2026-10-14）：宽度 0…5（1 = 原样）、低频分频点、高频起点、中频参与度
  function buildWidth() {
    const c = $("width");
    if (!paramInfo(MODULE.WIDTH, FIELD.W_WIDTH)) {
      c.textContent = "当前 wasm 不含 3D 立体声宽度模块（需要重新构建 wasm）";
      $("en-width").disabled = true;
      return;
    }
    fader(c, { module: MODULE.WIDTH, field: FIELD.W_WIDTH, ...L("w.width"), fmt: (v) => `${v.toFixed(2)}×` }); // 线性 1000 格（非 dB 推子的约定）
    fader(c, { module: MODULE.WIDTH, field: FIELD.W_XOVER, ...L("w.xover"), step: 10 });
    fader(c, { module: MODULE.WIDTH, field: FIELD.W_HF, ...L("w.hf"), step: 100 });
    fader(c, { module: MODULE.WIDTH, field: FIELD.W_MID, ...L("w.mid") });
    // 宽度 > 2 时提示开限幅（BO 2026-10-14：不做自动增益补偿）
    if ($("w-hint")) {
      readonlyPolls.push(async () => {
        const w = await getP(MODULE.WIDTH, 0, FIELD.W_WIDTH);
        $("w-hint").hidden = !(w > 2);
      });
    }
    moduleSwitch("en-width", MODULE.WIDTH, c);
  }

  // 虚拟舞台（模块 13，2026-10-15）：每个元素一支增益推子（底部 On/Off = 静音）+ 房间感 + 距离衰减；
  // 方位 / 距离 / 宽度是不占推子位的"虚拟控件"（登记进 controls：随配置保存、Default 复位），顶视图读写它们
  function buildStage() {
    const c = $("stage");
    if (!paramInfo(MODULE.STAGE, FIELD.ST_MODE)) {
      c.textContent = "当前 wasm 不含虚拟舞台模块（需要重新构建 wasm）";
      $("en-stage").disabled = true;
      return;
    }
    segControl($("st-mode"), {
      module: MODULE.STAGE,
      field: FIELD.ST_MODE,
      options: [
        [0, t("render.headphones")],
        [1, t("render.speakers")],
      ],
    });
    const count = Math.max(1, Math.min(16, deps.localIndexCount ? deps.localIndexCount(MODULE.STAGE) : 4));
    const kindOf = (i) => {
      const v = deps.localGet ? deps.localGet(MODULE.STAGE, i, FIELD.ST_KIND) : i;
      return Number.isFinite(v) ? v | 0 : i;
    };
    const kinds = [];
    for (let i = 0; i < count; i++) kinds.push(kindOf(i));
    const elements = [];
    for (let i = 0; i < count; i++) {
      const kind = kinds[i];
      const total = kinds.filter((k) => k === kind).length;
      const ordinal = kinds.slice(0, i).filter((k) => k === kind).length;
      const key = `st.${STAGE_KINDS[kind] || "other"}`;
      const suffix = total > 1 ? ` ${ordinal + 1}` : "";
      const gain = fader(c, { module: MODULE.STAGE, index: i, field: FIELD.ST_GAIN, label: ts(key) + suffix, title: t(key) + suffix });
      if (gain) channelSwitch(gain, { module: MODULE.STAGE, index: i, field: FIELD.ST_MUTE });
      const el = { index: i, kind, ordinal, label: ts(key) + suffix, gain };
      for (const [name, field] of [["az", FIELD.ST_AZIMUTH], ["dist", FIELD.ST_DISTANCE], ["width", FIELD.ST_WIDTH]]) {
        const info = paramInfo(MODULE.STAGE, field);
        let value = info.default;
        const ctl = {
          module: MODULE.STAGE,
          index: i,
          field,
          info,
          virtual: true,
          get value() {
            return value;
          },
          setValue(v, send = true) {
            value = Math.min(info.max, Math.max(info.min, v));
            if (send) ctl.send();
            if (P.onStageChange) P.onStageChange();
          },
          send() {
            deps.send(MODULE.STAGE, i, field, value);
          },
          async sync() {
            const v = await getP(MODULE.STAGE, i, field);
            if (Number.isFinite(v)) {
              ctl.setValue(v, false);
              ctl.initial = ctl.value;
            }
          },
          reset() {
            if (ctl.initial !== undefined) ctl.setValue(ctl.initial, true);
          },
          async pull() {
            const v = await getP(MODULE.STAGE, i, field);
            if (Number.isFinite(v)) ctl.setValue(v, false);
          },
        };
        C.controls.push(ctl);
        el[name] = ctl;
      }
      if (gain && gain.row) {
        const sw = gain.row.querySelector(".ch-switch input");
        if (sw) sw.addEventListener("change", () => P.onStageChange && P.onStageChange());
      }
      elements.push(el);
    }
    P.stageElements = elements;
    // 模块级推子：有 stage-mod 容器时放在元素推子下面一行（与顶视图并排的左列），否则接在同一行
    const m = $("stage-mod") || c;
    if (m === c) {
      const sep = document.createElement("span");
      sep.className = "fsep";
      c.appendChild(sep);
    }
    fader(m, { module: MODULE.STAGE, field: FIELD.ST_ROOM, ...L("st.room") });
    fader(m, { module: MODULE.STAGE, field: FIELD.ST_DIST_ATTEN, ...L("st.distAtten") });
    if (paramInfo(MODULE.STAGE, FIELD.ST_REAR)) fader(m, { module: MODULE.STAGE, field: FIELD.ST_REAR, ...L("st.rear") });
    // 高音质模式（阶段 4.5）：段长推子（ms，显示成秒）+ 计算设备（GPU / CPU）；改了宿主会按新设置重起分离 Worker
    if (paramInfo(MODULE.STAGE, FIELD.ST_SEGMENT)) fader(m, { module: MODULE.STAGE, field: FIELD.ST_SEGMENT, label: ts("st.segment"), title: t("st.segment.tip"), step: 100, fmt: (v) => `${(v / 1000).toFixed(1)} s` }); // 面板上叫"音质"（BO 2026-10-16：段长难懂），值仍是秒
    if ($("st-device") && paramInfo(MODULE.STAGE, FIELD.ST_DEVICE)) {
      segControl($("st-device"), {
        module: MODULE.STAGE,
        field: FIELD.ST_DEVICE,
        options: [
          [0, t("st.device.gpu")],
          [1, t("st.device.cpu")],
        ],
      });
      // CPU 模式要多线程 wasm：Firefox 的后台页没有 SharedArrayBuffer，单线程跟不上 → 灰掉（宿主告诉面板）
      if (deps.hqCpu && !deps.hqCpu()) {
        const cpuBtn = $("st-device").querySelectorAll("button")[1];
        if (cpuBtn) {
          cpuBtn.disabled = true;
          cpuBtn.title = t("st.device.cpuNA");
        }
      }
    }
    // 模型行：状态 / 进度条 / 下载、重新下载、取消、删除；分离 Worker 的状态与实时率（宿主经协议的 hq 消息推来）
    const modelRow = $("st-model");
    if (modelRow && deps.hqOp) {
      const status = $("ro-st-model");
      const bar = $("st-model-bar");
      const dl = $("st-model-dl");
      const del = $("st-model-del");
      const engine = $("ro-st-engine");
      let downloading = false;
      let lastHq = null;
      dl.addEventListener("click", () => deps.hqOp(downloading ? "cancel" : "download"));
      del.addEventListener("click", () => deps.hqOp("delete"));
      // 首次使用的醒目提示：舞台开着而模型还没就绪 → 一行带下载键的提示（下载中显示进度，下完自动开始分离，提示收起）
      const setup = $("st-setup");
      const paintSetup = () => {
        if (!setup) return;
        const mdl = (lastHq && lastHq.model) || { state: "none" };
        const on = $("en-stage") && $("en-stage").checked;
        const need = on && mdl.state !== "ready";
        setup.hidden = !need;
        if (!need) return;
        const pct = mdl.state === "downloading" ? `（${mdl.total ? Math.round((100 * mdl.loaded) / mdl.total) : 0}%）` : "";
        $("st-setup-text").textContent = (mdl.state === "downloading" ? t("st.setup.downloading") : mdl.state === "error" ? `${t("st.setup.error")}${mdl.error ? "：" + mdl.error : ""}` : t("st.setup.none")) + pct;
        $("st-setup-dl").textContent = mdl.state === "downloading" ? t("st.model.cancel") : t("st.model.download");
        $("st-setup-dl").hidden = !deps.hqOp;
      };
      if (setup) {
        $("st-setup-dl").addEventListener("click", () => deps.hqOp(downloading ? "cancel" : "download"));
        if ($("en-stage")) $("en-stage").addEventListener("change", paintSetup);
      }
      P.onHq = (hq) => {
        lastHq = hq;
        paintSetup();
        const mdl = hq.model || { state: "none" };
        const eng = hq.engine || { state: "off" };
        downloading = mdl.state === "downloading";
        const mb = (n) => `${(n / 1e6).toFixed(0)} MB`;
        let text = t(`st.model.${mdl.state}`) || mdl.state;
        if (mdl.state === "downloading") text += ` ${mdl.total ? Math.round((100 * mdl.loaded) / mdl.total) : 0}%`;
        else if (mdl.state === "ready") text += ` · ${mb(mdl.total)}`;
        else if (mdl.state === "error" && mdl.error) text += `：${mdl.error}`;
        status.textContent = text;
        bar.hidden = mdl.state !== "downloading";
        bar.max = mdl.total || 1;
        bar.value = mdl.loaded || 0;
        dl.textContent = downloading ? t("st.model.cancel") : mdl.state === "ready" ? t("st.model.redownload") : `${t("st.model.download")}（${mb(mdl.total || 0)}）`;
        del.hidden = mdl.state !== "ready";
        let et = t(`st.engine.${eng.state}`) || eng.state;
        if (eng.state === "on") et += ` · ${eng.ep === "webgpu" ? "GPU" : `CPU ×${eng.threads || 1}`}${eng.fallback ? " (GPU→CPU)" : ""}`;
        else if (eng.state === "starting" && eng.note) et += ` · ${eng.note}`;
        else if ((eng.state === "failed" || eng.state === "nomodel") && eng.error) et += `：${eng.error}`;
        engine.textContent = et;
        if ($("ro-st-rtf")) $("ro-st-rtf").textContent = eng.state === "on" && eng.rtf ? eng.rtf.toFixed(2) : "—";
        if ($("ro-st-rtf")) $("ro-st-rtf").classList.toggle("over", eng.state === "on" && eng.rtf > 1);
      };
    }
    // 复位摆位：方位 / 距离 / 宽度回引擎启动时的默认摆位（不动增益）
    if ($("st-layout")) {
      $("st-layout").addEventListener("click", () => {
        for (const el of elements) for (const k of ["az", "dist", "width"]) el[k].reset();
        deps.touch();
      });
    }
    // 分离器没就绪（权重还在加载 / Worker 起不来）→ 提示原声直通
    let sysTick = 0;
    if ($("ro-st-cpu") && !deps.sysInfo) $("ro-st-cpu").parentElement.querySelectorAll(".sys").forEach((e) => (e.hidden = true));
    // 浏览器没有整机占用的接口（Firefox 没有 chrome.system.*）：两格留着，写"不支持"，悬停说明原因；不去问后台
    const sysAvail = !!deps.sysInfo && (!deps.sysAvail || deps.sysAvail());
    const paintSysNA = () => {
      for (const id of ["ro-st-cpu", "ro-st-mem"]) {
        if (!$(id)) continue;
        $(id).textContent = t("ro.sys.na");
        $(id).title = t("ro.sys.naTip");
        if ($(id).previousElementSibling) $(id).previousElementSibling.title = t("ro.sys.naTip");
      }
    };
    if ($("ro-st-cpu") && deps.sysInfo && !sysAvail) paintSysNA();
    if ($("st-hint")) {
      // 舞台没开就什么都不刷（BO 2026-10-16）：读数统一一根横线，不读引擎、不问系统占用；开了才每 500 ms 轮询
      let stageIdle = false;
      readonlyPolls.push(async () => {
        const on = $("en-stage") && $("en-stage").checked;
        if (!on) {
          if (!stageIdle) {
            stageIdle = true;
            $("st-hint").hidden = true;
            for (const id of sysAvail ? ["ro-st-latency", "ro-st-rtf", "ro-st-late", "ro-st-cpu", "ro-st-mem"] : ["ro-st-latency", "ro-st-rtf", "ro-st-late"]) if ($(id)) $(id).textContent = "—";
          }
          return;
        }
        stageIdle = false;
        const feeding = await getP(MODULE.STAGE, 0, FIELD.ST_FEEDING);
        $("st-hint").hidden = !(feeding < 0.5);
        if ($("ro-st-cpu") && sysAvail && ++sysTick % 2 === 0) {
          // 每 1 s（轮询 500 ms 一次）问一次系统占用；浏览器只给得出 CPU 与系统内存，GPU / 显存没有接口
          const si = await deps.sysInfo();
          $("ro-st-cpu").textContent = si && Number.isFinite(si.cpu) ? `${Math.round(si.cpu)}%` : "—";
          $("ro-st-mem").textContent = si && si.mem ? `${(si.mem.used / 2 ** 30).toFixed(1)} / ${(si.mem.total / 2 ** 30).toFixed(0)} GB` : "—";
        }
        if ($("ro-st-latency")) {
          const [lat, late] = await Promise.all([getP(MODULE.STAGE, 0, FIELD.ST_LATENCY), getP(MODULE.STAGE, 0, FIELD.ST_DROPPED)]);
          // 分段分离的延时是秒级：有采样率就显示成秒
          const fs = deps.sampleRate ? deps.sampleRate() : 0;
          $("ro-st-latency").textContent = !Number.isFinite(lat) ? "—" : fs > 0 && lat >= fs / 10 ? `${(lat / fs).toFixed(2)} s` : `${Math.round(lat)} ${t("unit.samples")}`;
          $("ro-st-late").textContent = Number.isFinite(late) ? `${Math.round(late)}` : "—";
        }
      });
    }
    moduleSwitch("en-stage", MODULE.STAGE, c);
    // 开舞台、关舞台都把四个元素的摆位（方位 / 距离 / 宽度）与增益推子回引擎默认，并停掉"演示"旋转（BO 2026-10-16）
    if ($("en-stage")) {
      $("en-stage").addEventListener("change", () => {
        if (P.onStageReset) P.onStageReset(); // 先停演示，不然它下一拍又把人声转走
        for (const el of elements) for (const k of ["az", "dist", "width", "gain"]) if (el[k] && el[k].reset) el[k].reset();
        deps.touch();
      });
    }
  }

  /** 按测试页的顺序建全部面板（容器不存在的面板跳过）。 */
  function buildAll() {
    if ($("output-controls")) buildOutput();
    if ($("eq")) buildEq();
    if ($("truebass")) buildTrueBass();
    if ($("treble")) buildTreble();
    if ($("width")) buildWidth();
    if ($("reverb")) buildReverbPanel();
    if ($("surround")) buildSurroundPanel();
    if ($("stage")) buildStage();
  }

  P.buildOutput = buildOutput;
  P.buildEq = buildEq;
  P.buildTrueBass = buildTrueBass;
  P.buildTreble = buildTreble;
  P.buildWidth = buildWidth;
  P.buildReverbPanel = buildReverbPanel;
  P.buildSurroundPanel = buildSurroundPanel;
  P.buildStage = buildStage;
  P.buildAll = buildAll;
  return P;
}
