// Neo Audio — 分离模型的下载与缓存（阶段 4.5）。
//
// htdemucs 的 ONNX（约 168 MB）不随插件包，第一次启用高音质模式时从 GitHub Releases 下载，存进本源的 IndexedDB；
// 之后每次启动从 IndexedDB 读。进度 / 状态由 onState 回调给宿主广播到面板（进度条、重新下载 / 删除按钮）。
//
//   const store = new ModelStore({ url, key: "htdemucs-dyn-fp32", size: 168_667_978 });
//   store.onState = (s) => …            // {state:'none'|'downloading'|'ready'|'error', loaded, total, error}
//   await store.status();              // 查 IndexedDB，刷新 state
//   await store.download();            // 下载并存（可 cancel()）
//   const bytes = await store.bytes(); // ArrayBuffer（没有就 null）
//   await store.delete();

const DB_NAME = "neo-models";
const STORE = "files";

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "key" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("IndexedDB 打不开"));
  });
}

function tx(db, mode, fn) {
  // 等事务 complete 而不是请求 success：写入 168 MB 后文档可能马上被关掉（offscreen 空闲即关），请求成功时事务还没提交，数据会丢
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    let result;
    const req = fn(t.objectStore(STORE));
    req.onsuccess = () => {
      result = req.result;
    };
    req.onerror = () => reject(req.error || new Error("IndexedDB 操作失败"));
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error || new Error("IndexedDB 事务失败"));
    t.onabort = () => reject(t.error || new Error("IndexedDB 事务中止"));
  });
}

export class ModelStore {
  /** @param {{url:string, key?:string, size?:number}} o size 只用于进度条总长（HTTP 没给 content-length 时） */
  constructor(o) {
    this.url = o.url;
    this.key = o.key || "model";
    this.size = o.size || 0;
    this.state = { state: "none", loaded: 0, total: this.size, error: null, url: this.url };
    this.onState = null;
    this._abort = null;
  }

  _set(patch) {
    Object.assign(this.state, patch);
    if (this.onState) this.onState(this.state);
    return this.state;
  }

  /** 查缓存：有 → ready（total = 文件大小），没有 → none。下载中不打断。 */
  async status() {
    if (this.state.state === "downloading") return this.state;
    try {
      const db = await openDb();
      const rec = await tx(db, "readonly", (s) => s.get(this.key));
      db.close();
      if (rec && rec.blob) return this._set({ state: "ready", loaded: rec.blob.size, total: rec.blob.size, error: null });
      return this._set({ state: "none", loaded: 0, total: this.size, error: null });
    } catch (e) {
      return this._set({ state: "error", error: `IndexedDB：${e.message}` });
    }
  }

  /** 模型字节（没有缓存返回 null）。每次都从 IndexedDB 读（不在内存里留一份 168 MB）。 */
  async bytes() {
    try {
      const db = await openDb();
      const rec = await tx(db, "readonly", (s) => s.get(this.key));
      db.close();
      return rec && rec.blob ? await rec.blob.arrayBuffer() : null;
    } catch (_) {
      return null;
    }
  }

  /** 下载并存进 IndexedDB。进度经 onState 回调。重复调用时若正在下载则等它。 */
  async download() {
    if (this._abort) return this.state;
    const ac = new AbortController();
    this._abort = ac;
    this._set({ state: "downloading", loaded: 0, total: this.size, error: null });
    try {
      const resp = await fetch(this.url, { signal: ac.signal, cache: "no-store" });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const total = parseInt(resp.headers.get("content-length") || "0", 10) || this.size;
      const chunks = [];
      let loaded = 0;
      let lastReport = 0;
      if (resp.body && resp.body.getReader) {
        const reader = resp.body.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
          loaded += value.byteLength;
          const now = performance.now();
          if (now - lastReport > 150) {
            lastReport = now;
            this._set({ loaded, total });
          }
        }
      } else {
        const buf = await resp.arrayBuffer();
        chunks.push(new Uint8Array(buf));
        loaded = buf.byteLength;
      }
      const blob = new Blob(chunks, { type: "application/octet-stream" });
      if (blob.size < 1_000_000) throw new Error(`文件太小（${blob.size} 字节），不像模型`);
      const db = await openDb();
      await tx(db, "readwrite", (s) => s.put({ key: this.key, blob, size: blob.size, url: this.url, date: Date.now() }));
      db.close();
      return this._set({ state: "ready", loaded: blob.size, total: blob.size, error: null });
    } catch (e) {
      const aborted = e && e.name === "AbortError";
      return this._set({ state: aborted ? "none" : "error", loaded: 0, error: aborted ? null : `下载失败：${e.message}` });
    } finally {
      this._abort = null;
    }
  }

  /** 取消进行中的下载。 */
  cancel() {
    if (this._abort) this._abort.abort();
  }

  async delete() {
    this.cancel();
    try {
      const db = await openDb();
      await tx(db, "readwrite", (s) => s.delete(this.key));
      db.close();
      return this._set({ state: "none", loaded: 0, total: this.size, error: null });
    } catch (e) {
      return this._set({ state: "error", error: `删除失败：${e.message}` });
    }
  }
}
