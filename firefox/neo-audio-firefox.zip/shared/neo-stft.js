// Neo Audio — htdemucs 模型外的 STFT / iSTFT（阶段 4.4 探针里对拍过：STFT 对 Python 1.8e-7，iSTFT + 时域分支 2e-6）。
//
// 与 demucs 的 spectro / ispectro 一致：4096 点周期 Hann、跳 1024、normalized、center + reflect；外层再按 standalone_spec
// 的 1536 反射补零与切帧。CaC 排布：通道顺序 L实 L虚 R实 R虚，[4][2048][T]，T = ceil(L / 1024)。
// 分离 Worker（neo-hq-worker.js）与探针（tools/nn/probe-htdemucs.js）共用。

export const NFFT = 4096;
export const HOP = 1024;
export const BINS = NFFT / 2; // 丢掉奈奎斯特后的 2048
export const STEMS = 4; // htdemucs 的声部顺序：鼓 / 贝斯 / 其它 / 人声

// ---- FFT（基 2，复数，就地）
function makeFft(n) {
  const cos = new Float32Array(n / 2);
  const sin = new Float32Array(n / 2);
  for (let k = 0; k < n / 2; k++) {
    cos[k] = Math.cos((-2 * Math.PI * k) / n);
    sin[k] = Math.sin((-2 * Math.PI * k) / n);
  }
  const rev = new Uint32Array(n);
  const bits = Math.log2(n);
  for (let i = 0; i < n; i++) {
    let r = 0;
    for (let b = 0; b < bits; b++) r = (r << 1) | ((i >> b) & 1);
    rev[i] = r;
  }
  return (re, im, inverse = false) => {
    for (let i = 0; i < n; i++) {
      const j = rev[i];
      if (j > i) {
        let t = re[i];
        re[i] = re[j];
        re[j] = t;
        t = im[i];
        im[i] = im[j];
        im[j] = t;
      }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const half = len >> 1;
      const step = n / len;
      for (let start = 0; start < n; start += len) {
        for (let k = 0; k < half; k++) {
          const wr = cos[k * step];
          const wi = inverse ? -sin[k * step] : sin[k * step];
          const a = start + k;
          const b = a + half;
          const tr = re[b] * wr - im[b] * wi;
          const ti = re[b] * wi + im[b] * wr;
          re[b] = re[a] - tr;
          im[b] = im[a] - ti;
          re[a] += tr;
          im[a] += ti;
        }
      }
    }
    if (inverse) {
      for (let i = 0; i < n; i++) {
        re[i] /= n;
        im[i] /= n;
      }
    }
  };
}
const fft = makeFft(NFFT);
const WIN = new Float32Array(NFFT);
for (let i = 0; i < NFFT; i++) WIN[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / NFFT); // periodic Hann（torch 默认）

/** 反射补零（torch reflect）。 */
function reflectPad(x, left, right) {
  const n = x.length;
  const out = new Float32Array(n + left + right);
  for (let i = 0; i < out.length; i++) {
    let j = i - left;
    if (j < 0) j = -j;
    if (j >= n) j = 2 * (n - 1) - j;
    out[i] = x[j];
  }
  return out;
}

/**
 * standalone_spec + standalone_magnitude：输入 [2][L] → CaC 谱 Float32Array [4][2048][T]（通道顺序 L实 L虚 R实 R虚），
 * T = ceil(L / 1024)。
 */
export function stftCac(mix, L) {
  const T = Math.ceil(L / HOP);
  const pad = (HOP / 2) * 3; // 1536
  const out = new Float32Array(4 * BINS * T);
  const re = new Float32Array(NFFT);
  const im = new Float32Array(NFFT);
  const scale = 1 / Math.sqrt(NFFT); // normalized=True
  for (let ch = 0; ch < 2; ch++) {
    // 外层 reflect：(pad, pad + T*hop − L)；torch.stft center=True 再 reflect 2048
    const x1 = reflectPad(mix[ch].subarray(0, L), pad, pad + T * HOP - L);
    const x2 = reflectPad(x1, NFFT / 2, NFFT / 2);
    const nFrames = 1 + Math.floor((x2.length - NFFT) / HOP);
    // 取帧 2 .. 2+T
    for (let f = 2; f < 2 + T; f++) {
      if (f >= nFrames) throw new Error("帧数不够");
      const off = f * HOP;
      for (let i = 0; i < NFFT; i++) {
        re[i] = x2[off + i] * WIN[i];
        im[i] = 0;
      }
      fft(re, im, false);
      const t = f - 2;
      for (let k = 0; k < BINS; k++) {
        out[(ch * 2 * BINS + k) * T + t] = re[k] * scale;
        out[((ch * 2 + 1) * BINS + k) * T + t] = im[k] * scale;
      }
    }
  }
  return { x: out, T };
}

/**
 * standalone_mask(cac) + standalone_ispec：outX [S=4][4][2048][T] → 每个声部 [2][L]；再加时域分支 outXt [4][2][L]。
 * 返回 stems[s][ch] = Float32Array(L)。
 */
export function istftStems(outX, outXt, L, T) {
  const pad = (HOP / 2) * 3;
  const framesTot = T + 4; // 两边各补 2 帧
  const stems = [];
  const re = new Float32Array(NFFT);
  const im = new Float32Array(NFFT);
  const scale = Math.sqrt(NFFT); // normalized=True 的逆
  const total = NFFT + (framesTot - 1) * HOP;
  const acc = new Float32Array(total);
  // 窗平方和与声部 / 声道无关，算一次
  const wsum = new Float32Array(total);
  for (let f = 0; f < framesTot; f++) {
    const off = f * HOP;
    for (let i = 0; i < NFFT; i++) wsum[off + i] += WIN[i] * WIN[i];
  }
  for (let s = 0; s < STEMS; s++) {
    const chans = [];
    for (let ch = 0; ch < 2; ch++) {
      acc.fill(0);
      // istft（center=True）：帧 f 的中心在 f*hop（相对补了 2048 的信号起点 2048）
      for (let f = 0; f < framesTot; f++) {
        const t = f - 2;
        if (t < 0 || t >= T) continue; // 补的帧是零谱，贡献为零
        for (let k = 0; k < NFFT; k++) {
          re[k] = 0;
          im[k] = 0;
        }
        const base = (s * 4 + ch * 2) * BINS * T;
        const baseI = (s * 4 + ch * 2 + 1) * BINS * T;
        for (let k = 0; k < BINS; k++) {
          re[k] = outX[base + k * T + t] * scale;
          im[k] = outX[baseI + k * T + t] * scale;
        }
        // 奈奎斯特为 0；负频率共轭对称
        for (let k = 1; k < BINS; k++) {
          re[NFFT - k] = re[k];
          im[NFFT - k] = -im[k];
        }
        fft(re, im, true);
        const off = f * HOP;
        for (let i = 0; i < NFFT; i++) acc[off + i] += re[i] * WIN[i];
      }
      const y = new Float32Array(L);
      const xt = (s * 2 + ch) * L;
      for (let i = 0; i < L; i++) {
        const j = NFFT / 2 + pad + i; // 去掉 center 的 2048 与外层的 1536
        const w = wsum[j];
        y[i] = (w > 1e-8 ? acc[j] / w : 0) + outXt[xt + i];
      }
      chans.push(y);
    }
    stems.push(chans);
  }
  return stems;
}
