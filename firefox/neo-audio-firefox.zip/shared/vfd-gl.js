// Neo Audio — VFD 显示屏的 WebGL 渲染器（阶段 2.9 第 3 批，BO 决策：怎样性能高怎样改）。
//
// 分工：显示规则在内核灯板（哪些格亮、亮多少），版面与文字在页面的 Canvas 2D"静态层"（只在布局/风格变化时
// 重画一次、上传一次），每帧真正变化的只有点亮的格子——这里把灯板的亮度数组当作纹理，用一个片元着色器一次画完整块
// 点阵（逐像素算段的覆盖率，与 fillRect 的抗锯齿一致），再用几个小通道复现 Canvas 版的辉光：
//   发光层 lit → 栅极网切暗 litC → 透明度金字塔 1/2、1/4、1/8、1/16 → 合成（静态层 + 远晕×n + 宽晕 + 近晕 + 段本体 + 玻璃高光）
// 画法与 app.js 的 bloom() 逐步对应，颜色、不透明度、重复次数都从页面传入。
//
// 坐标约定：所有纹理的 v = 0 都是画布顶行（与 texImage2D(canvas) 一致）；画进离屏 FBO 时 gl_FragCoord.y 就是画布 y，
// 画到屏幕时翻转（u_flip = 1）。片元里的像素格 = [floor(P), floor(P) + 1)。

const VS = `
attribute vec2 a_pos;
uniform vec4 u_rect;
uniform vec2 u_size;
uniform float u_flip;
void main() {
  vec2 p = u_rect.xy + a_pos * u_rect.zw;
  vec2 c = p / u_size * 2.0 - 1.0;
  c.y = mix(c.y, -c.y, u_flip);
  gl_Position = vec4(c, 0.0, 1.0);
}`;

const HEAD = `
precision highp float;
uniform vec2 u_size;
uniform float u_flip;
vec2 canvasPos() { return vec2(gl_FragCoord.x, mix(gl_FragCoord.y, u_size.y - gl_FragCoord.y, u_flip)); }
float cover1(float p0, float a, float b) { return clamp(min(p0 + 1.0, b) - max(p0, a), 0.0, 1.0); }
`;

// 点阵格：每个像素找到自己所在的列/行，读该格（及上下相邻行，段的外扩可能跨进本像素）的亮度，按段矩形算覆盖率
const FS_CELLS = HEAD + `
uniform sampler2D u_bright;   // LUMINANCE_ALPHA：L = 全亮亮度²，A = 半亮亮度²
uniform sampler2D u_colmap;   // LUMINANCE：列 → 柱号（255 = 空列）
uniform float u_useColmap;
uniform float u_x0, u_colW, u_rowH, u_yBottom, u_segW, u_segH, u_dpr, u_cols, u_rows, u_bars;
uniform vec3 u_litColor, u_dimColor;
uniform float u_dimAlpha;
vec4 cell(float fc, float fr, float bar, vec2 pb) {
  if (fr < 0.0 || fr >= u_rows) return vec4(0.0);
  // 亮度纹理按 [柱][行] 排：s = 行、t = 柱
  vec4 t = texture2D(u_bright, vec2((fr + 0.5) / u_rows, (bar + 0.5) / u_bars));
  float a = t.r, b = t.a;
  if (a <= 0.0 && b <= 0.0) return vec4(0.0);
  bool lit = a >= b;
  float e = (lit ? 0.3 : 0.2) * u_dpr;
  float x0 = u_x0 + fc * u_colW + u_dpr - e;
  float y0 = u_yBottom - (fr + 1.0) * u_rowH + (u_rowH - u_segH) * 0.5 - e;
  float cov = cover1(pb.x, x0, x0 + u_segW + 2.0 * e) * cover1(pb.y, y0, y0 + u_segH + 2.0 * e);
  vec4 col = lit ? vec4(u_litColor, 1.0) * a : vec4(u_dimColor, 1.0) * (u_dimAlpha * b);
  return col * cov;
}
float barOf(float fc) {
  if (fc < 0.0 || fc >= u_cols) return -1.0;
  if (u_useColmap < 0.5) return fc;
  float b = floor(texture2D(u_colmap, vec2((fc + 0.5) / u_cols, 0.5)).r * 255.0 + 0.5);
  return b > 200.0 ? -1.0 : b;
}
void main() {
  vec2 P = canvasPos();
  float fc = floor((P.x - u_x0) / u_colW);
  float fr = floor((u_yBottom - P.y) / u_rowH);
  vec2 pb = floor(P);
  // 段外扩后可能跨进相邻列/行的像素格（点距小时相邻列几乎相接），所以把 3×3 邻域的格都算上，
  // 按列优先、行升序叠加（与页面逐列逐行 fillRect 的次序一致）
  vec4 o = vec4(0.0);
  for (int dc = -1; dc <= 1; dc++) {
    float c0 = fc + float(dc);
    float bar = barOf(c0);
    if (bar < 0.0) continue;
    for (int dr = -1; dr <= 1; dr++) {
      vec4 c = cell(c0, fr + float(dr), bar, pb);
      o = c + o * (1.0 - c.a);
    }
  }
  if (o.a <= 0.0) discard;
  gl_FragColor = o;
}`;

// 单个矩形段（OVER 红段等）：按覆盖率抗锯齿
const FS_RECT = HEAD + `
uniform vec4 u_box;   // x0, y0, x1, y1（已含外扩）
uniform vec4 u_color; // 预乘
void main() {
  vec2 pb = floor(canvasPos());
  float cov = cover1(pb.x, u_box.x, u_box.z) * cover1(pb.y, u_box.y, u_box.w);
  if (cov <= 0.0) discard;
  gl_FragColor = u_color * cov;
}`;

// 把一张预乘的纹理原样画上（2D 离屏层，如曲线；静态层）
const FS_BLIT = HEAD + `
uniform sampler2D u_tex;
void main() { gl_FragColor = texture2D(u_tex, canvasPos() / u_size); }`;

// 栅极网切暗：发光层 × (1 − carve × 网格)
const FS_CARVE = HEAD + `
uniform sampler2D u_tex, u_mesh;
uniform vec2 u_tile;
uniform float u_carve;
void main() {
  vec2 P = canvasPos();
  float m = texture2D(u_mesh, (mod(floor(P), u_tile) + 0.5) / u_tile).a;
  gl_FragColor = texture2D(u_tex, P / u_size) * (1.0 - u_carve * m);
}`;

// 金字塔：取源的透明度（第一级）或 r 通道，双线性采样 = 缩小时的 2×2 平均
const FS_DOWN = HEAD + `
uniform sampler2D u_tex;
uniform float u_fromAlpha;
void main() {
  vec4 s = texture2D(u_tex, canvasPos() / u_size);
  gl_FragColor = vec4(mix(s.r, s.a, u_fromAlpha), 0.0, 0.0, 1.0);
}`;

// 合成：静态层 → 远晕（重复 n 次 source-over，等价 1 − (1 − a)^n）→ 宽晕 → 近晕 → 段本体 → 玻璃斜向高光与顶边亮线
const FS_COMPOSE = HEAD + `
uniform sampler2D u_static, u_lit, u_s2, u_s4, u_s8;
uniform vec3 u_tint;
uniform float u_far, u_farRepeat, u_wide, u_near, u_glass, u_dpr;
void main() {
  vec2 P = canvasPos();
  vec2 uv = P / u_size;
  vec3 c = texture2D(u_static, uv).rgb;
  float keep = pow(1.0 - u_far * texture2D(u_s8, uv).r, u_farRepeat);
  c = u_tint * (1.0 - keep) + c * keep;
  float a = u_wide * texture2D(u_s4, uv).r;
  c = u_tint * a + c * (1.0 - a);
  a = u_near * texture2D(u_s2, uv).r;
  c = u_tint * a + c * (1.0 - a);
  vec4 l = texture2D(u_lit, uv);
  c = l.rgb + c * (1.0 - l.a);
  if (u_glass > 0.5) {
    // createLinearGradient(0, 0, 0.6W, H)：t 为沿该向量的投影；0 → 0.07，0.45 → 0.015，0.5 → 0
    vec2 d = vec2(0.6 * u_size.x, u_size.y);
    float t = dot(P, d) / dot(d, d);
    float ga = t < 0.45 ? mix(0.07, 0.015, t / 0.45) : (t < 0.5 ? mix(0.015, 0.0, (t - 0.45) / 0.05) : 0.0);
    c = c * (1.0 - ga) + ga;
    float line = 0.10 * clamp(u_dpr - floor(P.y), 0.0, 1.0);
    c = c * (1.0 - line) + line;
  }
  gl_FragColor = vec4(c, 1.0);
}`;

function compile(gl, type, src) {
  const sh = gl.createShader(type);
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(`着色器编译失败: ${gl.getShaderInfoLog(sh)}`);
  return sh;
}

function program(gl, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, VS));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
  gl.bindAttribLocation(p, 0, "a_pos");
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(`着色器链接失败: ${gl.getProgramInfoLog(p)}`);
  const u = {};
  const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) {
    const info = gl.getActiveUniform(p, i);
    u[info.name] = gl.getUniformLocation(p, info.name);
  }
  return { p, u };
}

/**
 * 建 WebGL 渲染器（优先 WebGL2，其次 WebGL1）；拿不到上下文返回 null（页面退回 Canvas 2D）。
 * @param {HTMLCanvasElement} canvas
 * @param {{p3?: boolean, preserve?: boolean}} opts p3：以 display-p3 解释颜色（与页面 2D 路径一致）；preserve：保留绘制缓冲（自动化读像素用）
 */
/** 拿 WebGL 上下文（统一入口，便于日后按环境换策略）。 */
function getGlContext(canvas, kind, attrs) {
  return canvas.getContext(kind, attrs);
}

export function createVfdGl(canvas, opts = {}) {
  let gl = null;
  let gl2 = false;
  const attrs = { alpha: false, antialias: false, depth: false, stencil: false, premultipliedAlpha: true, preserveDrawingBuffer: !!opts.preserve, powerPreference: "high-performance" };
  try {
    // 优先 WebGL2：溢光的读回可以异步（PBO + fence），不让 GPU 停下来等；WebGL1 只能同步读回
    gl = getGlContext(canvas, "webgl2", attrs);
    gl2 = !!gl;
    if (!gl) gl = getGlContext(canvas, "webgl", attrs);
  } catch (_) {
    gl = null;
  }
  if (!gl) return null;
  const p3 = !!opts.p3 && "drawingBufferColorSpace" in gl;
  if (p3) {
    try {
      gl.drawingBufferColorSpace = "display-p3";
      gl.unpackColorSpace = "display-p3";
    } catch (_) {
      /* 浏览器不支持则按 sRGB */
    }
  }
  const progs = { cells: program(gl, FS_CELLS), rect: program(gl, FS_RECT), blit: program(gl, FS_BLIT), carve: program(gl, FS_CARVE), down: program(gl, FS_DOWN), compose: program(gl, FS_COMPOSE) };
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

  const tex = (filter, wrap = gl.CLAMP_TO_EDGE) => {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
    return t;
  };
  const fboTarget = (w, h) => {
    const t = tex(gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return { t, fb, w, h };
  };

  const R = {
    gl,
    gl2,
    p3,
    W: 0,
    H: 0,
    dpr: 1,
    lost: false,
    _targets: null,
    _static: { t: tex(gl.NEAREST), key: null },
    _mesh: { t: tex(gl.NEAREST), w: 1, h: 1, key: null, carve: 0 }, // 非 2 的幂尺寸不能用 REPEAT（WebGL1 会判纹理不完整），平铺在着色器里取模
    _bright: { t: tex(gl.NEAREST), w: 0, h: 0 },
    _colmap: { t: tex(gl.NEAREST), key: null, n: 0 },
    _layer: { t: tex(gl.NEAREST), w: 0, h: 0 },
    _spillBuf: null,
    _spillPbo: null,
    _spillSync: null,
    _spillReady: null,
    colors: { lit: [1, 1, 1], dim: [1, 1, 1], dimAlpha: 0.8, tint: [1, 1, 1] },
  };
  canvas.addEventListener("webglcontextlost", (e) => {
    e.preventDefault();
    R.lost = true;
    if (R.onLost) R.onLost();
  });
  canvas.addEventListener("webglcontextrestored", () => {
    // 资源全部失效：让页面在同一个上下文上重建渲染器（createVfdGl 会拿到恢复后的同一个上下文）
    if (R.onRestored) R.onRestored();
  });

  function use(pr, size, flip, rect) {
    gl.useProgram(pr.p);
    gl.uniform2f(pr.u.u_size, size[0], size[1]);
    gl.uniform1f(pr.u.u_flip, flip);
    gl.uniform4f(pr.u.u_rect, rect[0], rect[1], rect[2], rect[3]);
  }
  function bindTex(pr, name, unit, t) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.uniform1i(pr.u[name], unit);
  }
  function draw() {
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
  function target(fb, w, h) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.viewport(0, 0, w, h);
  }

  /** 画布尺寸（像素）变化时重建离屏目标。 */
  R.resize = function (W, H, dpr) {
    R.dpr = dpr;
    if (R.W === W && R.H === H && R._targets) return;
    R.W = W;
    R.H = H;
    if (R._targets) for (const k of Object.keys(R._targets)) { gl.deleteFramebuffer(R._targets[k].fb); gl.deleteTexture(R._targets[k].t); }
    const r = (v) => Math.max(1, Math.round(v));
    R._targets = { lit: fboTarget(W, H), litC: fboTarget(W, H), s2: fboTarget(r(W / 2), r(H / 2)), s4: fboTarget(r(W / 4), r(H / 4)), s8: fboTarget(r(W / 8), r(H / 8)), s16: fboTarget(r(W / 16), r(H / 16)) };
    R._static.key = null;
  };

  /** 颜色（0–255 分量：core 段本体、dim 半亮、tint 磷光溢光；p3 开着时按 display-p3 解释）。 */
  R.setColors = function ({ core, dim, dimAlpha = 0.8, tint }) {
    const n = (c) => [c[0] / 255, c[1] / 255, c[2] / 255];
    R.colors = { lit: n(core), dim: n(dim), dimAlpha, tint: n(tint) };
  };

  /** 静态层（玻璃底 + 幽灵段 + 文字 + 基线）：同一个 key 只上传一次。 */
  R.setStatic = function (key, canvas2d) {
    if (R._static.key === key) return;
    R._static.key = key;
    gl.bindTexture(gl.TEXTURE_2D, R._static.t);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas2d);
  };

  /** 栅极网单元（白色描边、透明底的小画布）与切暗强度。 */
  R.setMesh = function (key, tileCanvas, carve) {
    R._mesh.carve = carve;
    if (R._mesh.key === key) return;
    R._mesh.key = key;
    R._mesh.w = tileCanvas.width;
    R._mesh.h = tileCanvas.height;
    gl.bindTexture(gl.TEXTURE_2D, R._mesh.t);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tileCanvas);
  };

  /** 一帧开始：清空发光层。 */
  R.begin = function () {
    const T = R._targets;
    target(T.lit.fb, T.lit.w, T.lit.h);
    gl.disable(gl.BLEND);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  };

  /**
   * 画一块点阵。bright：Uint8Array，每格 2 字节（全亮亮度²、半亮亮度²，0–255），按 [柱][行] 排，bars × rows；
   * colMap：每列的柱号（255 = 空列），不给则列号 = 柱号。几何与 app.js segGrid 一致（画布像素，y 向下）。
   */
  R.cells = function ({ x0, colW, rowH, yBottom, segW, segH, cols, rows, bars, bright, colMap = null, colKey = "" }) {
    const T = R._targets;
    const pr = progs.cells;
    const b = R._bright;
    gl.bindTexture(gl.TEXTURE_2D, b.t);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    if (b.w !== bars || b.h !== rows) {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE_ALPHA, rows, bars, 0, gl.LUMINANCE_ALPHA, gl.UNSIGNED_BYTE, bright);
      b.w = bars;
      b.h = rows;
    } else {
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, rows, bars, gl.LUMINANCE_ALPHA, gl.UNSIGNED_BYTE, bright);
    }
    const cm = R._colmap;
    if (colMap && cm.key !== colKey) {
      cm.key = colKey;
      cm.n = colMap.length;
      gl.bindTexture(gl.TEXTURE_2D, cm.t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, colMap.length, 1, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, colMap);
    }
    const yTop = yBottom - rows * rowH;
    use(pr, [T.lit.w, T.lit.h], 0, [x0 - 1, yTop - 1, cols * colW + 2, rows * rowH + 2]);
    bindTex(pr, "u_bright", 0, b.t);
    bindTex(pr, "u_colmap", 1, cm.t);
    gl.uniform1f(pr.u.u_useColmap, colMap ? 1 : 0);
    gl.uniform1f(pr.u.u_x0, x0);
    gl.uniform1f(pr.u.u_colW, colW);
    gl.uniform1f(pr.u.u_rowH, rowH);
    gl.uniform1f(pr.u.u_yBottom, yBottom);
    gl.uniform1f(pr.u.u_segW, segW);
    gl.uniform1f(pr.u.u_segH, segH);
    gl.uniform1f(pr.u.u_dpr, R.dpr);
    gl.uniform1f(pr.u.u_cols, cols);
    gl.uniform1f(pr.u.u_rows, rows);
    gl.uniform1f(pr.u.u_bars, bars);
    gl.uniform3fv(pr.u.u_litColor, R.colors.lit);
    gl.uniform3fv(pr.u.u_dimColor, R.colors.dim);
    gl.uniform1f(pr.u.u_dimAlpha, R.colors.dimAlpha);
    draw();
  };

  /** 一个段矩形（预乘颜色 0–1，alpha 1），外扩 expand 像素。 */
  R.rect = function (x, y, w, h, expand, rgb) {
    const T = R._targets;
    const pr = progs.rect;
    use(pr, [T.lit.w, T.lit.h], 0, [x - expand - 1, y - expand - 1, w + 2 * expand + 2, h + 2 * expand + 2]);
    gl.uniform4f(pr.u.u_box, x - expand, y - expand, x + w + expand, y + h + expand);
    gl.uniform4f(pr.u.u_color, rgb[0], rgb[1], rgb[2], 1);
    draw();
  };

  /** 把一张与画布同尺寸、带透明度的 2D 画布叠进发光层（曲线等用 2D 描边后上传）。 */
  R.layer2d = function (canvas2d) {
    const T = R._targets;
    const L = R._layer;
    gl.bindTexture(gl.TEXTURE_2D, L.t);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas2d);
    const pr = progs.blit;
    use(pr, [T.lit.w, T.lit.h], 0, [0, 0, T.lit.w, T.lit.h]);
    bindTex(pr, "u_tex", 0, L.t);
    draw();
  };

  /**
   * 一帧结束：切暗 → 金字塔 → 合成到屏幕。glow：{amt, far, farRepeat, wide, near}（与 app.js GLOW 同义）；
   * spill 为真时额外算到 1/16 级并读回（返回 {w, h, data}，data 为 RGBA 字节、r = 透明度、顶行在前），否则返回 null。
   */
  R.end = function ({ amt, far, farRepeat, wide, near, glass = true, spill = false }) {
    const T = R._targets;
    gl.disable(gl.BLEND);
    // 切暗
    target(T.litC.fb, T.litC.w, T.litC.h);
    let pr = progs.carve;
    use(pr, [T.litC.w, T.litC.h], 0, [0, 0, T.litC.w, T.litC.h]);
    bindTex(pr, "u_tex", 0, T.lit.t);
    bindTex(pr, "u_mesh", 1, R._mesh.t);
    gl.uniform2f(pr.u.u_tile, R._mesh.w, R._mesh.h);
    gl.uniform1f(pr.u.u_carve, R._mesh.carve);
    draw();
    // 金字塔（透明度）
    const needPyramid = amt > 0 || spill;
    if (needPyramid) {
      pr = progs.down;
      const chain = [[T.litC, T.s2, 1], [T.s2, T.s4, 0], [T.s4, T.s8, 0]];
      if (spill) chain.push([T.s8, T.s16, 0]);
      for (const [src, dst, fromAlpha] of chain) {
        target(dst.fb, dst.w, dst.h);
        use(pr, [dst.w, dst.h], 0, [0, 0, dst.w, dst.h]);
        bindTex(pr, "u_tex", 0, src.t);
        gl.uniform1f(pr.u.u_fromAlpha, fromAlpha);
        draw();
      }
    }
    let spillOut = null;
    if (spill) {
      const s = T.s16;
      const n = s.w * s.h * 4;
      if (!R._spillBuf || R._spillBuf.length !== n) {
        R._spillBuf = new Uint8Array(n);
        R._spillReady = null;
      }
      target(s.fb, s.w, s.h);
      if (gl2) {
        // 上一帧发起的读回若已完成就取走（晚一帧的溢光看不出来），再发起这一帧的
        if (R._spillSync) {
          const st = gl.clientWaitSync(R._spillSync, 0, 0);
          if (st === gl.ALREADY_SIGNALED || st === gl.CONDITION_SATISFIED) {
            gl.bindBuffer(gl.PIXEL_PACK_BUFFER, R._spillPbo);
            gl.getBufferSubData(gl.PIXEL_PACK_BUFFER, 0, R._spillBuf);
            gl.bindBuffer(gl.PIXEL_PACK_BUFFER, null);
            gl.deleteSync(R._spillSync);
            R._spillSync = null;
            R._spillReady = { w: s.w, h: s.h, data: R._spillBuf };
          }
        }
        if (!R._spillSync) {
          if (!R._spillPbo) R._spillPbo = gl.createBuffer();
          gl.bindBuffer(gl.PIXEL_PACK_BUFFER, R._spillPbo);
          gl.bufferData(gl.PIXEL_PACK_BUFFER, n, gl.STREAM_READ);
          gl.readPixels(0, 0, s.w, s.h, gl.RGBA, gl.UNSIGNED_BYTE, 0);
          gl.bindBuffer(gl.PIXEL_PACK_BUFFER, null);
          R._spillSync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        }
        spillOut = R._spillReady;
      } else {
        gl.readPixels(0, 0, s.w, s.h, gl.RGBA, gl.UNSIGNED_BYTE, R._spillBuf);
        spillOut = { w: s.w, h: s.h, data: R._spillBuf };
      }
    }
    // 合成到屏幕
    target(null, R.W, R.H);
    pr = progs.compose;
    use(pr, [R.W, R.H], 1, [0, 0, R.W, R.H]);
    bindTex(pr, "u_static", 0, R._static.t);
    bindTex(pr, "u_lit", 1, T.litC.t);
    bindTex(pr, "u_s2", 2, T.s2.t);
    bindTex(pr, "u_s4", 3, T.s4.t);
    bindTex(pr, "u_s8", 4, T.s8.t);
    gl.uniform3fv(pr.u.u_tint, R.colors.tint);
    const on = amt > 0;
    gl.uniform1f(pr.u.u_far, on ? Math.min(1, far * amt) : 0);
    gl.uniform1f(pr.u.u_farRepeat, farRepeat + (amt > 1.3 ? 1 : 0));
    gl.uniform1f(pr.u.u_wide, on ? Math.min(1, wide * amt) : 0);
    gl.uniform1f(pr.u.u_near, on ? Math.min(1, near * amt) : 0);
    gl.uniform1f(pr.u.u_glass, glass ? 1 : 0);
    gl.uniform1f(pr.u.u_dpr, R.dpr);
    draw();
    return spillOut;
  };

  /** 读屏幕像素（画布坐标，y 向下；返回 RGBA 字节，顶行在前）。需要 preserve 才能在帧外读。 */
  R.readPixels = function (x, y, w, h) {
    const buf = new Uint8Array(w * h * 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.readPixels(x, R.H - y - h, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
    const out = new Uint8ClampedArray(w * h * 4);
    for (let r = 0; r < h; r++) out.set(buf.subarray((h - 1 - r) * w * 4, (h - r) * w * 4), r * w * 4);
    return out;
  };

  R.destroy = function () {
    const ext = gl.getExtension("WEBGL_lose_context");
    if (ext) ext.loseContext();
  };
  return R;
}

// ---------------------------------------------------------------- 溢光（边框环）渲染器
// 边框上的光斑：把显示屏发光层最模糊的那级（1/16）放大一圈画到黑色边框上，只画边框环（玻璃区域挖空）。
// 与 app.js spill() 的 2D 版逐步对应：两次放大（m = 0.75b 与 2m）、不透明度 0.9·amt 与 0.5·amt、source-over 叠加。
const FS_SPILL = `
precision highp float;
uniform vec2 u_size;
uniform sampler2D u_tex;
uniform vec3 u_tint;
uniform vec4 u_glass;   // 玻璃区域 x0, y0, x1, y1（挖空）
uniform vec4 u_rect1, u_rect2; // 两次放大的目标矩形 x, y, w, h
uniform float u_a1, u_a2;
vec4 layer(vec2 P, vec4 r, float a) {
  vec2 uv = (P - r.xy) / r.zw;
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec4(0.0);
  float s = texture2D(u_tex, uv).r * a;
  return vec4(u_tint * s, s);
}
void main() {
  vec2 P = vec2(gl_FragCoord.x, u_size.y - gl_FragCoord.y);
  if (P.x >= u_glass.x && P.x < u_glass.z && P.y >= u_glass.y && P.y < u_glass.w) discard;
  vec4 o = layer(P, u_rect1, u_a1);
  vec4 c = layer(P, u_rect2, u_a2);
  o = c + o * (1.0 - c.a);
  if (o.a <= 0.0) discard;
  gl_FragColor = o;
}`;

/** 边框溢光画布的 WebGL 渲染器；拿不到上下文返回 null（页面退回 2D 的 spill()）。 */
export function createSpillGl(canvas, opts = {}) {
  let gl = null;
  try {
    const sa = { alpha: true, antialias: false, depth: false, stencil: false, premultipliedAlpha: true, preserveDrawingBuffer: !!opts.preserve };
    gl = getGlContext(canvas, "webgl2", sa) || getGlContext(canvas, "webgl", sa);
  } catch (_) {
    gl = null;
  }
  if (!gl) return null;
  if (opts.p3 && "drawingBufferColorSpace" in gl) {
    try {
      gl.drawingBufferColorSpace = "display-p3";
    } catch (_) {
      /* 按 sRGB */
    }
  }
  const pr = program(gl, FS_SPILL);
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  let tw = 0, th = 0;
  let lost = false;
  const api = {
    get lost() { return lost; },
    onRestored: null,
    /** 清空（溢光关或没有数据时）。 */
    clear(W, H) {
      gl.viewport(0, 0, W, H);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    },
    /**
     * 画一帧。src：{w, h, data}（RGBA 字节，r = 透明度，顶行在前）；b = 边框宽（像素）；gw/gh = 玻璃区尺寸；
     * amt = 溢光强度；tint = 磷光色（0–1）。
     */
    draw(W, H, src, { b, gw, gh, amt, tint }) {
      gl.viewport(0, 0, W, H);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
      if (tw !== src.w || th !== src.h) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, src.w, src.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, src.data);
        tw = src.w;
        th = src.h;
      } else {
        gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, src.w, src.h, gl.RGBA, gl.UNSIGNED_BYTE, src.data);
      }
      gl.useProgram(pr.p);
      gl.uniform4f(pr.u.u_rect, 0, 0, W, H);
      gl.uniform2f(pr.u.u_size, W, H);
      gl.uniform1f(pr.u.u_flip, 1);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.uniform1i(pr.u.u_tex, 0);
      gl.uniform3fv(pr.u.u_tint, tint);
      gl.uniform4f(pr.u.u_glass, b, b, b + gw, b + gh);
      const m = b * 0.75;
      gl.uniform4f(pr.u.u_rect1, b - m, b - m, gw + 2 * m, gh + 2 * m);
      gl.uniform4f(pr.u.u_rect2, b - 2 * m, b - 2 * m, gw + 4 * m, gh + 4 * m);
      gl.uniform1f(pr.u.u_a1, Math.min(1, 0.9 * amt));
      gl.uniform1f(pr.u.u_a2, Math.min(1, 0.5 * amt));
      gl.disable(gl.BLEND);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    },
  };
  canvas.addEventListener("webglcontextlost", (e) => { e.preventDefault(); lost = true; });
  canvas.addEventListener("webglcontextrestored", () => { if (api.onRestored) api.onRestored(); });
  return api;
}
