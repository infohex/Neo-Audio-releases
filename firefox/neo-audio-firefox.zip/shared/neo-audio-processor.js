// Neo Audio — AudioWorkletProcessor（音频线程）。
//
// 职责：实例化 WASM 引擎、每个渲染量子调 na_process、处理参数消息、按约定频率把电平表 +
// 最新输出样本以 transferable ArrayBuffer 发给主线程（主线程用完后 recycle 回来复用，零拷贝、无 GC 压力）。
//
// 消息（主线程 → 这里）：
//   {type:'set', module, index, field, value}
//   {type:'get', id, module, index, field}           → 回 {type:'got', id, value, error}
//   {type:'enable', module, on}
//   {type:'getEnabled', id, module}                 → 回 {type:'got', id, value(0/1), error}
//   {type:'layout', module, freqs:Float32Array}
//   {type:'display', frames, intervalMs, idleSeconds, idleIntervalMs}
//                                                    显示数据配置（frames ≤ 8192）；idle* 见下
//   {type:'recycle', buffer:ArrayBuffer}             归还显示缓冲
//   {type:'clearClip'}
//   {type:'nnPort', port:MessagePort}                 虚拟舞台（阶段 4.5）：与分离 Worker 直连的端口；之后把待分离的跳攒成
//                                                    批（STAGE_BATCH 跳）发过去，收到的整块声部写回舞台模块
//   {type:'stageWorker', on, depth}                   舞台模块切到 Worker 模式（队列深度 depth 跳）/ 切回
//   {type:'stageDepth', depth}                        在线加深队列（只加不减）
//   {type:'stageStats', id}                           → 回 {type:'got', id, value:{sent, got, skipped, dropped, backlog, depth, port}}（诊断）
// 消息（这里 → 主线程）：
//   {type:'ready', sampleRate, latency}
//   {type:'display', buffer, frames}                 Float32Array 布局：[11 电平][frames L][frames R]
//   {type:'idle', on}                                进入/退出空闲
//   {type:'got', ...} / {type:'error', message}
//
// 空闲检测（BO 决策：门限 3 s）：输入连续 idleSeconds 全为 0（或输入端口没接东西）→ 空闲：
// 跳过 na_process、直接输出 0，显示数据降到每 idleIntervalMs 一次；一旦出现非零输入立即恢复。
// 进入空闲前的 3 s 里仍正常处理零信号，让限幅器延迟线与各滤波器状态衰减完；退出时不需要 reset。

import { instantiateSync, MAX_BLOCK, METER_COUNT, SCOPE_CAPACITY, ERR } from "./wasm-abi.js";

const MAX_POOL = 4;
const STAGE_BATCH = 8; // 攒够这么多跳（23 ms）才发给分离 Worker：分段分离的延时是秒级，少发消息更要紧

class NeoAudioProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const po = options.processorOptions || {};
    this.abi = null;
    this.displayFrames = 2048;
    this.blocksPerPost = Math.max(1, Math.round((0.033 * sampleRate) / MAX_BLOCK));
    this.blockCounter = 0;
    this.pool = [];
    this.metersScratch = new Float32Array(METER_COUNT);
    this.idleThresholdFrames = Math.round(3 * sampleRate);
    this.idleBlocksPerPost = Math.max(1, Math.round((0.5 * sampleRate) / MAX_BLOCK));
    this.silentFrames = 0;
    this.idle = false;
    this.nnPort = null; // 分离 Worker 的直连端口
    this.stageStats = { sent: 0, got: 0, skipped: 0, portErrors: 0 };
    this.stageDepth = 2;
    this.stageLastSent = -1; // 积压按序号算（已发最大序号 − 已回最大序号）
    this.stageLastGot = -1;
    this.stageBatch = new Float32Array(STAGE_BATCH * 256); // 攒着待发的跳 [跳][声道][128]
    this.stageBatchFirst = -1;
    this.stageBatchN = 0;
    this.port.onmessage = (e) => this.onMessage(e.data);
    try {
      // 主线程传来编译好的 Module，或（Firefox content script）原始字节 / 普通数组在这里同步编译
      const module = po.module || (po.bytes ? new WebAssembly.Module(po.bytes) : po.bytesArray ? new WebAssembly.Module(new Uint8Array(po.bytesArray)) : null);
      if (!module) throw new Error("processorOptions.module / bytes 缺失");
      this.abi = instantiateSync(module);
      const r = this.abi.init(sampleRate);
      if (r !== ERR.OK) throw new Error(`na_init 失败: ${r}`);
      this.port.postMessage({
        type: "ready",
        sampleRate,
        latency: this.abi.latencySamples(),
      });
    } catch (err) {
      this.abi = null;
      this.port.postMessage({ type: "error", message: String(err && err.message ? err.message : err) });
    }
  }

  onMessage(m) {
    if (!this.abi || !m) return;
    const abi = this.abi;
    switch (m.type) {
      case "set":
        abi.setParam(m.module, m.index, m.field, m.value);
        break;
      case "get": {
        const value = abi.getParam(m.module, m.index, m.field);
        const error = Number.isNaN(value) ? abi.lastError() : ERR.OK;
        this.port.postMessage({ type: "got", id: m.id, value, error });
        break;
      }
      case "enable":
        abi.setModuleEnabled(m.module, m.on);
        break;
      case "getEnabled": {
        const r = abi.moduleEnabled(m.module);
        this.port.postMessage({ type: "got", id: m.id, value: r < 0 ? NaN : r, error: r < 0 ? r : ERR.OK });
        break;
      }
      case "layout":
        abi.setLayout(m.module, m.freqs);
        break;
      case "display":
        if (m.frames) this.displayFrames = Math.min(SCOPE_CAPACITY, Math.max(128, m.frames | 0));
        if (m.intervalMs) {
          this.blocksPerPost = Math.max(1, Math.round((m.intervalMs / 1000) * sampleRate / MAX_BLOCK));
        }
        if (m.idleSeconds !== undefined) this.idleThresholdFrames = Math.max(0, Math.round(m.idleSeconds * sampleRate));
        if (m.idleIntervalMs) {
          this.idleBlocksPerPost = Math.max(1, Math.round((m.idleIntervalMs / 1000) * sampleRate / MAX_BLOCK));
        }
        // 帧数变了，旧缓冲尺寸不对，丢弃
        this.pool.length = 0;
        break;
      case "recycle":
        if (m.buffer instanceof ArrayBuffer && this.pool.length < MAX_POOL) {
          const need = (METER_COUNT + 2 * this.displayFrames) * 4;
          if (m.buffer.byteLength === need) this.pool.push(m.buffer);
        }
        break;
      case "clearClip":
        abi.clearClip();
        break;
      case "nnPort":
        if (abi.hasStage() && m.port) {
          m.port.onmessage = (e) => this.onStems(e.data);
          this.nnPort = m.port;
          this.stageLastSent = -1;
          this.stageLastGot = -1;
          this.stageBatchN = 0;
        } else if (!m.port) {
          this.nnPort = null;
        }
        break;
      case "stageWorker":
        this.stageDepth = m.depth === undefined ? 2 : m.depth | 0;
        if (abi.hasStage()) abi.stageSetWorker(!!m.on, this.stageDepth);
        if (m.on) {
          // 队列重置后跳序号从 0 起（换段长在线重设也走这里）：背压 / 积压计数从头来；并在跳的通道上发"新流"标记
          // （与跳同一条端口，顺序有保证），分离器看到它才把期望序号归零——不能靠它自己猜，否则序号从 0 重来会被当成旧跳丢掉
          this.stageLastSent = -1;
          this.stageLastGot = -1;
          this.stageBatchN = 0;
          if (this.nnPort) {
            try {
              this.nnPort.postMessage({ reset: true });
            } catch (_) {
              /* 端口失效：pumpStage 会处理 */
            }
          }
        } else this.nnPort = null;
        break;
      case "stageDepth":
        if (abi.hasStage() && (m.depth | 0) > this.stageDepth) {
          this.stageDepth = m.depth | 0;
          abi.stageSetDepth(this.stageDepth);
        }
        break;
      case "stageStats":
        this.port.postMessage({ type: "got", id: m.id, value: Object.assign({ dropped: abi.hasStage() ? abi.stageDropped() : 0, port: !!this.nnPort, backlog: this.stageLastGot < 0 ? 0 : this.stageLastSent - this.stageLastGot, depth: this.stageDepth }, this.stageStats), error: ERR.OK });
        break;
      default:
        break;
    }
  }

  /** Worker 送回的一块定稿声部：{index, hops, buf:[跳][声部 4][声道 2][128]} → 舞台模块（≤ 512 跳一次写）。绝不能抛。 */
  onStems(m) {
    if (!this.abi || !m || !m.buf || typeof m.index !== "number") return;
    try {
      const abi = this.abi;
      const hops = m.hops | 0;
      const per = 4 * 2 * 128;
      for (let off = 0; off < hops; off += 512) {
        const n = Math.min(512, hops - off);
        const view = abi.stageStemsBlock(n);
        if (!view) break;
        view.set(m.buf.subarray(off * per, (off + n) * per));
        abi.stagePutStemsRange(m.index + off, n);
      }
      const last = m.index + hops - 1;
      if (last > this.stageLastGot) this.stageLastGot = last;
      this.stageStats.got += hops;
    } catch (_) {
      /* 一块丢了就丢了，舞台模块用干混音顶上 */
    }
  }

  /** 把舞台模块攒好的待分离跳攒成批发给 Worker（Worker 模式下才有）。绝不能抛。 */
  pumpStage() {
    const abi = this.abi;
    const port = this.nnPort;
    if (!port) return;
    try {
      for (let guard = 0; guard < 8; guard++) {
        const index = abi.stageTakeHop();
        if (index < 0) break;
        // 背压：Worker 跟不上（机器被占满）时积压会无限增长、回来的声部全是过期的；积压超过队列深度就不发了，
        // Worker 看到序号断档会从新位置重来，舞台模块这几跳走淡化 / 干混音
        const backlog = this.stageLastGot < 0 ? 0 : index - this.stageLastGot;
        if (backlog > this.stageDepth + 64) {
          this.stageStats.skipped++;
          this.stageBatchN = 0;
          continue;
        }
        // 序号不连续（上面跳过了）→ 先把攒着的发掉
        if (this.stageBatchN > 0 && this.stageBatchFirst + this.stageBatchN !== index) this.flushStage(port);
        if (this.stageBatchN === 0) this.stageBatchFirst = index;
        const o = this.stageBatchN * 256;
        this.stageBatch.set(abi.stageHopView(0), o);
        this.stageBatch.set(abi.stageHopView(1), o + 128);
        this.stageBatchN++;
        this.stageLastSent = index;
        if (this.stageBatchN === STAGE_BATCH) this.flushStage(port);
      }
    } catch (_) {
      /* 端口失效：停发，舞台模块回退到干混音 */
      this.stageStats.portErrors++;
      this.nnPort = null;
    }
  }

  flushStage(port) {
    const n = this.stageBatchN;
    if (n <= 0) return;
    const buf = this.stageBatch.slice(0, n * 256);
    port.postMessage({ index: this.stageBatchFirst, hops: n, buf }, [buf.buffer]);
    this.stageStats.sent += n;
    this.stageBatchN = 0;
  }

  postDisplay() {
    const frames = this.displayFrames;
    const need = (METER_COUNT + 2 * frames) * 4;
    let buffer = this.pool.pop();
    if (!buffer || buffer.byteLength !== need) buffer = new ArrayBuffer(need);
    const view = new Float32Array(buffer);
    this.abi.meters(this.metersScratch);
    if (this.idle) {
      // 空闲时引擎不再更新电平表：电平读数置底，削波标志/自动增益/延迟保留
      for (const i of [0, 1, 2, 3, 6, 7]) this.metersScratch[i] = -100;
      this.metersScratch[8] = 0;
    }
    view.set(this.metersScratch, 0);
    const l = view.subarray(METER_COUNT, METER_COUNT + frames);
    const r = view.subarray(METER_COUNT + frames, METER_COUNT + 2 * frames);
    this.abi.scopeCopy(frames, l, r);
    // 转移所有权发出去；某些环境（Firefox 的扩展沙箱上下文）转移会失败 → 退回拷贝发送；再失败就停发并报告，
    // 绝不能让 process() 里抛异常（处理器会被判死、整条链静音）
    try {
      this.port.postMessage({ type: "display", buffer, frames }, [buffer]);
    } catch (e1) {
      try {
        this.port.postMessage({ type: "display", buffer, frames });
        this.noTransfer = true;
      } catch (e2) {
        this.displayDisabled = true;
        this.port.postMessage({ type: "error", message: `显示数据发不出去: ${e2.message}` });
      }
    }
  }

  process(inputs, outputs) {
    const output = outputs[0];
    if (!output || output.length === 0) return true;
    const outL = output[0];
    const outR = output.length > 1 ? output[1] : null;
    const total = outL.length;
    const input = inputs[0] || [];
    const inL = input[0] || null;
    const inR = input.length > 1 ? input[1] : inL;

    if (!this.abi) {
      // 引擎没起来：直通，至少不让页面静音
      if (inL) outL.set(inL);
      if (outR && inR) outR.set(inR);
      return true;
    }

    // 空闲检测：输入全 0 累计帧数
    let silent = true;
    if (inL) {
      for (let i = 0; i < total; i++) {
        if (inL[i] !== 0 || inR[i] !== 0) {
          silent = false;
          break;
        }
      }
    }
    if (silent) {
      if (this.silentFrames < this.idleThresholdFrames) this.silentFrames += total;
      if (!this.idle && this.silentFrames >= this.idleThresholdFrames) {
        this.idle = true;
        this.blockCounter = 0;
        this.port.postMessage({ type: "idle", on: true });
      }
    } else {
      this.silentFrames = 0;
      if (this.idle) {
        this.idle = false;
        this.port.postMessage({ type: "idle", on: false });
      }
    }
    if (this.idle) {
      outL.fill(0);
      if (outR) outR.fill(0);
      if (++this.blockCounter >= this.idleBlocksPerPost) {
        this.blockCounter = 0;
        if (!this.displayDisabled) this.postDisplay();
      }
      return true;
    }

    let offset = 0;
    while (offset < total) {
      const n = Math.min(MAX_BLOCK, total - offset);
      const bufL = this.abi.inputView(0, n);
      const bufR = this.abi.inputView(1, n);
      if (inL) {
        bufL.set(inL.subarray(offset, offset + n));
        bufR.set(inR.subarray(offset, offset + n));
      } else {
        bufL.fill(0);
        bufR.fill(0);
      }
      this.abi.process(n);
      outL.set(this.abi.outputView(0, n), offset);
      if (outR) outR.set(this.abi.outputView(1, n), offset);
      offset += n;
    }
    if (this.nnPort) this.pumpStage();

    if (++this.blockCounter >= this.blocksPerPost) {
      this.blockCounter = 0;
      if (!this.displayDisabled) this.postDisplay();
    }
    return true;
  }
}

registerProcessor("neo-audio-processor", NeoAudioProcessor);
