// Neo Audio — WASM ABI v2 的 JS 封装（主线程与 AudioWorklet 共用）。
//
// 只依赖导出的 C ABI（na_* 函数）与线性内存，不用 wasm-bindgen 胶水，
// 所以在 Safari 的 AudioWorkletGlobalScope（没有 TextDecoder）里也能跑。
//
// 内存视图不能缓存：na_init / na_analyzer_init / na_set_layout 可能触发 memory.grow，
// 旧的 Float32Array 会失效。所以每次访问都通过 view()/f32() 重新建视图（代价极小）。

export const ABI_VERSION = 2;

export const ERR = Object.freeze({
  OK: 0,
  NOT_INITIALIZED: -1,
  SAMPLE_RATE: -2,
  TOO_MANY_FRAMES: -3,
  OUT_OF_RANGE: -4,
  READ_ONLY: -5,
  BAD_VALUE: -6,
  ANALYZER: -7,
  BAD_MODULE: -8,
  BAD_INDEX: -9,
  BAD_FIELD: -10,
});

export const MODULE = Object.freeze({
  // 0 曾是"全局频率范围"，已从内核去掉（BO 决策 2026-10-04）；编号保留不复用
  NOTCH: 1,
  EQ: 2,
  BASS: 3,
  EXCITER: 4,
  OUTPUT: 5,
  TRUEBASS: 6, // 阶段 2.2 新增（ABI v2 追加模块，旧编号不变）
  REVERSE: 7, // 阶段 2.4 新增：分块倒放
  TREBLE: 8, // 阶段 2.5 新增：TrueTreble 高频提升
  REVERB: 9, // 阶段 2.7 新增：混响（Dattorro 板式 + I3DL2 外壳）
  SURROUND: 10, // 阶段 2.8 新增：虚拟环绕（上混 5.1 → 六路增益 → HRTF/矩阵回两声道）
  DISPLAY: 11, // 阶段 2.9 新增：显示灯板设置（不在音频链上；由 UI 线程实例的引擎保管，灯板每帧取用）
  WIDTH: 12, // 阶段 2.10 新增（2026-10-14）："3D" 立体声宽度（中/侧宽度 + 低频单声道分频；链上在混响之后、虚拟环绕之前）
  STAGE: 13, // 阶段 4.2 新增（2026-10-15）：虚拟舞台（神经网络分离声部 → 舞台摆位 → HRTF / 矩阵渲染；与虚拟环绕互斥）
});

// 字段号与 crates/dsp-core/src/params.rs 一致（已发布，不再改动）。
export const FIELD = Object.freeze({
  NOTCH_FREQ: 0,
  NOTCH_Q: 1,
  NOTCH_DEPTH: 2,
  NOTCH_ENABLED: 3,
  NOTCH_IN_RANGE: 4,
  NOTCH_ACTIVE: 5,
  EQ_GAIN: 0,
  EQ_Q: 1,
  EQ_FREQ: 2,
  EQ_FILTER_DB: 3,
  EQ_IN_RANGE: 4,
  EQ_COMPENSATION: 100,
  HARM_FREQ: 0,
  HARM_BOOST: 1,
  HARM_ENABLED: 2,
  HARM_IN_RANGE: 3,
  HARM_ACTIVE: 4,
  HARM_HAS_HARMONICS: 5,
  OUT_MANUAL_GAIN: 100,
  OUT_AUTO_ENABLED: 101,
  OUT_AUTO_AMOUNT: 102,
  OUT_AUTO_LIMIT: 103,
  OUT_LIMITER_ENABLED: 104,
  OUT_THRESHOLD: 105,
  OUT_RELEASE: 106,
  OUT_AUTO_GAIN_DB: 107,
  OUT_GAIN_REDUCTION_DB: 108,
  OUT_LATENCY_SAMPLES: 109,
  OUT_TRIM_L: 110, // 耳机平衡：左/右增益微调、左/右高频微调（±6 dB）
  OUT_TRIM_R: 111,
  OUT_HF_TRIM_L: 112,
  OUT_HF_TRIM_R: 113,
  TB_FREQ: 100,
  TB_GAIN: 101,
  TB_IN_RANGE: 102,
  TB_ACTIVE: 103,
  RV_BLOCK_MS: 100,
  RV_BLOCK_FRAMES: 101,
  RV_MIX: 102,
  TR_FREQ: 100,
  TR_GAIN: 101,
  TR_EFF_FREQ: 102,
  TR_ACTIVE: 103,
  W_WIDTH: 100, // 3D：宽度（0 单声道 / 1 原样 / ≤ 5）
  W_XOVER: 101, // 3D：低频分频点（Hz），以下只收窄不展宽
  W_ACTIVE: 102, // 3D（只读）：宽度 ≠ 1
  W_HF: 103, // 3D：高频起点（Hz），以上全额展宽
  W_MID: 104, // 3D：中频参与度（0–1）
  RB_PRESET: 100,
  RB_ROOM: 101,
  RB_ROOM_HF: 102,
  RB_DECAY: 103,
  RB_DECAY_HF_RATIO: 104,
  RB_REFLECTIONS: 105,
  RB_REFLECTIONS_DELAY: 106,
  RB_REVERB: 107,
  RB_REVERB_DELAY: 108,
  RB_DIFFUSION: 109,
  RB_DENSITY: 110,
  RB_HF_REFERENCE: 111,
  SR_MODE: 100,
  SR_GAIN_FL: 101,
  SR_GAIN_FR: 102,
  SR_GAIN_C: 103,
  SR_GAIN_LFE: 104,
  SR_GAIN_LS: 105,
  SR_GAIN_RS: 106,
  SR_STEER: 107,
  SR_FRONT_KEEP: 108, // 前方保留（原"中置扩散"的编号沿用）
  SR_SURROUND_DELAY: 109,
  SR_SURROUND_LPF: 110,
  SR_LFE_XOVER: 111,
  SR_SURROUND_ANGLE: 112,
  SR_ROOM: 113,
  SR_TIMBRE: 114,
  SR_DOM_LR: 115,
  SR_DOM_CS: 116,
  SR_DELAY_SAMPLES: 117,
  SR_CENTER_HPF: 118, // 中置下限（Hz）
  SR_SURROUND_WRAP: 119, // 环绕包裹（0–1）
  SR_MUTE_FL: 120, // 六路静音开关（增益值保留）
  SR_MUTE_FR: 121,
  SR_MUTE_C: 122,
  SR_MUTE_LFE: 123,
  SR_MUTE_LS: 124,
  SR_MUTE_RS: 125,
  // 模块 11 Display（阶段 2.9）：显示设置也走参数表（BO 决策 2026-10-05）
  DP_GAMMA: 100, // 刻度曲率 γ 1…3（1 = 线性，默认 2 = "非线性"）
  DP_AFTERGLOW_MS: 101, // 余晖 ms 0…300（0 = 关）
  DP_PEAK_DECAY: 102, // 峰值保持点回落 dB/s 0…60
  DP_OVER_HOLD_MS: 103, // 削波后 OVER 保持 ms 0…5000
  DP_SCOPE_WINDOW: 104, // 示波器窗长 样本 384…8192（对数）
  // 模块 13 虚拟舞台（阶段 4.2）：序号 = 元素；0–6 元素字段，100+ 模块级
  ST_GAIN: 0,
  ST_MUTE: 1,
  ST_AZIMUTH: 2, // 度：0 正前方，正角为右侧，±180 正后方
  ST_DISTANCE: 3, // 0…1
  ST_WIDTH: 4, // 度：声部左右声道落在方位 ∓ 宽度/2
  ST_KIND: 5, // 只读：0 鼓 1 贝斯 2 人声 3 其它
  ST_ORDINAL: 6, // 只读：同类里的序号
  ST_MODE: 100, // 0 耳机 1 音箱
  ST_ROOM: 101,
  ST_DIST_ATTEN: 102,
  ST_LATENCY: 103, // 只读：样本
  ST_FEEDING: 104, // 只读：最近一跳用的是声部（1）还是回退的干混音（0）
  ST_COUNT: 105, // 只读：元素数
  ST_REAR: 106, // 后方强调 0…1（耳机模式：身后的源高频再暗、电平再低、房间送入更多）
  ST_DROPPED: 107, // 只读：丢弃 / 迟到的声部跳数（累计）
  ST_DEVICE: 108, // 分离用的计算设备 0 GPU / 1 CPU（引擎只保管，宿主读它来起 Worker）
  ST_SEGMENT: 109, // 分离段长 ms 500…1500，默认 500（越长音质越好、延时越大；面板上叫「音质」）
});

/** 虚拟舞台元素种类（ST_KIND 的值 → i18n 键后缀）。 */
export const STAGE_KINDS = Object.freeze(["drums", "bass", "vocals", "other"]);

/** 虚拟环绕：六路增益字段与对应的静音字段（顺序 FL、FR、C、LFE、Ls、Rs）。 */
export const SURROUND_GAIN_FIELDS = Object.freeze([101, 102, 103, 104, 105, 106]);
export const SURROUND_MUTE_FIELDS = Object.freeze([120, 121, 122, 123, 124, 125]);

/** 输出级耳机平衡的四个字段（顺序：左增益、右增益、左高频、右高频）。 */
export const OUTPUT_BALANCE_FIELDS = Object.freeze([110, 111, 112, 113]);

/** 虚拟环绕：LFE 分频点三档（Hz，内核吸附到最近一档）。 */
export const SURROUND_LFE_XOVER_CHOICES = Object.freeze([60, 90, 120]);

/** 混响预设名（下标 = RB_PRESET 值；与 crates/dsp-core/src/modules/reverb.rs 的 PRESETS 同序；29 = 自定义）。 */
export const REVERB_PRESETS = Object.freeze([
  "Generic", "Padded Cell", "Room", "Bathroom", "Living Room", "Stone Room", "Auditorium", "Concert Hall", "Cave", "Arena",
  "Hangar", "Carpeted Hallway", "Hallway", "Stone Corridor", "Alley", "Forest", "City", "Mountains", "Quarry", "Plain",
  "Parking Lot", "Sewer Pipe", "Underwater", "Small Room", "Medium Room", "Large Room", "Medium Hall", "Large Hall", "Plate",
]);
export const REVERB_PRESET_CUSTOM = REVERB_PRESETS.length;

export const SCALE = Object.freeze({ LINEAR: 0, LOG: 1, DB: 2 });
export const UNIT = Object.freeze({
  NONE: 0,
  HZ: 1,
  DB: 2,
  Q: 3,
  MS: 4,
  PERCENT: 5,
  BOOL: 6,
  SAMPLES: 7,
});

// 电平表快照下标（与 dsp-core engine::meter_index 一致）。
export const METER = Object.freeze({
  PEAK_L: 0,
  PEAK_R: 1,
  RMS_L: 2,
  RMS_R: 3,
  CLIP_L: 4,
  CLIP_R: 5,
  BLOCK_PEAK_L: 6,
  BLOCK_PEAK_R: 7,
  GAIN_REDUCTION: 8,
  AUTO_GAIN: 9,
  LATENCY: 10,
});
export const METER_COUNT = 11;
export const INFO_LEN = 6;
export const BAR_COUNT = 31;
export const MAX_BLOCK = 128;
export const SCOPE_CAPACITY = 8192;
export const ANALYSIS_INPUT_CAPACITY = 16384;
export const WAVE_MAX_COLUMNS = 2048;
export const LAYOUT_CAPACITY = 32;
/** 显示灯板尺寸（与 dsp-core display.rs 一致；运行时再用 na_display_dims 核对）。 */
export const LAMP = Object.freeze({
  BARS: 33, // 31 根频谱柱 + L + R 电平柱
  ROWS: 72,
  WAVE_COLS: 384,
  WAVE_ROWS: 72,
  CURVE_HISTORY: 16,
  MAX_TICKS: 8,
  TICKS_LEN: 2 + 4 * 8, // [柱档数, 电平档数, 柱档行×8, 柱档值×8, 电平档行×8, 电平档值×8]
  INFO_STRIDE: 4, // 每柱 rows, peakRow(−1 无), over, inactive
});

/** 同步实例化（worklet 内用；模块已在主线程编译好）。 */
export function instantiateSync(module) {
  const instance = new WebAssembly.Instance(module, {});
  return new NeoAbi(instance);
}

/** 异步实例化（主线程用）。 */
export async function instantiate(module) {
  const instance = await WebAssembly.instantiate(module, {});
  return new NeoAbi(instance);
}

export class NeoAbi {
  constructor(instance) {
    this.x = instance.exports;
    if (typeof this.x.na_abi_version !== "function") {
      throw new Error("Neo Audio: wasm 没有导出 na_abi_version，文件不对");
    }
    const v = this.x.na_abi_version();
    if (v !== ABI_VERSION) {
      throw new Error(`Neo Audio: ABI 版本不匹配，wasm=${v}，JS=${ABI_VERSION}`);
    }
    this.memory = this.x.memory;
  }

  /** 以 f32 视图访问线性内存的一段（每次重建，避免 memory.grow 后失效）。 */
  f32(ptr, len) {
    return new Float32Array(this.memory.buffer, ptr, len);
  }

  // ---- 引擎 ----
  init(sampleRate) {
    return this.x.na_init(sampleRate);
  }
  setSampleRate(fs) {
    return this.x.na_set_sample_rate(fs);
  }
  destroy() {
    this.x.na_destroy();
  }
  maxBlock() {
    return this.x.na_max_block();
  }
  latencySamples() {
    return this.x.na_latency_samples();
  }
  inputView(ch, frames) {
    return this.f32(this.x.na_input_ptr(ch), frames);
  }
  outputView(ch, frames) {
    return this.f32(this.x.na_output_ptr(ch), frames);
  }
  process(frames) {
    return this.x.na_process(frames);
  }

  // ---- 神经分离（na_nn_*，阶段 4.1）与虚拟舞台的分离通道（na_stage_*，阶段 4.2）；旧 wasm / 桩没有这些导出 ----
  hasNn() {
    return typeof this.x.na_nn_load === "function";
  }
  hasStage() {
    return typeof this.x.na_stage_take_hop === "function";
  }
  /** 申请权重缓冲区并返回它的 u8 视图（拷完立刻 nnLoad，不要跨 memory.grow 保留视图）。 */
  nnWeightsAlloc(len) {
    const ptr = this.x.na_nn_weights_alloc(len);
    return ptr ? new Uint8Array(this.memory.buffer, ptr, len) : null;
  }
  nnLoad() {
    return this.x.na_nn_load();
  }
  nnUnload() {
    this.x.na_nn_unload();
  }
  nnLoaded() {
    return this.x.na_nn_loaded() !== 0;
  }
  nnInputView(ch) {
    return this.f32(this.x.na_nn_input_ptr(ch), 128);
  }
  nnOutputView(stem, ch) {
    return this.f32(this.x.na_nn_output_ptr(stem, ch), 128);
  }
  nnHop() {
    return this.x.na_nn_hop();
  }
  /** 只推进一个模型（0 鼓 / 1 贝斯 / 2 人声）。 */
  nnHopSource(source) {
    return this.x.na_nn_hop_source(source);
  }
  nnReset() {
    this.x.na_nn_reset();
  }
  /** 取一跳待分离的输入：返回跳序号，没有返回 -1；数据在 stageHopView(ch)。 */
  stageTakeHop() {
    const i = this.x.na_stage_take_hop();
    return i === 0xffffffff ? -1 : i;
  }
  stageHopView(ch) {
    return this.f32(this.x.na_stage_hop_ptr(ch), 128);
  }
  stageStemsView(stem, ch) {
    return this.f32(this.x.na_stage_stems_ptr(stem, ch), 128);
  }
  stagePutStems(index) {
    return this.x.na_stage_put_stems(index >>> 0);
  }
  /** 多跳写回的缓冲区视图：hops 跳 × [声部 4][声道 2][128]（≤ 512 跳；拷完立刻 stagePutStemsRange，不要跨 memory.grow 保留视图）。 */
  stageStemsBlock(hops) {
    const p = this.x.na_stage_stems_block_ptr(hops);
    return p ? this.f32(p, hops * 4 * 2 * 128) : null;
  }
  stagePutStemsRange(index, hops) {
    return this.x.na_stage_put_stems_range(index >>> 0, hops);
  }
  stageSetWorker(on, depth) {
    return this.x.na_stage_set_worker(on ? 1 : 0, depth);
  }
  /** 在线加深队列（只能加深，不清状态）。旧 wasm 没有此导出时退回 stageSetWorker。 */
  stageSetDepth(depth) {
    return typeof this.x.na_stage_set_depth === "function" ? this.x.na_stage_set_depth(depth) : this.x.na_stage_set_worker(1, depth);
  }
  stageDropped() {
    return this.x.na_stage_dropped();
  }

  // ---- 参数表 ----
  moduleCount() {
    return this.x.na_module_count();
  }
  fieldCount(module) {
    return this.x.na_field_count(module);
  }
  fieldId(module, n) {
    return this.x.na_field_id(module, n);
  }
  indexCount(module) {
    return this.x.na_index_count(module);
  }
  /** 返回 {min, max, default, scale, unit, readOnly} 或 null。不需要引擎已初始化。 */
  paramInfo(module, field) {
    if (this.x.na_param_info(module, field) !== ERR.OK) return null;
    const v = this.f32(this.x.na_info_ptr(), INFO_LEN);
    return {
      min: v[0],
      max: v[1],
      default: v[2],
      scale: v[3] | 0,
      unit: v[4] | 0,
      readOnly: v[5] !== 0,
    };
  }
  setParam(module, index, field, value) {
    return this.x.na_set_param(module, index, field, value);
  }
  /** 返回值；出错返回 NaN，错误码在 lastError()。 */
  getParam(module, index, field) {
    return this.x.na_get_param(module, index, field);
  }
  lastError() {
    return this.x.na_last_error();
  }
  setModuleEnabled(module, on) {
    return this.x.na_set_module_enabled(module, on ? 1 : 0);
  }
  moduleEnabled(module) {
    return this.x.na_module_enabled(module);
  }
  setLayout(module, freqs) {
    if (freqs.length > LAYOUT_CAPACITY) return ERR.OUT_OF_RANGE;
    const buf = this.f32(this.x.na_layout_ptr(), LAYOUT_CAPACITY);
    buf.set(freqs);
    return this.x.na_set_layout(module, freqs.length);
  }

  // ---- 显示（音频线程） ----
  /** 刷新并把 11 个电平值写进 out（Float32Array，长度 ≥ 11）。 */
  meters(out) {
    const r = this.x.na_meters();
    if (r === ERR.OK) out.set(this.f32(this.x.na_meters_ptr(), METER_COUNT));
    return r;
  }
  clearClip() {
    this.x.na_clear_clip();
  }
  /** 把最新 frames 帧输出写进 outL/outR（长度 ≥ frames），返回有效帧数。 */
  scopeCopy(frames, outL, outR) {
    const n = this.x.na_scope_copy(frames);
    outL.set(this.f32(this.x.na_scope_ptr(0), frames));
    outR.set(this.f32(this.x.na_scope_ptr(1), frames));
    return n;
  }

  // ---- 分析器（UI 线程实例） ----
  analyzerInit(sampleRate, fftSize, curvePoints) {
    return this.x.na_analyzer_init(sampleRate, fftSize, curvePoints);
  }
  analyzerDestroy() {
    this.x.na_analyzer_destroy();
  }
  analyzerSetSampleRate(fs) {
    return this.x.na_analyzer_set_sample_rate(fs);
  }
  analyzerSetBallistics(attackMs, releaseMs) {
    return this.x.na_analyzer_set_ballistics(attackMs, releaseMs);
  }
  analyzerFftSize() {
    return this.x.na_analyzer_fft_size();
  }
  /** 把单声道样本写进分析输入缓冲区。 */
  analysisInput(samples) {
    const n = Math.min(samples.length, ANALYSIS_INPUT_CAPACITY);
    this.f32(this.x.na_analysis_input_ptr(), n).set(samples.subarray(0, n));
    return n;
  }
  analyze(frames, dtSeconds) {
    return this.x.na_analyze(frames, dtSeconds);
  }
  curvePoints() {
    return this.x.na_curve_points();
  }
  curveDb() {
    return this.f32(this.x.na_curve_ptr(), this.curvePoints());
  }
  curveFreq() {
    return this.f32(this.x.na_curve_freq_ptr(), this.curvePoints());
  }
  barsDb() {
    return this.f32(this.x.na_bars_ptr(), BAR_COUNT);
  }
  barFreq() {
    return this.f32(this.x.na_bar_freq_ptr(), BAR_COUNT);
  }
  barActive() {
    return this.f32(this.x.na_bar_active_ptr(), BAR_COUNT);
  }
  /** 波形抽取：返回 Float32Array（columns×2，min/max 交错）的视图。 */
  decimate(frames, columns) {
    const c = this.x.na_decimate(frames, columns);
    return this.f32(this.x.na_wave_ptr(), c * 2);
  }
  maxCurvePoints() {
    return this.x.na_max_curve_points();
  }

  // ---- 显示灯板（UI 线程实例；规则在内核，这里只搬数据） ----
  /** 核对灯板尺寸常量与 wasm 一致；不一致抛错（JS 画格子按这些常量分配）。 */
  displayCheckDims() {
    const want = [LAMP.BARS, LAMP.ROWS, LAMP.WAVE_COLS, LAMP.WAVE_ROWS, LAMP.CURVE_HISTORY, LAMP.MAX_TICKS];
    const got = want.map((_, i) => this.x.na_display_dims(i));
    if (got.some((v, i) => v !== want[i])) throw new Error(`Neo Audio: 灯板尺寸不一致 wasm=[${got}] JS=[${want}]`);
  }
  displayReset() {
    this.x.na_display_reset();
  }
  /** 输入：频谱柱 dB（31）、可用标志（31）、电平表（11）、曲线 dB（≤ maxCurvePoints）、示波器样本（每声道 ≤ 8192，最新在末尾）。 */
  displayBarsIn(barsDb, barActive) {
    this.f32(this.x.na_display_bars_in_ptr(), BAR_COUNT).set(barsDb.subarray(0, BAR_COUNT));
    this.f32(this.x.na_display_bar_active_in_ptr(), BAR_COUNT).set(barActive.subarray(0, BAR_COUNT));
  }
  displayMetersIn(meters) {
    this.f32(this.x.na_display_meters_ptr(), METER_COUNT).set(meters.subarray(0, METER_COUNT));
  }
  displayCurveIn(curveDb) {
    const n = Math.min(curveDb.length, this.maxCurvePoints());
    this.f32(this.x.na_display_curve_in_ptr(), n).set(curveDb.subarray(0, n));
    return n;
  }
  displayScopeIn(l, r) {
    const n = Math.min(l.length, r.length, SCOPE_CAPACITY);
    this.f32(this.x.na_display_scope_ptr(0), n).set(l.subarray(l.length - n));
    this.f32(this.x.na_display_scope_ptr(1), n).set(r.subarray(r.length - n));
    return n;
  }
  /** 每帧更新（dt 毫秒）。示波器样本不足一窗返回 ERR.BAD_VALUE，灯板保持上一帧。 */
  displayUpdateBars(dtMs) {
    return this.x.na_display_update_bars(dtMs);
  }
  displayUpdateScope(frames, dtMs) {
    return this.x.na_display_update_scope(frames, dtMs);
  }
  displayUpdateCurve(points, dtMs) {
    return this.x.na_display_update_curve(points, dtMs);
  }
  /** 输出视图（每次重建；只在下一次 update 前有效）。 */
  lampBars() {
    return this.f32(this.x.na_display_bars_ptr(), LAMP.BARS * LAMP.ROWS);
  }
  lampBarInfo() {
    return this.f32(this.x.na_display_bar_info_ptr(), LAMP.BARS * LAMP.INFO_STRIDE);
  }
  lampTicks() {
    return this.f32(this.x.na_display_ticks_ptr(), LAMP.TICKS_LEN);
  }
  lampScopeLit() {
    return this.f32(this.x.na_display_scope_lit_ptr(), LAMP.WAVE_COLS * LAMP.WAVE_ROWS);
  }
  lampScopeDim() {
    return this.f32(this.x.na_display_scope_dim_ptr(), LAMP.WAVE_COLS * LAMP.WAVE_ROWS);
  }
  /** [实际窗长, 触发起点]。 */
  lampScopeInfo() {
    return this.f32(this.x.na_display_scope_info_ptr(), 2);
  }
  lampCurve(points) {
    return this.f32(this.x.na_display_curve_ptr(), points);
  }
  /** 第 slot 槽的历史曲线（points 个高度）。 */
  lampCurveHist(slot, points) {
    return this.f32(this.x.na_display_curve_hist_ptr() + slot * this.maxCurvePoints() * 4, points);
  }
  lampCurveHistBr() {
    return this.f32(this.x.na_display_curve_hist_br_ptr(), LAMP.CURVE_HISTORY);
  }
}

/** 0..1 位置 → 实际值（按标度；与 dsp-core params::position_to_value 一致）。 */
export function positionToValue(info, pos) {
  const p = Math.min(1, Math.max(0, pos));
  if (info.scale === SCALE.LOG && info.min > 0 && info.max > info.min) {
    return info.min * Math.pow(info.max / info.min, p);
  }
  return info.min + (info.max - info.min) * p;
}

/** 实际值 → 0..1 位置。 */
export function valueToPosition(info, value) {
  const lo = Math.min(info.min, info.max);
  const hi = Math.max(info.min, info.max);
  const v = Math.min(hi, Math.max(lo, value));
  if (info.scale === SCALE.LOG && info.min > 0 && info.max > info.min) {
    return Math.log(v / info.min) / Math.log(info.max / info.min);
  }
  return info.max !== info.min ? (v - info.min) / (info.max - info.min) : 0;
}
