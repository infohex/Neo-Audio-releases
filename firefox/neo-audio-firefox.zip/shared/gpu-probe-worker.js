// 诊断用：这个 Worker 上下文里有没有 WebGPU 适配器（Firefox 的后台页 Worker 4.5b 要知道）
(async () => {
  const r = { gpu: !!self.navigator.gpu, adapter: null, sab: typeof SharedArrayBuffer !== "undefined" };
  try {
    const ad = self.navigator.gpu ? await self.navigator.gpu.requestAdapter({ powerPreference: "high-performance" }) : null;
    if (ad) {
      const info = ad.info || {};
      r.adapter = `${info.vendor || "?"} ${info.architecture || ""} ${info.description || ""}`.trim();
    }
  } catch (e) {
    r.error = e.message;
  }
  self.postMessage(r);
})();
