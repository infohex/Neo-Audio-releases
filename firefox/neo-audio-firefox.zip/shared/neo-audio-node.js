// Neo Audio — 主线程 API。
//
// 一个 NeoAudio 对象 = 一个 AudioWorkletNode（音频线程里的处理引擎）+ 主线程上的第二个 WASM 实例
// （读参数元数据、跑频谱分析与波形抽取、显示灯板）。显示数据由 worklet 以 transferable 缓冲区
// 送来，这里算完频谱后把缓冲区归还给 worklet 复用；页面随后调 feedLamp(d) 让内核算出哪些灯该亮
// （阶段 2.9：显示规则在内核，JS 只画）。主线程实例也 na_init 一个引擎，只用来保管模块 11（显示设置）。
//
// 用法：
//   const neo = await NeoAudio.create(ctx, { wasmUrl, workletUrl });
//   source.connect(neo.node); neo.node.connect(ctx.destination);
//   neo.setParam(MODULE.EQ, 5, FIELD.EQ_GAIN, 6);
//   neo.onDisplay = (d) => { /* d.meters, d.curveDb, d.barsDb, d.waveL ... */ };

import {
  instantiate,
  ERR,
  METER_COUNT,
  MODULE,
  FIELD,
  SCOPE_CAPACITY,
  WAVE_MAX_COLUMNS,
  LAMP,
} from "./wasm-abi.js";

export { MODULE, FIELD, ERR, SCALE, UNIT, METER, METER_COUNT, LAMP, REVERB_PRESETS, REVERB_PRESET_CUSTOM, SURROUND_LFE_XOVER_CHOICES, SURROUND_GAIN_FIELDS, SURROUND_MUTE_FIELDS, OUTPUT_BALANCE_FIELDS, positionToValue, valueToPosition } from "./wasm-abi.js";

/**
 * 内核灯板的薄包装（阶段 3.1 从 NeoAudio 里拆出来）：持有一个已 na_init 的 wasm 实例，
 * feedLamp(d) 写入一帧显示数据并跑三个 update，lamp.* 读亮度视图。
 * NeoAudio 自己也用它；插件里 UI 侧（content script / 独立窗口）单独建一个，引擎在别处。
 */
const moduleBytes = new WeakMap(); // WebAssembly.Module → 原始字节（loadModule 记下）

// Firefox 的 content script 跑在隔离沙箱里：沙箱对象（哪怕普通数组）传给 worklet / MessagePort 会抛
// "The object could not be cloned"；要先用 Firefox 提供的 cloneInto() 把对象造到页面那一侧。Chrome 没有这个函数，原样返回。
const IS_SANDBOX = typeof cloneInto === "function" && typeof window !== "undefined";
const toPage = IS_SANDBOX ? (o) => cloneInto(o, window) : (o) => o;
// 反方向：worklet 送来的 ArrayBuffer 在 Firefox 沙箱里是跨界对象，直接在它上面建视图能行，但之后的 subarray / from
// 会碰到 "Permission denied to access property constructor"。所以沙箱环境下先整块拷成沙箱自己的缓冲（每帧几十 KB），
// 后面所有切片都在本地做；这块缓冲也不再回收给 worklet（它每帧自己分配）
function viewOf(buffer) {
  if (!IS_SANDBOX) return new Float32Array(buffer);
  const u = new Uint8Array(buffer.byteLength);
  u.set(new Uint8Array(buffer));
  return new Float32Array(u.buffer);
}

export class NeoLamp {
  /** @param {import("./wasm-abi.js").NeoAbi} abi 已 init 的实例（模块 11 显示设置由它的引擎保管） */
  constructor(abi) {
    this.abi = abi;
    this._lampTime = 0;
    abi.displayCheckDims();
    this.lamp = {
      bars: () => abi.lampBars(),
      barInfo: () => abi.lampBarInfo(),
      ticks: () => abi.lampTicks(),
      scopeLit: () => abi.lampScopeLit(),
      scopeDim: () => abi.lampScopeDim(),
      scopeInfo: () => abi.lampScopeInfo(),
      curve: (points) => abi.lampCurve(points),
      curveHist: (slot, points) => abi.lampCurveHist(slot, points),
      curveHistBr: () => abi.lampCurveHistBr(),
    };
  }

  /**
   * 灯板喂数据（规则全在内核）：写入柱读数 / 可用标志 / 电平表 / 曲线 / 示波器样本，跑三个 update，
   * 之后用 this.lamp 读亮度。dt 由上一次 feedLamp 到现在的时间差给出（第一帧按 33 ms）。
   * 返回 {bars, scope, curve} 三个返回码（示波器样本不足一窗时 scope = ERR.BAD_VALUE，灯板保持上一帧）。
   */
  feedLamp(d) {
    const now = performance.now();
    const dtMs = this._lampTime ? Math.min(1000, now - this._lampTime) : 33;
    this._lampTime = now;
    const ui = this.abi;
    ui.displayBarsIn(d.barsDb, d.barActive);
    ui.displayMetersIn(d.meters);
    const bars = ui.displayUpdateBars(dtMs);
    const n = ui.displayScopeIn(d.scopeL, d.scopeR);
    const scope = ui.displayUpdateScope(n, dtMs);
    const points = ui.displayCurveIn(d.curveDb);
    const curve = ui.displayUpdateCurve(points, dtMs);
    return { bars, scope, curve, points };
  }

  /** 灯板清零（切换数据源 / 关闭显示屏时）。 */
  reset() {
    this._lampTime = 0;
    this.abi.displayReset();
  }
}

/**
 * 本地分离通道：就在这个上下文里起模块 Worker（测试页、Chrome 的 offscreen 宿主）。接口同插件里的远程通道
 * （content-boot.js 的 remoteHqTransport）：port 给 worklet 直连；init(cfg) 回 ready；onMessage 收 stat / error；terminate()。
 */
async function localHqTransport(o) {
  if (typeof Worker === "undefined") throw new Error("这个环境起不了分离 Worker");
  const model = o.hqModel ? await o.hqModel() : null;
  if (!model) {
    const e = new Error("分离模型还没下载");
    e.code = "nomodel";
    throw e;
  }
  const worker = new Worker(o.hqWorkerUrl, { type: "module" });
  const ch = new MessageChannel();
  const tr = {
    port: ch.port1,
    onMessage: null,
    init(cfg) {
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("分离 Worker 加载模型超时")), 600000);
        worker.onmessage = (e) => {
          const m = e.data || {};
          if (m.type === "ready") {
            clearTimeout(timer);
            worker.onmessage = (e2) => tr.onMessage && tr.onMessage(e2.data);
            resolve(m);
          } else if (m.type === "error") {
            clearTimeout(timer);
            reject(new Error(m.message));
          } else if (tr.onMessage) tr.onMessage(m);
        };
        worker.onerror = (e) => {
          clearTimeout(timer);
          const err = new Error(e && e.message ? e.message : "分离 Worker 脚本加载失败");
          if (tr.onMessage) tr.onMessage({ type: "error", message: err.message });
          reject(err);
        };
        // 模型字节转移给 Worker（宿主每次从缓存重新读，这里不留副本）
        worker.postMessage(Object.assign({ type: "init", model }, cfg), [model]);
        worker.postMessage({ type: "port", port: ch.port2 }, [ch.port2]);
      });
    },
    terminate() {
      try {
        worker.terminate();
      } catch (_) {
        /* 已停 */
      }
      ch.port2.close();
    },
    send(m) {
      worker.postMessage(m);
    },
  };
  return tr;
}

export class NeoAudio {
  /**
   * @param {AudioContext} ctx
   * @param {{wasmUrl:string, workletUrl:string, module?:WebAssembly.Module, fftSize?:number, curvePoints?:number, waveColumns?:number, displayIntervalMs?:number, idleSeconds?:number, idleIntervalMs?:number, hqWorkerUrl?:string, hqModel?:()=>Promise<ArrayBuffer|null>, hqThreads?:number, hqQueueDepth?:number}} opts
   *   hqWorkerUrl + hqModel：本地起分离 Worker（neo-hq-worker.js，模块 Worker；hqModel 取模型字节，没有 → 状态 nomodel）；
   *   hqTransport：插件里改用它——返回一个远程通道（Worker 在 offscreen / 后台页，经 runtime.Port 来回，见 content-boot.js）。
   *   第一次打开模块 13 时起；hqThreads：CPU 模式线程数；hqQueueDepth：测试用的固定队列深度。
   *   idleSeconds：输入连续静音多久后 worklet 进入空闲（跳过 DSP、输出 0）；idleIntervalMs：空闲时显示数据间隔；
   *   waveFrames：包络显示的时间窗（帧，≤ 8192；8192 @48k ≈ 170 ms），与 FFT 点数无关；
   *   scopeFrames：示波器用的原始样本尾段长度（帧），随 onDisplay 的 scopeL/scopeR 给出。
   */
  static async create(ctx, opts) {
    const o = Object.assign(
      { fftSize: 2048, curvePoints: 256, waveColumns: 512, waveFrames: 8192, scopeFrames: 2048, displayIntervalMs: 33, idleSeconds: 3, idleIntervalMs: 500 },
      opts
    );
    const module = o.module || (await NeoAudio.loadModule(o.wasmUrl));
    try {
      await ctx.audioWorklet.addModule(o.workletUrl);
    } catch (e) {
      throw new Error(`audioWorklet.addModule(${o.workletUrl}): ${e.message}`);
    }

    const self = new NeoAudio(ctx, module, o);
    await self._start();
    return self;
  }

  /** 取并编译 wasm（总是取最新：本地静态服务没有缓存头，浏览器会按启发式缓存旧产物）。原始字节记在 bytesOf() 里。 */
  static async loadModule(wasmUrl) {
    const resp = await fetch(wasmUrl, { cache: "no-store" });
    if (!resp.ok) throw new Error(`加载 wasm 失败: ${resp.status} ${wasmUrl}`);
    const bytes = await resp.arrayBuffer();
    const module = await WebAssembly.compile(bytes);
    moduleBytes.set(module, bytes);
    return module;
  }

  /** loadModule 编译时的原始字节（Firefox 的 content script 里 Module 不能克隆给 worklet，改传字节让 worklet 自己编译）。 */
  static bytesOf(module) {
    return moduleBytes.get(module) || null;
  }

  /**
   * 主线程上的"本地引擎"：同一个 wasm 的独立实例，只做 na_init 不处理音频，用来在 AudioContext
   * 建立之前（还没有用户手势/没选文件）读取参数元数据、默认值与模块开关默认状态，让 UI 先建起来。
   */
  static async localEngine(module, sampleRate = 48_000) {
    const abi = await instantiate(module);
    const r = abi.init(sampleRate);
    if (r !== ERR.OK) throw new Error(`本地引擎 na_init 失败: ${r}`);
    return abi;
  }

  constructor(ctx, module, o) {
    this.ctx = ctx;
    this.module = module;
    this.opts = o;
    this.node = null;
    this.ui = null;
    this.latency = 0;
    this.onDisplay = null;
    this.onError = null;
    /** worklet 空闲状态变化回调：(on: boolean) => void */
    this.onIdle = null;
    this.idle = false;
    this._pending = new Map();
    this._nextId = 1;
    this._lastDisplayTime = 0;
    this._mono = null;
    // worklet 每帧送来的样本数：波形窗口与 FFT 点数取大者（分析器只用末尾 fftSize 个样本）
    this._displayFrames = Math.min(SCOPE_CAPACITY, Math.max(o.waveFrames, o.fftSize));
    this._waveColumns = Math.min(WAVE_MAX_COLUMNS, o.waveColumns);
    this._cache = new Map();
    /** 灯板输出视图（每次取都重建；只在下一次 feedLamp 前有效）。 */
    this.lamp = null;
    /** 虚拟舞台（阶段 4.5）的分离 Worker（htdemucs，高音质模式）：第一次打开模块 13 时才起，关模块就停（释放显存）。 */
    this._hqTransport = null; // {port, init(cfg), onMessage, terminate()}：本地 Worker 或经 runtime.Port 的远程分离服务
    this._hqGen = 0;
    this._hqRestartTimer = 0;
    this._hqMaxTotalMs = 0;
    this.hqInfo = { state: "off", ep: null, threads: 0, fallback: false, segment: null, depth: 0, device: null, segmentMs: 0, rtf: 0, infMs: 0, totalMs: 0, windows: 0, error: null };
    /** 分离 Worker 状态 / 每段统计变化：(info) => void。 */
    this.onHq = null;
  }

  async _start() {
    this.ui = await instantiate(this.module);
    // 主线程实例也建一个引擎：不处理音频，只保管模块 11（显示设置），灯板每帧从它同步
    const ri = this.ui.init(this.ctx.sampleRate);
    if (ri !== ERR.OK) throw new Error(`主线程 na_init 失败: ${ri}`);
    const r = this.ui.analyzerInit(this.ctx.sampleRate, this.opts.fftSize, this.opts.curvePoints);
    if (r !== ERR.OK) throw new Error(`na_analyzer_init 失败: ${r}`);
    this._lampObj = new NeoLamp(this.ui);
    this.lamp = this._lampObj.lamp;

    // worklet 需要同一个 wasm。Chrome / 普通页面：直接传编译好的 Module；Firefox 的 content script 沙箱里 Module
    // 克隆给 worklet 会抛 "The object could not be cloned"（structuredClone 探测不出来），于是按顺序重试：
    // Module → 原始字节（worklet 线程自己同步编译）→ 普通数组（什么环境都能克隆）
    const bytes = NeoAudio.bytesOf(this.module);
    const attempts = [{ how: "module", opts: { module: this.module } }];
    if (bytes) {
      attempts.push({ how: "bytes", opts: { bytes: bytes.slice(0) } });
      attempts.push({ how: "array", opts: { bytesArray: Array.from(new Uint8Array(bytes)) } });
    }
    let lastErr = null;
    for (const a of attempts) {
      try {
        this.node = new AudioWorkletNode(this.ctx, "neo-audio-processor", {
          numberOfInputs: 1,
          numberOfOutputs: 1,
          outputChannelCount: [2],
          processorOptions: toPage(a.opts),
        });
        this.wasmTransfer = a.how; // 调试 / 自动化：这次用的是哪种传法
        break;
      } catch (e) {
        lastErr = e;
        if (!/clone/i.test(e.message)) throw new Error(`AudioWorkletNode(processorOptions=${a.how}): ${e.message}`);
      }
    }
    if (!this.node) throw new Error(`AudioWorkletNode: wasm 传不进 worklet（${lastErr ? lastErr.message : "?"}）`);
    const ready = new Promise((resolve, reject) => {
      this._resolveReady = resolve;
      this._rejectReady = reject;
    });
    this.node.port.onmessage = (e) => this._onMessage(e.data);
    // 处理器里抛了异常 → 浏览器把它判死（之后静音、不再发帧）；至少把这事报出来
    this.node.onprocessorerror = () => {
      if (this.onError) this.onError(new Error("AudioWorklet 处理器出错（processorerror），处理已停止"));
    };
    await ready;
    this._sendDisplayConfig();
  }

  _sendDisplayConfig() {
    this.node.port.postMessage(toPage({
      type: "display",
      frames: this._displayFrames,
      intervalMs: this.opts.displayIntervalMs,
      idleSeconds: this.opts.idleSeconds,
      idleIntervalMs: this.opts.idleIntervalMs,
    }));
  }

  _onMessage(m) {
    if (!m) return;
    switch (m.type) {
      case "ready":
        this.latency = m.latency;
        if (this._resolveReady) this._resolveReady();
        break;
      case "error":
        if (this._rejectReady) this._rejectReady(new Error(m.message));
        if (this.onError) this.onError(new Error(m.message));
        break;
      case "got": {
        const p = this._pending.get(m.id);
        if (p) {
          this._pending.delete(m.id);
          if (m.error === ERR.OK) p.resolve(m.value);
          else p.reject(new Error(`na_get_param 错误 ${m.error}`));
        }
        break;
      }
      case "display":
        try {
          this._onDisplay(m.buffer, m.frames);
        } catch (e) {
          if (!this._displayErrorReported) {
            this._displayErrorReported = true;
            if (this.onError) this.onError(new Error(`显示帧处理失败: ${e.message}`));
          }
        }
        break;
      case "idle":
        this.idle = !!m.on;
        if (this.onIdle) this.onIdle(this.idle);
        break;
      default:
        break;
    }
  }

  _onDisplay(buffer, frames) {
    const view = viewOf(buffer);
    const meters = view.subarray(0, METER_COUNT);
    const l = view.subarray(METER_COUNT, METER_COUNT + frames);
    const r = view.subarray(METER_COUNT + frames, METER_COUNT + 2 * frames);

    const now = performance.now();
    const dt = this._lastDisplayTime ? (now - this._lastDisplayTime) / 1000 : 0.033;
    this._lastDisplayTime = now;

    let result = null;
    if (this.ui && this.onDisplay) {
      if (!this._mono || this._mono.length !== frames) this._mono = new Float32Array(frames);
      const mono = this._mono;
      for (let i = 0; i < frames; i++) mono[i] = 0.5 * (l[i] + r[i]);
      this.ui.analysisInput(mono);
      this.ui.analyze(frames, dt);
      // 波形：左右各抽取一次（复制出来，因为下一次调用会覆盖 wasm 侧缓冲）
      this.ui.analysisInput(l);
      const waveL = Float32Array.from(this.ui.decimate(frames, this._waveColumns));
      this.ui.analysisInput(r);
      const waveR = Float32Array.from(this.ui.decimate(frames, this._waveColumns));
      // 示波器用的原始样本尾段（必须在缓冲归还前复制）
      const sn = Math.min(frames, this.opts.scopeFrames);
      const scopeL = Float32Array.from(l.subarray(frames - sn));
      const scopeR = Float32Array.from(r.subarray(frames - sn));
      result = {
        meters: Float32Array.from(meters),
        curveDb: this.ui.curveDb(),
        curveFreq: this.ui.curveFreq(),
        barsDb: this.ui.barsDb(),
        barFreq: this.ui.barFreq(),
        barActive: this.ui.barActive(),
        waveL,
        waveR,
        scopeL,
        scopeR,
        frames,
        latency: this.latency,
        sampleRate: this.ctx.sampleRate,
      };
    }
    // 归还缓冲区（转移所有权）。Firefox 的 content script 沙箱里页面侧的 ArrayBuffer 回传会失败（cloneInto 不收它）：
    // 失败一次就不再回收，worklet 每帧自己分配（几十 KB，GC 压力可接受）；绝不能让异常掐断后面的 onDisplay
    if (this.node && !this._noRecycle && !IS_SANDBOX) {
      try {
        this.node.port.postMessage(toPage({ type: "recycle", buffer }), [buffer]);
      } catch (e) {
        this._noRecycle = true;
        if (this.onError) this.onError(new Error(`显示缓冲不回收（${e.message}），改为每帧分配`));
      }
    }
    if (result) this.onDisplay(result);
  }

  /** 把一帧显示数据喂给内核灯板，见 NeoLamp.feedLamp。 */
  feedLamp(d) {
    return this._lampObj.feedLamp(d);
  }

  // ---- 控制面 ----

  /** 参数元数据（不经过音频线程）。 */
  paramInfo(module, field) {
    return this.ui ? this.ui.paramInfo(module, field) : null;
  }

  /** 写参数。模块 11（显示设置）写主线程实例的引擎（灯板在这里），不经过音频线程。 */
  setParam(module, index, field, value) {
    this._cache.set(`${module}/${index}/${field}`, value);
    if (module === MODULE.DISPLAY) return this.ui.setParam(module, index, field, value);
    this.node.port.postMessage(toPage({ type: "set", module, index, field, value }));
    // 舞台的计算设备 / 段长变了（等拖动停下来）：段长让分离器在线换（不重起、不重建会话，见 neo-hq-core.js applySeg；
    // 重建会把 GPU 进程忙上几秒，整个显示都卡——BO 2026-10-16）；设备换了才重起（会话绑着执行提供器）
    if (module === MODULE.STAGE && (field === FIELD.ST_DEVICE || field === FIELD.ST_SEGMENT) && this.hqInfo.state !== "off") {
      clearTimeout(this._hqRestartTimer);
      // 防抖窗口里设备和段长都动了（设备 + 段长一起设）：只要设备动过就得重起，不能被后到的段长盖掉
      if (field === FIELD.ST_DEVICE) this._hqRestartWanted = true;
      this._hqRestartTimer = setTimeout(() => {
        const tr = this._hqTransport;
        const live = !this._hqRestartWanted && this.hqInfo.state === "on" && tr && tr.send;
        this._hqRestartWanted = false;
        if (live) tr.send({ type: "segment", segmentMs: this.cachedParam(MODULE.STAGE, 0, FIELD.ST_SEGMENT) });
        else this.restartHq();
      }, 400);
    }
    return ERR.OK;
  }

  /** 从音频线程读回实际生效值（含夹取、补偿、只读字段）。模块 11 直接从主线程实例读。 */
  getParam(module, index, field) {
    if (module === MODULE.DISPLAY) {
      const v = this.ui.getParam(module, index, field);
      return Number.isNaN(v) ? Promise.reject(new Error(`na_get_param 错误 ${this.ui.lastError()}`)) : Promise.resolve(v);
    }
    return new Promise((resolve, reject) => {
      const id = this._nextId++;
      this._pending.set(id, { resolve, reject });
      this.node.port.postMessage(toPage({ type: "get", id, module, index, field }));
    });
  }

  /** 最近一次通过 setParam 写入的值（未经夹取），没有则 undefined。 */
  cachedParam(module, index, field) {
    return this._cache.get(`${module}/${index}/${field}`);
  }

  /** 读回模块开关（目标状态）。全局/输出级没有开关，reject。 */
  getModuleEnabled(module) {
    return new Promise((resolve, reject) => {
      const id = this._nextId++;
      this._pending.set(id, { resolve: (v) => resolve(v > 0.5), reject });
      this.node.port.postMessage(toPage({ type: "getEnabled", id, module }));
    });
  }

  setModuleEnabled(module, on) {
    this.node.port.postMessage(toPage({ type: "enable", module, on: !!on }));
    if (module === MODULE.STAGE) {
      if (on) this.startHq();
      else this.stopHq();
    }
  }

  /**
   * 起分离 Worker（htdemucs，高音质模式）并把它与 worklet 用一条 MessagePort 直连。幂等；失败记在 hqInfo.error，
   * 舞台模块会一直用干混音顶上（听起来就是原声延迟几秒）。需要 opts.hqWorkerUrl 与 opts.hqModel。
   */
  async startHq() {
    if (this.hqInfo.state === "starting" || this.hqInfo.state === "on") return this.hqInfo.state === "on";
    const o = this.opts;
    if ((!o.hqWorkerUrl && !o.hqTransport) || !this.ui || !this.ui.hasStage()) {
      this._setHq({ state: "failed", error: "这个环境起不了分离 Worker" });
      return false;
    }
    const gen = ++this._hqGen;
    this._hqMaxTotalMs = 0;
    this._setHq({ state: "starting", error: null, note: null, rtf: 0, infMs: 0, totalMs: 0, windows: 0 });
    let tr = null;
    try {
      const [dev, segMs] = await Promise.all([this.getParam(MODULE.STAGE, 0, FIELD.ST_DEVICE), this.getParam(MODULE.STAGE, 0, FIELD.ST_SEGMENT)]);
      if (gen !== this._hqGen) return false;
      const device = dev >= 0.5 ? "cpu" : "gpu";
      const segmentMs = Number.isFinite(segMs) ? segMs : 500;
      const threads = o.hqThreads || Math.max(1, Math.min(4, (navigator.hardwareConcurrency || 2) - 1));
      // 通道：宿主给了 hqTransport（插件里：Worker 在 offscreen / 后台页，经 runtime.Port 来回）就用它，否则本地起 Worker（测试页、offscreen 宿主）
      tr = o.hqTransport ? await o.hqTransport() : await localHqTransport(o);
      if (gen !== this._hqGen || !this.node) {
        tr.terminate();
        return false;
      }
      tr.onMessage = (m) => this._onHqMessage(gen, m); // 启动中的 note 也收
      const ready = await tr.init({ device, segmentMs, threads });
      if (gen !== this._hqGen || !this.node) {
        tr.terminate();
        return false;
      }
      // Firefox 沙箱：带 MessagePort 的消息要用 wrapReflectors 克隆到页面那侧
      const payload = { type: "nnPort", port: tr.port };
      this.node.port.postMessage(IS_SANDBOX ? cloneInto(payload, window, { wrapReflectors: true }) : payload, [tr.port]);
      const depth = o.hqQueueDepth || this._hqDepth(ready.segment, ready.ep, 0);
      this.node.port.postMessage(toPage({ type: "stageWorker", on: true, depth }));
      tr.onMessage = (m) => this._onHqMessage(gen, m);
      this._hqTransport = tr;
      this._setHq({ state: "on", ep: ready.ep, threads: ready.threads, fallback: !!ready.fallback, segment: ready.segment, depth, device, segmentMs, error: ready.fallback ? `GPU 起不来，已改用 CPU：${ready.fallback}` : null });
      return true;
    } catch (e) {
      if (tr) tr.terminate();
      if (gen === this._hqGen) this._setHq(e && e.code === "nomodel" ? { state: "nomodel", error: null } : { state: "failed", error: e.message });
      return false;
    }
  }

  /** 停分离 Worker（关模块 / 换设置 / 销毁）。 */
  stopHq() {
    this._hqGen++;
    clearTimeout(this._hqRestartTimer);
    this._hqRestartWanted = false;
    if (this._hqTransport) {
      try {
        this._hqTransport.terminate();
      } catch (_) {
        /* 已停 */
      }
      this._hqTransport = null;
    }
    if (this.node) this.node.port.postMessage(toPage({ type: "stageWorker", on: false, depth: 0 }));
    if (this.hqInfo.state !== "off") this._setHq({ state: "off", ep: null, depth: 0, rtf: 0, windows: 0 });
  }

  /** 按当前设备 / 段长重起（设置变了、或模型刚下载好）。 */
  restartHq() {
    this.stopHq();
    return this.startHq();
  }

  /**
   * 队列深度（跳）：一个样本最多等 段长 + 一段的处理时间 才定稿，再留 0.3 s 给调度；处理时间没量到之前按设备估
   * （GPU：0.15 段长 + 0.1 s；CPU：0.9 段长），量到后按最大值的 1.5 倍。
   */
  _hqDepth(segment, ep, totalMs) {
    const S = (segment ? segment.S : 44100) / 44100;
    const proc = totalMs > 0 ? (1.5 * totalMs) / 1000 : ep === "webgpu" ? 0.15 * S + 0.1 : 0.9 * S;
    return Math.min(2800, Math.ceil(((S + proc + 0.3) * 44100) / 128));
  }

  _onHqMessage(gen, m) {
    if (gen !== this._hqGen || !m) return;
    if (m.type === "stat") {
      if (m.totalMs > this._hqMaxTotalMs) this._hqMaxTotalMs = m.totalMs;
      const want = this._hqDepth(this.hqInfo.segment, this.hqInfo.ep, this._hqMaxTotalMs);
      let depth = this.hqInfo.depth;
      if (!this.opts.hqQueueDepth && want > depth && this.node) {
        depth = want;
        this.node.port.postMessage(toPage({ type: "stageDepth", depth }));
      }
      this._setHq({ rtf: m.rtf, infMs: m.infMs, totalMs: m.totalMs, windows: m.windows, depth });
    } else if (m.type === "error") {
      this._setHq({ state: "failed", error: m.message });
    } else if (m.type === "note") {
      this._setHq({ note: m.text }); // 启动阶段的进度（建会话 / 预热耗时），面板状态行与自检用
    } else if (m.type === "segment" && m.segment) {
      // 分离器在线换好了段长：队列深度按新段长重算（可能变浅）→ 舞台模块重置队列（跳序号从 0 起，分离器等新流）
      this._hqMaxTotalMs = 0;
      const depth = this.opts.hqQueueDepth || this._hqDepth(m.segment, this.hqInfo.ep, 0);
      if (this.node) this.node.port.postMessage(toPage({ type: "stageWorker", on: true, depth }));
      const want = this.cachedParam(MODULE.STAGE, 0, FIELD.ST_SEGMENT);
      this._setHq({ segment: m.segment, segmentMs: Number.isFinite(want) ? want : this.hqInfo.segmentMs, depth });
    }
  }

  _setHq(patch) {
    Object.assign(this.hqInfo, patch);
    if (this.onHq) this.onHq(this.hqInfo);
  }

  /** 舞台分离通道的计数（诊断）：{sent, got, skipped, dropped, backlog, depth, port, portErrors}。 */
  stageStats() {
    return new Promise((resolve, reject) => {
      const id = this._nextId++;
      this._pending.set(id, { resolve, reject });
      this.node.port.postMessage(toPage({ type: "stageStats", id }));
    });
  }

  /** 分离 Worker 状态：off / starting / on / failed / nomodel（自动化探针用）。 */
  get stageWorkerState() {
    return this.hqInfo.state;
  }

  get stageQueueDepth() {
    return this.hqInfo.depth;
  }

  setLayout(module, freqs) {
    this.node.port.postMessage(toPage({ type: "layout", module, freqs: Float32Array.from(freqs) }));
  }

  clearClip() {
    this.node.port.postMessage(toPage({ type: "clearClip" }));
  }

  /** 改 FFT 点数（显示设置）：重建主线程分析器，并让 worklet 送足够多的样本。 */
  setFftSize(fftSize, curvePoints = this.opts.curvePoints) {
    const r = this.ui.analyzerInit(this.ctx.sampleRate, fftSize, curvePoints);
    if (r !== ERR.OK) return r;
    this.opts.fftSize = fftSize;
    this.opts.curvePoints = curvePoints;
    this._displayFrames = Math.min(SCOPE_CAPACITY, Math.max(this.opts.waveFrames, fftSize));
    this._sendDisplayConfig();
    return ERR.OK;
  }

  /** 改显示帧间隔（毫秒；极大值 = 实际停发，阶段 3.1 的显示屏开关用）。idleIntervalMs 可一并改。 */
  setDisplayInterval(intervalMs, idleIntervalMs) {
    this.opts.displayIntervalMs = intervalMs;
    if (idleIntervalMs !== undefined) this.opts.idleIntervalMs = idleIntervalMs;
    this._sendDisplayConfig();
  }

  /** 改空闲检测参数（秒 / 毫秒）。 */
  setIdle(idleSeconds, idleIntervalMs = this.opts.idleIntervalMs) {
    this.opts.idleSeconds = idleSeconds;
    this.opts.idleIntervalMs = idleIntervalMs;
    this._sendDisplayConfig();
  }

  setBallistics(attackMs, releaseMs) {
    return this.ui.analyzerSetBallistics(attackMs, releaseMs);
  }

  destroy() {
    this.stopHq();
    if (this.node) {
      this.node.port.onmessage = null;
      try {
        this.node.disconnect();
      } catch (_) {
        /* 已断开 */
      }
      this.node = null;
    }
    if (this.ui) {
      this.ui.analyzerDestroy();
      this.ui.destroy();
      this.ui = null;
      this.lamp = null;
      this._lampObj = null;
    }
  }
}
