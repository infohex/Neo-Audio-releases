// Neo Audio — 虚拟舞台的分离 Worker（阶段 4.5）：薄壳，逻辑在 neo-hq-core.js（Firefox 的后台页把核心内联在主线程跑）。
// 模块 Worker（type: "module"）。消息协议见 neo-hq-core.js。
import { createSeparator } from "./neo-hq-core.js";

const sep = createSeparator({ post: (m) => self.postMessage(m) });
self.onmessage = (e) => sep.handle(e.data);
