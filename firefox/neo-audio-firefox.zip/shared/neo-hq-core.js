// Neo Audio — 虚拟舞台的分离核心（阶段 4.5，"高音质模式"）：htdemucs（Demucs v4）ONNX 用 onnxruntime-web 跑，
// WebGPU（GPU）或 WASM（CPU）二选一；STFT / iSTFT 在这里用 JS 做（neo-stft.js）。
// 通常跑在模块 Worker 里（neo-hq-worker.js 是薄壳）；Firefox 的后台页把它内联在主线程跑（createHqServer({inline:true})），
// 因为那里的 Worker 里 WebGPU 首次推理不返回（4.5b，2026-10-16）。
//
// 输入跳（128 样本 @ 44.1 kHz）攒进环形缓冲，每攒够一段（S 样本，0.5–5 s，1024 的倍数）就分离一次；段与段按 Demucs
// 自己的办法重叠相加：重叠 O ≈ 25% S，三角权重；窗口 k 从 kH 开始（H = S − O），算完后 [kH, (k+1)H) 这 H 个样本定稿，
// 一次写回给 worklet。一个样本最多等 S + 推理时间才定稿，所以舞台模块的队列深度由宿主按段长与设备算（neo-audio-node.js）。
//
// 消息（主线程 → 这里）：
//   {type:'init', model:ArrayBuffer, device:'gpu'|'cpu', segmentMs, threads}  加载模型 → 回 {type:'ready', ep, threads, segment:{S,O,H}}
//                                                                          或 {type:'error', message}；GPU 起不来自动落到 CPU（ready 里 ep = 'wasm'，fallback: true）
//   {type:'port', port:MessagePort}                                          与 worklet 直连的端口
//   {type:'reset'}                                                           清空环形缓冲（换曲 / 跳转）
// 端口（worklet ⇄ 这里）：
//   → {index, hops, buf:Float32Array(hops×256)}    连续 hops 跳的输入，[跳][声道 2][128]；index 是第一跳的序号
//   ← {index, hops, buf:Float32Array(hops×1024)}   定稿的连续 hops 跳的声部，[跳][声部 4][声道 2][128]，声部顺序同舞台模块
//                                                   （鼓 / 贝斯 / 人声 / 其它）
// 这里 → 主线程：{type:'stat', infMs, totalMs, segS, rtf, windows}   每段一次（rtf = 整段耗时 / 段步进 H 的时长）

import * as ort from "./ort/ort.webgpu.mjs";
import { stftCac, istftStems, BINS } from "./neo-stft.js";

// 会话按 (后端, 模型大小) 缓存、从不 release（内联模式，Firefox 后台页）：同一个 ORT 实例里 release 过一个 WebGPU 会话再建
// 就报 "index out of bounds"，并发建两个会报 "another WebGPU EP inference session is being created"——实测两条都踩过
// （BO 2026-10-16）。缓存还让开关舞台瞬间重起（不用再读 168 MB、再编着色器）。Worker 模式（Chrome）每个 Worker 自己一份
// 模块实例，terminate 整个释放，不受影响。代价：Firefox 下舞台关掉后会话（约 1.5 GB 显存）留着，后台页被回收时才释放。
const sessionCache = new Map();
let sessionLock = Promise.resolve();
function createSession(model, opts) {
  const key = `${opts.executionProviders[0]}:${model.byteLength}`;
  const p = sessionLock.then(async () => {
    if (sessionCache.has(key)) return sessionCache.get(key);
    const s = await ort.InferenceSession.create(model, opts);
    sessionCache.set(key, s);
    return s;
  });
  sessionLock = p.then(
    () => {},
    () => {}
  );
  return p;
}
function releaseSession(s) {
  // 缓存里的会话不释放（见上）；只有不在缓存里的（预热超时换掉的那种）才真的 release
  for (const v of sessionCache.values()) if (v === s) return;
  try {
    s.release();
  } catch (_) {
    /* 已释放 */
  }
}

/**
 * 建一个分离器：io.post(m) 往外发（ready / error / stat / note）；返回 { handle(m), dispose() }，handle 收 init / port / reset / stop。
 */
export function createSeparator(io) {
  const post = (m) => io.post(m);
  const FS = 44100;
  const HOPN = 128;
  const BLOCK = 1024; // 段长 / 重叠 / 步进都是它的倍数（模型里时域分支的总步长；也是 STFT 的跳）
  const SEG_MIN = 22 * BLOCK; // 0.51 s
  const SEG_MAX = 215 * BLOCK; // 4.99 s（动态模型按它追踪，运行时段长不能超过）
  const OVERLAP = 0.25;
  // htdemucs 的声部顺序 鼓 / 贝斯 / 其它 / 人声 → 舞台模块的 鼓 / 贝斯 / 人声 / 其它
  const STEM_MAP = [0, 1, 3, 2];
  /** 预热（首次推理）的超时（ms）。 */
  const WARM_TIMEOUT_MS = 60000;

  ort.env.wasm.wasmPaths = new URL("./ort/", import.meta.url).href; // ort.webgpu.mjs + ort-wasm-simd-threaded.asyncify.{mjs,wasm}（tools/pack.py 拷来）

  let session = null;
  let ep = null;
  let port = null;
  let seg = null; // {S, O, H}
  let ring = null; // {l, r, len}：环形缓冲，按绝对样本位置取模
  let written = 0; // 已连续写入的绝对样本数（= (最后一跳序号 + 1) × 128）
  let nextStart = 0; // 下一个窗口的起点（绝对样本位置）
  let expectIndex = 0; // 期望的下一跳序号（断档 = 换曲 / 背压跳过 → 重来）
  let prevTail = null; // 上一窗口末 O 个样本（4 声部 × 2 声道），与本窗口开头重叠相加
  let weight = null; // 三角权重（长 S）
  let busy = false;
  // 内联跑（Firefox 后台页）时几个分离器共用同一个 ORT 实例：一次 session.run 还在飞就 release 会把 wasm 堆弄坏，之后
  // 再建会话报 "index out of bounds"（BO 2026-10-16）。所以 dispose 只做标记，等在飞的推理结束再真正释放
  let disposed = false;
  let inflight = 0;
  let windows = 0;
  let feeds = null; // ORT 输入张量（按段长复用）
  let pendingSeg = null; // 待生效的新段长（音质推杆动了）：等在飞的推理结束再换

  function planSegment(segmentMs) {
    const S = Math.min(SEG_MAX, Math.max(SEG_MIN, Math.round((segmentMs / 1000) * FS / BLOCK) * BLOCK));
    const O = Math.max(BLOCK, Math.round((OVERLAP * S) / BLOCK) * BLOCK);
    const H = S - O;
    return { S, O, H };
  }

  async function init(m) {
    seg = planSegment(m.segmentMs || 1000);
    const threads = Math.max(1, Math.min(8, m.threads | 0 || 1));
    // wasm 线程要 SharedArrayBuffer：普通页面得 crossOriginIsolated（COOP/COEP）；插件页（offscreen 文档）Chrome 不要求隔离也给
    // SAB（manifest 的 COOP/COEP 键反而会让 tabCapture 报 "Error starting tab capture"，不能用），所以直接探测
    let sab = false;
    try {
      sab = typeof SharedArrayBuffer !== "undefined" && new WebAssembly.Memory({ initial: 1, maximum: 1, shared: true }).buffer instanceof SharedArrayBuffer;
    } catch (_) {
      sab = false;
    }
    ort.env.wasm.numThreads = sab ? threads : 1;
    ort.env.webgpu.powerPreference = "high-performance";
    const want = m.device === "cpu" ? ["wasm"] : ["webgpu"];
    let fallback = false;
    let s = null;
    const t0s = performance.now();
    post({ type: "note", text: `建会话（${want[0]}，线程 ${ort.env.wasm.numThreads}）…` });
    try {
      s = await createSession(m.model, { executionProviders: want, graphOptimizationLevel: "all" });
      ep = want[0];
    } catch (e) {
      if (disposed) return;
      if (want[0] !== "webgpu") throw e;
      // 没有 WebGPU（或起不来）→ CPU
      fallback = String(e && e.message ? e.message : e);
      s = await createSession(m.model, { executionProviders: ["wasm"], graphOptimizationLevel: "all" });
      ep = "wasm";
    }
    if (disposed) return;
    session = s;
    post({ type: "note", text: `会话就绪（${ep}）${(performance.now() - t0s).toFixed(0)} ms，预热一段…` });
    setupSeg(seg);
    resetStream(0);
    // 预热一次（着色器编译 / 内存分配），让第一段不迟到；WebGPU 首次推理超过 WARM_TIMEOUT_MS 不回来（Firefox 的 Worker 里会这样）→ 换 CPU
    const t0 = performance.now();
    // 预热期间每 10 s 报一次心跳：首次推理卡住时能分辨是这条线程在同步阻塞（心跳停）还是在等一个永远不回来的 Promise（心跳在）
    const hb = setInterval(() => post({ type: "note", text: `预热中… ${Math.round((performance.now() - t0) / 1000)} s（线程活着）` }), 10000);
    const warm = () => separate(new Float32Array(seg.S), new Float32Array(seg.S)).finally(() => clearInterval(hb));
    if (ep === "webgpu") {
      const timedOut = await Promise.race([warm().then(() => false), new Promise((r) => setTimeout(() => r(true), WARM_TIMEOUT_MS))]);
      if (disposed) return;
      if (timedOut) {
        post({ type: "note", text: `WebGPU 首次推理 ${WARM_TIMEOUT_MS / 1000} s 没回来，改用 CPU…` });
        sessionCache.delete(`webgpu:${m.model.byteLength}`); // 挂着的会话不 release（内联模式会把实例弄坏），丢掉引用
        fallback = `WebGPU 首次推理 ${WARM_TIMEOUT_MS / 1000} s 没返回`;
        session = await createSession(m.model, { executionProviders: ["wasm"], graphOptimizationLevel: "all" });
        ep = "wasm";
        feeds = null;
        await warm();
      }
    } else await warm();
    if (disposed) return;
    post({ type: "ready", ep, threads: ort.env.wasm.numThreads, fallback, segment: seg, warmMs: performance.now() - t0 });
  }

  function resetStream(index) {
    written = index * HOPN;
    nextStart = written;
    expectIndex = index;
    prevTail = null;
  }

  /** 按段长建三角权重（Demucs：1..S/2, S/2..1）与环形缓冲（落后到 S + H 才跳段，环要装得下）。 */
  function setupSeg(s) {
    weight = new Float32Array(s.S);
    for (let i = 0; i < s.S; i++) weight[i] = i < s.S / 2 ? i + 1 : s.S - i;
    const cap = 4 * s.S;
    ring = { l: new Float32Array(cap), r: new Float32Array(cap), len: cap };
    feeds = null;
    prevTail = null;
  }

  /**
   * 在线换段长（音质推杆，BO 2026-10-16）：不重起 Worker、不重建会话——重建要重传 168 MB 权重、重编着色器，GPU 进程一忙
   * 整个显示都卡几秒。只换权重 / 环，预热一段新长度（新形状的着色器变体），再等宿主的下一跳从头对齐（舞台模块那边
   * 重置队列后跳序号从 0 起）。只能在没有推理在飞时做：pump 循环顶上、或空闲时直接做。
   */
  async function applySeg() {
    const ns = pendingSeg;
    pendingSeg = null;
    if (!ns || disposed || !session) return;
    if (ns.S !== seg.S) {
      seg = ns;
      setupSeg(seg);
    }
    resetStream(0);
    expectIndex = -1; // 环重建过了：任何序号的下一跳都当新流的起点（舞台模块重置队列时还会再发一个 reset 标记）
    const t0 = performance.now();
    await separate(new Float32Array(seg.S), new Float32Array(seg.S));
    if (disposed) return;
    post({ type: "segment", segment: seg, warmMs: performance.now() - t0 });
  }

  /** 一段：[2][S] → 声部 [4][2][S]（舞台模块的声部顺序）。 */
  async function separate(l, r) {
    inflight++;
    try {
      return await separateNow(l, r);
    } finally {
      inflight--;
      if (disposed && inflight === 0) releaseNow();
    }
  }
  async function separateNow(l, r) {
    const S = seg.S;
    const { x, T } = stftCac([l, r], S);
    if (!feeds || feeds.T !== T) {
      feeds = {
        T,
        mix: new ort.Tensor("float32", new Float32Array(2 * S), [1, 2, S]),
        x: new ort.Tensor("float32", x, [1, 4, BINS, T]),
      };
    } else {
      feeds.x.data.set(x);
    }
    feeds.mix.data.set(l, 0);
    feeds.mix.data.set(r, S);
    const t0 = performance.now();
    const res = await session.run({ mix: feeds.mix, x: feeds.x });
    const infMs = performance.now() - t0;
    const stems = istftStems(res.out_x.data, res.out_xt.data, S, T);
    const out = [stems[STEM_MAP[0]], stems[STEM_MAP[1]], stems[STEM_MAP[2]], stems[STEM_MAP[3]]];
    return { out, infMs };
  }

  function takeWindow(start) {
    const S = seg.S;
    const l = new Float32Array(S);
    const r = new Float32Array(S);
    const cap = ring.len;
    let p = start % cap;
    for (let i = 0; i < S; i++) {
      l[i] = ring.l[p];
      r[i] = ring.r[p];
      if (++p === cap) p = 0;
    }
    return { l, r };
  }

  async function pump() {
    if (busy || !session || !port) return;
    busy = true;
    try {
      for (;;) {
        if (pendingSeg) await applySeg();
        if (disposed || written < nextStart + seg.S) break;
        // 落后太多（CPU 跟不上 / 机器被占满）：往前跳到最新的一段，中间的跳由舞台模块用干混音顶上
        if (written - nextStart > seg.S + seg.H) {
          nextStart = written - seg.S;
          prevTail = null;
        }
        const t0 = performance.now();
        const w = takeWindow(nextStart);
        const { out, infMs } = await separate(w.l, w.r);
        if (disposed || !port) return;
        const { S, O, H } = seg;
        // 定稿 [nextStart, nextStart + H)：前 O 个样本与上一窗口的尾巴按三角权重相加
        const hops = H / HOPN;
        const buf = new Float32Array(hops * 4 * 2 * HOPN);
        for (let s = 0; s < 4; s++) {
          for (let ch = 0; ch < 2; ch++) {
            const y = out[s][ch];
            const tail = prevTail ? prevTail[s][ch] : null;
            for (let i = 0; i < H; i++) {
              let v = y[i];
              if (tail && i < O) {
                const wp = weight[H + i]; // 上一窗口里的位置 H + i
                const wc = weight[i];
                v = (tail[i] * wp + y[i] * wc) / (wp + wc);
              }
              const h = (i / HOPN) | 0;
              buf[((h * 4 + s) * 2 + ch) * HOPN + (i - h * HOPN)] = v;
            }
          }
        }
        // 留尾巴
        const nt = [];
        for (let s = 0; s < 4; s++) nt.push([out[s][0].subarray(H, S), out[s][1].subarray(H, S)]);
        prevTail = nt;
        const index = nextStart / HOPN;
        nextStart += H;
        windows++;
        try {
          port.postMessage({ index, hops, buf }, [buf.buffer]);
        } catch (_) {
          port.postMessage({ index, hops, buf });
        }
        const totalMs = performance.now() - t0;
        post({ type: "stat", infMs, totalMs, segS: S / FS, rtf: totalMs / 1000 / (H / FS), windows, ep });
      }
    } catch (e) {
      post({ type: "error", message: `分离失败：${e && e.message ? e.message : e}` });
    } finally {
      busy = false;
    }
  }

  function onHops(m) {
    if (!ring || !m) return;
    if (m.reset) {
      // 舞台模块重置了队列（换段长 / 重起）：序号从 0 起，等新流
      resetStream(0);
      expectIndex = -1;
      return;
    }
    if (typeof m.index !== "number" || !m.buf) return;
    const hops = m.hops | 0;
    if (m.index !== expectIndex) {
      if (expectIndex >= 0 && m.index < expectIndex) return; // 旧的 / 重复（-1：刚换段长，等新流）
      resetStream(m.index); // 断档：换曲、跳转或被背压跳过 → 从这里重来
    }
    const cap = ring.len;
    let p = written % cap;
    for (let h = 0; h < hops; h++) {
      const base = h * 2 * HOPN;
      for (let i = 0; i < HOPN; i++) {
        ring.l[p] = m.buf[base + i];
        ring.r[p] = m.buf[base + HOPN + i];
        if (++p === cap) p = 0;
      }
    }
    written += hops * HOPN;
    expectIndex = m.index + hops;
    pump();
  }

  function handle(m) {
    m = m || {};
    if (disposed) return;
    if (m.type === "init") {
      init(m).catch((err) => post({ type: "error", message: `模型加载失败：${err && err.message ? err.message : err}` }));
    } else if (m.type === "port") {
      port = m.port;
      port.onmessage = (ev) => onHops(ev.data);
    } else if (m.type === "reset") {
      if (ring) resetStream(expectIndex);
    } else if (m.type === "segment") {
      pendingSeg = planSegment(m.segmentMs || 1000);
      if (session && !busy && inflight === 0) {
        busy = true;
        applySeg()
          .catch((e) => post({ type: "error", message: `换段长失败：${e && e.message ? e.message : e}` }))
          .finally(() => {
            busy = false;
            pump();
          });
      }
    } else if (m.type === "stop") {
      dispose();
    }
  }
  function dispose() {
    disposed = true;
    if (port) {
      port.onmessage = null;
      port = null;
    }
    ring = null;
    if (inflight === 0) releaseNow();
  }
  function releaseNow() {
    if (!session) return;
    const s = session;
    session = null;
    releaseSession(s);
  }
  return { handle, dispose };
}
