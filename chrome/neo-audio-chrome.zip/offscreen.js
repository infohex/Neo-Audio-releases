// Neo Audio — offscreen 文档：引擎宿主所在（阶段 3.2）。
//
// 每个被捕获的标签页一个 EngineHost（AudioContext + worklet 引擎）；tabCapture 的 streamId → getUserMedia →
// MediaStreamSource → 引擎 → destination（标签页本身被捕获后静音，处理后的声音由这里播放）。
// content script 的面板经 runtime.Port（name = "neo-ui"）连到对应标签页的宿主，讲 protocol.js 的消息。

import { NeoAudio } from "./shared/neo-audio-node.js";
import { EngineHost } from "./common/host.js";
import { wrapJsonPort } from "./common/protocol.js";
import { ModelStore } from "./common/model-store.js";
import { HQ_MODEL } from "./common/hq-model.js";
import { createHqServer } from "./common/hq-session.js";

const WASM_URL = chrome.runtime.getURL("dsp_wasm.wasm");
const WORKLET_URL = chrome.runtime.getURL("shared/neo-audio-processor.js");
// 面板显示屏：FFT 2048、示波样本 2048、包络列 16（面板不画包络；跨 Port 一帧约 4.7k 个数）
// 虚拟舞台（阶段 4.5）：分离 Worker 脚本随插件包；模型按需下载进 IndexedDB（common/hq-model.js 里是地址与大小）
const NEO_OPTS = { fftSize: 4096, curvePoints: 256, waveColumns: 16, scopeFrames: 2048, displayIntervalMs: 33, hqWorkerUrl: chrome.runtime.getURL("shared/neo-hq-worker.js") };
const modelStore = new ModelStore(HQ_MODEL);
// 下载进度 / 状态报给 SW（它再广播给页内媒体模式的标签页）；本文档里的宿主经 host.js 串在同一个 onState 上
modelStore.onState = (st) => chrome.runtime.sendMessage({ type: "neo-model-state", state: Object.assign({}, st) }).catch(() => {});
// 注意：offscreen 文档里除了 chrome.runtime 没有别的扩展 API（chrome.storage 是 undefined，顶层一碰模块就挂、ping 永远不应答）。
// 开发 / 自动化用的模型地址覆盖（chrome.storage.local 的 neo.devModelUrl）由 SW 读出来随 start 消息带过来。

// 分离服务（方案 B）：页面里的引擎经 runtime.Port（neo-hq）把音频跳送来，这里起 Worker 分离、把声部送回
const BORN = Date.now(); // 文档出生时间（status 里报出去：自动化看它有没有被拆了重建）
const hqServer = createHqServer({ modelStore, workerUrl: chrome.runtime.getURL("shared/neo-hq-worker.js"), log });
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "neo-hq") hqServer.attach(port);
});

let modulePromise = null;
const hosts = new Map(); // tabId → { host, stream }
const pending = new Map(); // tabId → [endpoint]：宿主还没建好时先连上来的面板

function log(text) {
  console.debug("[Neo Audio offscreen]", text);
}

async function start(tabId, streamId, devModelUrl) {
  if (hosts.has(tabId)) await stop(tabId);
  if (typeof devModelUrl === "string" && devModelUrl) modelStore.url = devModelUrl;
  if (!modulePromise) modulePromise = NeoAudio.loadModule(WASM_URL);
  const module = await modulePromise;
  const host = new EngineHost({ module, wasmUrl: WASM_URL, workletUrl: WORKLET_URL, neoOpts: NEO_OPTS, modelStore, log: (t) => log(`[tab ${tabId}] ${t}`) });
  await host.start();
  let stream = null;
  if (streamId) {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } },
      video: false,
    });
    host.connectNode(host.ctx.createMediaStreamSource(stream), "tab");
    // 捕获的轨道结束（标签页关闭 / 浏览器收回）→ 当作关闭
    for (const t of stream.getAudioTracks()) t.addEventListener("ended", () => stop(tabId));
  }
  hosts.set(tabId, { host, stream });
  for (const ep of pending.get(tabId) || []) attach(tabId, ep);
  pending.delete(tabId);
  log(`tab ${tabId}：宿主已启动，${host.sampleRate} Hz，源 ${host.sourceKind}`);
  return { sampleRate: host.sampleRate, source: host.sourceKind };
}

async function stop(tabId) {
  const e = hosts.get(tabId);
  if (!e) return;
  hosts.delete(tabId);
  if (e.stream) for (const t of e.stream.getTracks()) t.stop();
  await e.host.destroy();
  log(`tab ${tabId}：宿主已关闭`);
}

function attach(tabId, ep) {
  const e = hosts.get(tabId);
  if (!e) {
    if (!pending.has(tabId)) pending.set(tabId, []);
    pending.get(tabId).push(ep);
    ep.post({ type: "state", started: false, idle: false, source: "none", warnings: ["引擎尚未启动"] });
    return () => {
      const list = pending.get(tabId) || [];
      const i = list.indexOf(ep);
      if (i >= 0) list.splice(i, 1);
    };
  }
  return e.host.attach(ep);
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.to !== "offscreen") return false;
  if (m.type === "ping") {
    reply({ ok: true });
    return false;
  }
  if (m.type === "start") {
    start(m.tabId, m.streamId, m.devModelUrl).then(
      (r) => reply({ ok: true, ...r }),
      (err) => {
        log(`start 失败: ${err.message}`);
        reply({ ok: false, error: err.message });
      }
    );
    return true;
  }
  if (m.type === "stop") {
    stop(m.tabId).then(() => reply({ ok: true }));
    return true;
  }
  if (m.type === "model") {
    // SW 转来的模型操作（页内媒体模式的面板点的下载 / 取消）；devModelUrl：开发用的地址覆盖
    if (typeof m.devModelUrl === "string" && m.devModelUrl) modelStore.url = m.devModelUrl;
    if (m.op === "download") modelStore.download();
    else if (m.op === "cancel") modelStore.cancel();
    else if (m.op === "delete") modelStore.delete();
    modelStore.status().then(() => reply({ state: Object.assign({}, modelStore.state) }), () => reply({ state: Object.assign({}, modelStore.state) }));
    return true;
  }
  if (m.type === "status") {
    const tabs = {};
    for (const [id, e] of hosts) tabs[id] = { started: e.host.started, source: e.host.sourceKind, displayWanted: e.host.displayWanted, volume: e.host.volume, sampleRate: e.host.sampleRate, frames: e.host.frameCount, ctxState: e.host.ctx ? e.host.ctx.state : null, idle: e.host.idle, hq: e.host.neo ? e.host.neo.hqInfo.state : null, tracks: e.stream ? e.stream.getAudioTracks().map((t) => `${t.readyState}/${t.muted ? "muted" : "live"}`) : [], level: e.host._lastFrame ? Array.from(e.host._lastFrame.meters.slice(0, 4)).map((v) => Math.round(v)) : null };
    reply({ tabs, downloading: modelStore.state.state === "downloading", hq: hqServer.count, born: BORN });
    return false;
  }
  // 自动化探针：直接从某标签页的引擎读回（扩展内部消息，页面碰不到）
  if (m.type === "probe") {
    const e = hosts.get(m.tabId);
    if (!e || !e.host.neo) {
      reply({ error: "no host" });
      return false;
    }
    if (m.op === "set") {
      reply({ value: e.host.neo.setParam(m.module, m.index || 0, m.field, m.value) });
      return false;
    }
    if (m.op === "hq") {
      reply({ value: Object.assign({}, e.host.neo.hqInfo) });
      return false;
    }
    const p = m.op === "enabled" ? e.host.neo.getModuleEnabled(m.module) : e.host.neo.getParam(m.module, m.index || 0, m.field);
    p.then((value) => reply({ value }), (err) => reply({ error: err.message }));
    return true;
  }
  return false;
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "neo-ui") return;
  const tabId = port.sender && port.sender.tab ? port.sender.tab.id : undefined;
  if (tabId === undefined) {
    port.disconnect();
    return;
  }
  const ep = wrapJsonPort(port);
  let detach = attach(tabId, ep);
  port.onDisconnect.addListener(() => {
    if (detach) detach();
    detach = null;
  });
});

// 自动化探针（扩展内部）：把宿主表与启停暴露出来，tools/stub/ext-hq-test.mjs 在 offscreen.html 标签页里直接驱动
self.__neoOffscreen = { hosts, start, stop, modelStore };
log("offscreen 文档就绪");
